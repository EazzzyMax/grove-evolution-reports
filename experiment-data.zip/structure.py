import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import json,ijson,numpy as np,time
from pathlib import Path
from scipy.spatial.distance import cdist,pdist,squareform
from scipy.stats import spearmanr
D=Path('outputs/comparison'); worlds={k:json.load(open(D/f'{k}.json')) for k in ['old','current']}
n=worlds['current']['next_id']; cache=D/'ancestry.npz'
if cache.exists():
 z=np.load(cache);parent=z['parent'];born=z['born'];died=z['died'];gen=z['gen']
else:
 parent=np.zeros(n,np.int32);born=np.zeros(n,np.int32);died=np.zeros(n,np.int32);gen=np.zeros(n,np.int32)
 with (D/'current-full.json').open('rb') as f:
  for r in ijson.items(f,'lives.item',use_float=True):
   i=r['id'];parent[i]=r['parent'] or 0;born[i]=r['born'];died[i]=r['died'] or 0;gen[i]=r['generation']
   if i%1000000==0:print('parsed',i,flush=True)
 np.savez_compressed(cache,parent=parent,born=born,died=died,gen=gen)
def mrca(ids):
 sets=[]
 for i in ids:
  s=set()
  while i:s.add(int(i));i=parent[i]
  sets.append(s)
 common=set.intersection(*sets);v=max(common,key=lambda i:gen[i]);return {'id':v,'generation':int(gen[v]),'born':int(born[v]),'died':int(died[v])}
def kin_pairs(ids,tree,rng):
 a=rng.integers(0,len(ids),20000);b=rng.integers(0,len(ids),20000);keep=a!=b;a=a[keep];b=b[keep]
 x=ids[a].copy();y=ids[b].copy();orig=gen[x]+gen[y]
 while np.any(x!=y):
  mask=x!=y;gx=gen[x];gy=gen[y];mx=mask&(gx>=gy);my=mask&(gy>=gx);x[mx]=parent[x[mx]];y[my]=parent[y[my]]
 distance=orig-2*gen[x];same=tree[a]==tree[b]
 return {'same_tree_median_links':float(np.median(distance[same])),'different_tree_median_links':float(np.median(distance[~same])),'pairs':len(a)}
rng=np.random.default_rng(20261110);result={}; allweights=[]
for label,w in worlds.items():
 a=w['agents'];ids=np.array([x['id'] for x in a]);xy=np.array([[x['x'],x['y']] for x in a]);ts=np.array([[i%w['config']['size'],i//w['config']['size']] for i,c in enumerate(w['cells']) if c['tree']]);tree=cdist(xy,ts).argmin(1);weights=np.array([x['brain']['weights'] for x in a],dtype=np.float64);allweights.append(weights)
 gd=squareform(pdist(weights,'euclidean')/np.sqrt(weights.shape[1]));sd=squareform(pdist(xy));tri=np.triu_indices(len(a),1);same=tree[:,None]==tree[None,:];rho=float(spearmanr(gd[tri],sd[tri]).statistic)
 # Mantel-style label permutations preserve dependence among pair distances.
 perm=[]
 for _ in range(199):
  p=rng.permutation(len(a));perm.append(float(spearmanr(gd[p[:,None],p[None,:]][tri],sd[tri]).statistic))
 cuts={}
 for lag in [10000,100000,1000000]:
  ancestors=ids.copy();threshold=w['tick']-lag
  while np.any(born[ancestors]>threshold):
   mask=born[ancestors]>threshold;ancestors[mask]=parent[ancestors[mask]]
  values,counts=np.unique(ancestors,return_counts=True);order=np.argsort(-counts)
  cuts[str(lag)]=[{'id':int(values[i]),'n':int(counts[i])} for i in order]
 mr=mrca(ids);mr['age_ticks']=w['tick']-mr['born'];mr['age_fraction']=mr['age_ticks']/w['tick']
 groups=[]
 for i,t in enumerate(ts):
  ix=np.flatnonzero(tree==i)
  groups.append({'tree':i,'x':int(t[0]),'y':int(t[1]),'n':len(ix),'energy_mean':float(np.mean([a[j]['energy'] for j in ix])) if len(ix) else None,'within_rms_mean':float(gd[np.ix_(ix,ix)][np.triu_indices(len(ix),1)].mean()) if len(ix)>1 else None})
 result[label]={'tick':w['tick'],'n':len(a),'mrca':mr,'occupied_trees':len(set(tree.tolist())),'groups':groups,'cuts':cuts,'kinship':kin_pairs(ids,tree,rng),'genetic_rms_median':float(np.median(gd[tri])),'genetic_rms_same_tree':float(np.median(gd[tri][same[tri]])),'genetic_rms_different_tree':float(np.median(gd[tri][~same[tri]])),'spatial_genetic_spearman':rho,'mantel_permutation_p':(1+sum(v>=rho for v in perm))/200,'agents':[{'id':int(ids[i]),'x':int(xy[i,0]),'y':int(xy[i,1]),'tree':int(tree[i])} for i in range(len(a))]}
 print(label,{k:v for k,v in result[label].items() if k not in ['agents','groups','cuts']},flush=True)
result['between_rms_median']=float(np.median(cdist(*allweights)/np.sqrt(allweights[0].shape[1])))
D.joinpath('structure.json').write_text(json.dumps(result,indent=2))
