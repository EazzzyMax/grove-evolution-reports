//! Independent four-founder islands and ecological transfer experiments.
#![allow(dead_code)]
#[path="../src/brain.rs"] mod brain;
#[path="../src/sim.rs"] mod sim;
use brain::*;use sim::*;
use rand::{Rng,SeedableRng,seq::SliceRandom};
use serde_json::{json,Value};
use std::{fs::{self,File},io::{BufReader,BufWriter,Write},path::Path};
const OUT:&str="outputs/islands";
fn config(seed:u64)->Config{Config{size:32,trees:3,initial_population:4,seed,food_energy:60.,strike_cost:2.,mutation:0.52,max_age:10000,..Default::default()}}
fn save(w:&World,path:&str){let tmp=format!("{path}.tmp");let mut f=BufWriter::new(File::create(&tmp).unwrap());serde_json::to_writer(&mut f,w).unwrap();f.flush().unwrap();drop(f);fs::rename(tmp,path).unwrap();}
fn flush_dead(w:&mut World,f:&mut BufWriter<File>){for r in &w.lives{if r.died.is_some(){writeln!(f,"{}",serde_json::to_string(r).unwrap()).unwrap();}}w.lives.retain(|r|r.died.is_none());f.flush().unwrap();}
fn seed_new(w:&mut World,rng:&mut impl Rng){assert!(w.agents.is_empty());for i in 0..4{let pos=loop{let p=rng.random_range(0..w.cells.len());if !w.cells[p].tree&&!w.agents.iter().any(|a|a.x== (p%32)as i32&&a.y==(p/32)as i32){break p;}};let id=w.next_id;w.next_id+=1;let brain=Brain::random(rng);let a=Agent{id,lineage:i+1,parent:None,generation:0,x:(pos%32)as i32,y:(pos/32)as i32,dir:rng.random_range(0..4),energy:120.,age:0,children:0,eaten:0,cracked:0,last_birth:0,action:5,probabilities:[1./6.;6],hidden:[0.;HIDDEN],brain};w.lives.push(LifeRecord{id,parent:None,lineage:i+1,generation:0,born:w.tick,died:None,cause:None,birth_position:Some([a.x,a.y]),outcome:None,genome_base:Some(a.brain.clone()),mutations:None});w.agents.push(a);}w.validate().unwrap();}
fn record(w:&World,start:u64,restarts:u64)->Value{json!({"tick":w.tick,"colony_age":w.tick-start,"restarts":restarts,"n":w.agents.len(),"generation":w.agents.iter().map(|a|a.generation).max().unwrap_or(0),"counters":w.counters,"energy_mean":w.agents.iter().map(|a|a.energy as f64).sum::<f64>()/w.agents.len().max(1)as f64})}
fn island(mode:&str,id:u64,duration:u64){
 let prefix=format!("{OUT}/search/{mode}-{id}");if Path::new(&format!("{prefix}-final.json")).exists(){return;}
 let cap=if mode=="cap4"{4}else{usize::MAX};let mut w=World::new(config(61000+id));let mut seed_rng=rand_chacha::ChaCha8Rng::seed_from_u64(82000+id);
 let mut log=BufWriter::new(File::create(format!("{prefix}.jsonl")).unwrap());let mut archive=BufWriter::new(File::create(format!("{prefix}-lives.jsonl")).unwrap());
 writeln!(log,"{}",json!({"kind":"metadata","mode":mode,"island":id,"config":w.config,"cap":if cap==4{Some(4)}else{None},"duration_since_last_restart":duration,"reseed":"new brains and positions; existing map, food and world RNG preserved"})).unwrap();
 let mut start=0;let mut restarts=0;let mut peak=4;let mut reached10k=false;let mut reached100k=false;
 while w.tick-start<duration{
  w.step_with_population_limit(cap);peak=peak.max(w.agents.len());
  if w.agents.is_empty(){
   writeln!(log,"{}",json!({"kind":"extinction","island":id,"attempt":restarts+1,"started":start,"ended":w.tick,"duration":w.tick-start,"peak":peak,"counters":w.counters})).unwrap();flush_dead(&mut w,&mut archive);restarts+=1;start=w.tick;peak=4;reached10k=false;reached100k=false;seed_new(&mut w,&mut seed_rng);
   if restarts%100==0{eprintln!("{mode}-{id}: {restarts} restarts, {} total ticks",w.tick);}
  }
  if w.tick%1000==0{writeln!(log,"{}",record(&w,start,restarts)).unwrap();log.flush().unwrap();}
  if w.tick%10000==0{flush_dead(&mut w,&mut archive);}
  if w.tick-start>=10000&&!reached10k{reached10k=true;save(&w,&format!("{prefix}-10k.json"));eprintln!("{mode}-{id}: established after {restarts} restarts, {} alive",w.agents.len());}
  if w.tick-start>=100000&&!reached100k{reached100k=true;save(&w,&format!("{prefix}-100k.json"));}
  if (w.tick-start)%100000==0&&w.tick>start{eprintln!("{mode}-{id}: colony {} ticks; {} alive; gen {}",w.tick-start,w.agents.len(),w.agents.iter().map(|a|a.generation).max().unwrap_or(0));}
 }
 flush_dead(&mut w,&mut archive);save(&w,&format!("{prefix}-final.json"));let mut finalrow=record(&w,start,restarts);finalrow["kind"]=json!("final");writeln!(log,"{finalrow}").unwrap();log.flush().unwrap();eprintln!("DONE {mode}-{id} {finalrow}");
}
fn load(path:&str)->World{let mut w:World=serde_json::from_reader(BufReader::new(File::open(path).unwrap())).unwrap();w.validate().unwrap();w}
fn reset_archive(w:&mut World){w.lives=w.agents.iter().map(|a|LifeRecord{id:a.id,parent:None,lineage:a.lineage,generation:a.generation,born:w.tick.saturating_sub(a.age as u64),died:None,cause:None,birth_position:Some([a.x,a.y]),outcome:None,genome_base:Some(a.brain.clone()),mutations:None}).collect();w.lives.sort_by_key(|r|r.id);w.archive_start=w.tick;w.genome_archive_start=Some(w.tick);w.history.clear();w.lineage_history.clear();w.events.clear();}
fn transfer(tag:&str,mode:&str,duration:u64){
 let prefix=format!("{OUT}/transfer/{tag}-{mode}");if Path::new(&format!("{prefix}-final.json")).exists(){return;}
 let source=load(&format!("{OUT}/search/{tag}-final.json"));let mut pool=source.agents;let mut rng=rand_chacha::ChaCha8Rng::seed_from_u64(91001);pool.shuffle(&mut rng);pool.truncate(16);
 let mut cfg=config(92001);cfg.size=80;cfg.trees=18;cfg.initial_population=16;
 let mut w=if mode=="dense"{load("outputs/comparison/current.json")}else{World::new(cfg)};
 if mode=="dense"{
  for a in &mut w.agents{a.lineage=1;}
  let size=w.config.size;let trees:Vec<_>=w.cells.iter().enumerate().filter(|(_,c)|c.tree).map(|(i,_)|((i%size)as i32,(i/size)as i32)).collect();
  let mut slots:Vec<_>=w.cells.iter().enumerate().filter(|(i,c)|!c.tree&&!w.agents.iter().any(|a|a.x==(*i%size)as i32&&a.y==(*i/size)as i32)&&trees.iter().any(|p|{let dx=(*i%size)as i32-p.0;let dy=(*i/size)as i32-p.1;dx*dx+dy*dy<=25})).map(|(i,_)|i).collect();slots.shuffle(&mut rng);
  for (i,pos) in slots.into_iter().take(16).enumerate(){let mut a=pool[i%pool.len()].clone();a.id=w.next_id;w.next_id+=1;a.parent=None;a.lineage=2;a.generation=0;a.age=0;a.energy=120.;a.last_birth=0;a.children=0;a.eaten=0;a.cracked=0;a.x=(pos%size)as i32;a.y=(pos/size)as i32;a.dir=i%4;a.action=5;a.hidden=[0.;HIDDEN];a.probabilities=[1./6.;6];w.agents.push(a);}
 }else{for (i,a) in w.agents.iter_mut().enumerate(){a.brain=pool[i%pool.len()].brain.clone();a.lineage=2;}}
 reset_archive(&mut w);w.validate().unwrap();w.rng=rand_chacha::ChaCha8Rng::seed_from_u64(93001);let start=w.tick;let before=w.counters.clone();save(&w,&format!("{prefix}-start.json"));
 let mut f=BufWriter::new(File::create(format!("{prefix}.jsonl")).unwrap());let mut archive=BufWriter::new(File::create(format!("{prefix}-lives.jsonl")).unwrap());
 writeln!(f,"{}",json!({"kind":"metadata","tag":tag,"mode":mode,"duration":duration,"start":start,"config":w.config,"source_ids":pool.iter().map(|a|a.id).collect::<Vec<_>>(),"initial_residents":w.agents.iter().filter(|a|a.lineage==1).count(),"initial_invaders":16,"before":before})).unwrap();
 for elapsed in 0..duration{
  if elapsed%1000==0{let n=[w.agents.iter().filter(|a|a.lineage==1).count(),w.agents.iter().filter(|a|a.lineage==2).count()];writeln!(f,"{}",json!({"elapsed":elapsed,"n":n,"counters":w.counters})).unwrap();f.flush().unwrap();if n[1]==0{break;}}
  w.step();if w.tick%10000==0{flush_dead(&mut w,&mut archive);}
  if w.tick-start==100000{save(&w,&format!("{prefix}-100k.json"));}
  if (w.tick-start)%100000==0{eprintln!("transfer {tag}-{mode}: {} ticks, {} invaders / {} total",w.tick-start,w.agents.iter().filter(|a|a.lineage==2).count(),w.agents.len());}
  if !w.agents.iter().any(|a|a.lineage==2){break;}
 }
 flush_dead(&mut w,&mut archive);save(&w,&format!("{prefix}-final.json"));writeln!(f,"{}",json!({"kind":"final","tag":tag,"mode":mode,"elapsed":w.tick-start,"n":[w.agents.iter().filter(|a|a.lineage==1).count(),w.agents.iter().filter(|a|a.lineage==2).count()],"counters":w.counters})).unwrap();f.flush().unwrap();eprintln!("DONE transfer {tag}-{mode} after {} ticks",w.tick-start);
}
fn main(){rayon::ThreadPoolBuilder::new().num_threads(1).build_global().unwrap();let a:Vec<_>=std::env::args().collect();let mode=&a[1];if mode=="transfer"{let sel:Value=serde_json::from_reader(File::open(format!("{OUT}/selection.json")).unwrap()).unwrap();std::thread::scope(|s|{for tag in sel["selected"].as_array().unwrap(){for mode in ["large","dense"]{let tag=tag.as_str().unwrap().to_string();s.spawn(move||transfer(&tag,mode,1000000));}}});return;}let duration=a.get(2).and_then(|s|s.parse().ok()).unwrap_or(1000000);std::thread::scope(|s|{for id in 0..16{let mode=mode.clone();s.spawn(move||island(&mode,id,duration));}});}
