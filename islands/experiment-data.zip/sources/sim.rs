use crate::brain::{Brain, HIDDEN, PARAMS, RADIUS, VISION, VISUAL_INPUTS};
use rand::{Rng, SeedableRng, seq::SliceRandom};
use rand_chacha::ChaCha8Rng;
use rayon::prelude::*;
use serde::{Deserialize, Serialize};
use std::collections::VecDeque;

fn default_size() -> usize {
    32
}
fn default_width() -> usize {
    3
}
fn default_length() -> usize {
    1
}
pub const DIR: [(i32, i32); 4] = [(0, -1), (1, 0), (0, 1), (-1, 0)];
#[derive(Clone, Serialize, Deserialize, PartialEq, Debug)]
pub struct Config {
    #[serde(default = "default_size")]
    pub size: usize,
    #[serde(default = "default_width")]
    pub strike_width: usize,
    #[serde(default = "default_length")]
    pub strike_length: usize,
    pub seed: u64,
    pub initial_population: usize,
    pub trees: usize,
    pub drop_chance: f32,
    pub food_energy: f32,
    pub metabolism: f32,
    pub strike_cost: f32,
    pub mutation: f32,
    pub ready_fraction: f32,
    pub max_age: u32,
}
impl Default for Config {
    fn default() -> Self {
        Self {
            size: 32,
            strike_width: 3,
            strike_length: 1,
            seed: 42,
            initial_population: 32,
            trees: 8,
            drop_chance: 0.10,
            food_energy: 40.0,
            metabolism: 0.25,
            strike_cost: 0.8,
            mutation: 0.25,
            ready_fraction: 0.0,
            max_age: 2400,
        }
    }
}
impl Config {
    pub fn validate(&self) -> Result<(), String> {
        if !(1..=2048).contains(&self.size) {
            return Err("Размер поля: 1–2048. Верхний предел ограничивает расход памяти.".into());
        }
        if self.initial_population == 0 || self.initial_population > 4096 {
            return Err("Дикарей на старте: 1–4096 (ограничение памяти для мозгов).".into());
        }
        if self.trees > 65536 || self.trees + self.initial_population > self.size * self.size {
            return Err(
                "Деревья и дикари должны помещаться на поле; максимум 65 536 деревьев.".into(),
            );
        }
        if !(1..=4096).contains(&self.strike_width) || !(1..=4096).contains(&self.strike_length) {
            return Err("Размеры удара: 1–4096 клеток.".into());
        }
        if self.max_age == 0 {
            return Err("Предельный возраст должен быть больше нуля.".into());
        }
        for (name, value) in [
            ("Энергия ореха", self.food_energy),
            ("Жизнь / такт", self.metabolism),
            ("Стоимость удара", self.strike_cost),
            ("Сила мутации", self.mutation),
        ] {
            if !value.is_finite() || value < 0.0 {
                return Err(format!("{name}: требуется конечное неотрицательное число."));
            }
        }
        for value in [self.drop_chance, self.ready_fraction] {
            if !value.is_finite() || !(0.0..=1.0).contains(&value) {
                return Err("Вероятность должна быть от 0 до 1.".into());
            }
        }
        Ok(())
    }
}
#[derive(Clone, Copy, Default, Serialize, Deserialize)]
pub struct Cell {
    pub tree: bool,
    pub nut: u8,
    pub ttl: u16,
}
#[derive(Clone, Serialize, Deserialize)]
pub struct Agent {
    pub id: u64,
    pub lineage: u64,
    pub parent: Option<u64>,
    pub generation: u32,
    pub x: i32,
    pub y: i32,
    pub dir: usize,
    pub energy: f32,
    pub age: u32,
    pub children: u32,
    pub eaten: u32,
    pub cracked: u32,
    pub last_birth: u32,
    pub action: usize,
    pub probabilities: [f32; 6],
    pub hidden: [f32; HIDDEN],
    pub brain: Brain,
}
#[derive(Clone, Default, Serialize, Deserialize)]
pub struct Counters {
    pub births: u64,
    pub deaths: u64,
    pub eaten: u64,
    pub cracked: u64,
    pub strikes: u64,
    pub starved: u64,
    pub old_age: u64,
}
#[derive(Clone, Serialize, Deserialize)]
pub struct Sample {
    pub tick: u64,
    pub population: usize,
    pub ready: usize,
    pub energy: f32,
}
#[derive(Clone, Serialize, Deserialize)]
pub struct LineageSample {
    pub tick: u64,
    pub counts: Vec<usize>,
}
#[derive(Clone, Serialize, Deserialize)]
pub struct Event {
    pub tick: u64,
    pub text: String,
}
#[derive(Clone, Serialize, Deserialize)]
pub struct LifeOutcome {
    pub position: [i32; 2],
    pub eaten: u32,
    pub cracked: u32,
    pub children: u32,
    pub energy: f32,
}
#[derive(Clone, Serialize, Deserialize)]
pub struct LifeRecord {
    pub id: u64,
    pub parent: Option<u64>,
    pub lineage: u64,
    pub generation: u32,
    pub born: u64,
    pub died: Option<u64>,
    pub cause: Option<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub birth_position: Option<[i32; 2]>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub outcome: Option<LifeOutcome>,
    // A full baseline for founders, or living agents when upgrading an old save.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub genome_base: Option<Brain>,
    // Ordered replacement values; repeated indices must be applied in order.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub mutations: Option<Vec<(usize, f32)>>,
}
#[derive(Clone, Serialize, Deserialize)]
pub struct World {
    pub version: u32,
    #[serde(default)]
    pub lives: Vec<LifeRecord>,
    #[serde(default)]
    pub archive_start: u64,
    #[serde(default)]
    pub genome_archive_start: Option<u64>,
    pub config: Config,
    pub tick: u64,
    pub cells: Vec<Cell>,
    pub agents: Vec<Agent>,
    pub counters: Counters,
    pub history: VecDeque<Sample>,
    #[serde(default)]
    pub lineage_history: Vec<LineageSample>,
    pub events: VecDeque<Event>,
    pub rng: ChaCha8Rng,
    pub next_id: u64,
    #[serde(skip)]
    occupancy: Vec<bool>,
    #[serde(skip)]
    order: Vec<usize>,
    #[serde(skip)]
    targets: Vec<Option<usize>>,
    #[serde(skip)]
    claims: Vec<u16>,
    #[serde(skip)]
    observation_scratch: Vec<(usize, f32)>,
    #[serde(skip)]
    nut_cells: Vec<usize>,
    #[serde(skip)]
    tree_cells: Vec<usize>,
}
pub fn index(size: usize, x: i32, y: i32) -> Option<usize> {
    if x >= 0 && y >= 0 && x < size as i32 && y < size as i32 {
        Some(y as usize * size + x as usize)
    } else {
        None
    }
}
pub fn relative(a: &Agent, right: i32, forward: i32) -> (i32, i32) {
    let (fx, fy) = DIR[a.dir];
    let (rx, ry) = DIR[(a.dir + 1) % 4];
    (
        a.x + fx * forward + rx * right,
        a.y + fy * forward + ry * right,
    )
}
impl World {
    pub fn new(config: Config) -> Self {
        config.validate().expect("valid configuration");
        let size = config.size;
        let cells_len = size * size;
        let rng = ChaCha8Rng::seed_from_u64(config.seed);
        let mut w = Self {
            version: 2,
            lives: Vec::new(),
            archive_start: 0,
            genome_archive_start: Some(0),
            config,
            tick: 0,
            cells: vec![Cell::default(); cells_len],
            agents: Vec::new(),
            counters: Counters::default(),
            history: VecDeque::new(),
            lineage_history: Vec::new(),
            events: VecDeque::new(),
            rng,
            next_id: 1,
            occupancy: vec![false; cells_len],
            order: Vec::new(),
            targets: Vec::new(),
            claims: vec![0; cells_len],
            observation_scratch: Vec::with_capacity(VISUAL_INPUTS + 2),
            nut_cells: Vec::new(),
            tree_cells: Vec::new(),
        };
        for _ in 0..w.config.trees {
            let mut placed = false;
            for _ in 0..2000 {
                let x = w.rng.random_range(0..size);
                let y = w.rng.random_range(0..size);
                let near = (-4i32..=4).any(|dy| {
                    (-4i32..=4).any(|dx| {
                        dx * dx + dy * dy < 25
                            && index(size, x as i32 + dx, y as i32 + dy)
                                .is_some_and(|i| w.cells[i].tree)
                    })
                });
                if !near {
                    w.cells[y * size + x].tree = true;
                    placed = true;
                    break;
                }
            }
            if !placed {
                // Small maps may not fit the preferred spacing; still honor tree count.
                let free: Vec<_> = (0..size * size).filter(|&i| !w.cells[i].tree).collect();
                let i = free[w.rng.random_range(0..free.len())];
                w.cells[i].tree = true;
            }
        }
        let trees: Vec<_> = w
            .cells
            .iter()
            .enumerate()
            .filter_map(|(i, c)| c.tree.then_some(i))
            .collect();
        w.tree_cells = trees.clone();
        for _ in 0..28 {
            for &t in &trees {
                w.drop_nut(t);
            }
        }
        for _ in 0..w.config.initial_population {
            loop {
                let pos = w.rng.random_range(0..cells_len);
                if !w.cells[pos].tree && !w.occupancy[pos] {
                    let id = w.next_id;
                    w.next_id += 1;
                    let brain = Brain::random(&mut w.rng);
                    w.agents.push(Agent {
                        id,
                        lineage: id,
                        parent: None,
                        generation: 0,
                        x: (pos % size) as i32,
                        y: (pos / size) as i32,
                        dir: w.rng.random_range(0..4),
                        energy: 120.0,
                        age: 0,
                        children: 0,
                        eaten: 0,
                        cracked: 0,
                        last_birth: 0,
                        action: 5,
                        probabilities: [1.0 / 6.0; 6],
                        hidden: [0.0; HIDDEN],
                        brain,
                    });
                    w.occupancy[pos] = true;
                    break;
                }
            }
        }
        w.lives = w
            .agents
            .iter()
            .map(|a| LifeRecord {
                id: a.id,
                parent: a.parent,
                lineage: a.lineage,
                generation: a.generation,
                born: 0,
                died: None,
                cause: None,
                birth_position: Some([a.x, a.y]),
                outcome: None,
                genome_base: Some(a.brain.clone()),
                mutations: None,
            })
            .collect();
        w.event("Начало эксперимента. Все мозги случайные.".into());
        w.sample();
        w
    }
    fn event(&mut self, text: String) {
        self.events.push_front(Event {
            tick: self.tick,
            text,
        });
        self.events.truncate(60);
    }
    fn drop_nut(&mut self, t: usize) {
        let size = self.config.size;
        for _ in 0..8 {
            let dx: i32 = self.rng.random_range(-5..=5);
            let dy: i32 = self.rng.random_range(-5..=5);
            if dx * dx + dy * dy > 25 {
                continue;
            }
            if let Some(i) = index(
                size,
                t as i32 % size as i32 + dx,
                t as i32 / size as i32 + dy,
            ) && !self.cells[i].tree
                && self.cells[i].nut == 0
            {
                let ready = self.rng.random::<f32>() < self.config.ready_fraction;
                self.cells[i].nut = if ready { 2 } else { 1 };
                self.nut_cells.push(i);
                self.cells[i].ttl = if ready { 400 } else { 1200 };
                break;
            }
        }
    }
    pub fn observation(
        size: usize,
        cells: &[Cell],
        occ: &[bool],
        a: &Agent,
        max_age: u32,
        out: &mut Vec<(usize, f32)>,
    ) {
        out.clear();
        for row in 0..VISION {
            for col in 0..VISION {
                let base = (row * VISION + col) * 5;
                let (x, y) = relative(a, col as i32 - RADIUS, RADIUS - row as i32);
                match index(size, x, y) {
                    None => out.push((base, 1.0)),
                    Some(i) => {
                        if cells[i].tree {
                            out.push((base + 1, 1.0));
                        }
                        if cells[i].nut == 1 {
                            out.push((base + 2, 1.0));
                        }
                        if cells[i].nut == 2 {
                            out.push((base + 3, 1.0));
                        }
                        if occ[i] && (x != a.x || y != a.y) {
                            out.push((base + 4, 1.0));
                        }
                    }
                }
            }
        }
        out.push((VISUAL_INPUTS, (a.energy / 200.0).clamp(0.0, 1.0)));
        out.push((
            VISUAL_INPUTS + 1,
            (a.age as f32 / max_age as f32).clamp(0.0, 1.0),
        ));
    }
    fn rebuild_occupancy(&mut self) {
        let size = self.config.size;
        let cells_len = size * size;
        self.occupancy.resize(cells_len, false);
        self.occupancy.fill(false);
        for a in &self.agents {
            self.occupancy[index(size, a.x, a.y).unwrap()] = true;
        }
    }
    pub fn step(&mut self) {
        self.step_with_sensor_filter(|_, _| {});
    }
    /// Research hook: alter observations without changing genomes or RNG draws.
    /// The normal simulation uses an inlined no-op filter.
    pub fn step_with_sensor_filter<F>(&mut self, filter: F)
    where
        F: Fn(&Agent, &mut Vec<(usize, f32)>) + Sync,
    {
        self.step_with_filter_and_limit(filter, usize::MAX);
    }
    /// Research-only demographic limit: full populations defer births without energy cost.
    pub fn step_with_population_limit(&mut self, limit: usize) {
        self.step_with_filter_and_limit(|_, _| {}, limit);
    }
    fn step_with_filter_and_limit<F>(&mut self, filter: F, limit: usize)
    where
        F: Fn(&Agent, &mut Vec<(usize, f32)>) + Sync,
    {
        if self.agents.is_empty() {
            return;
        }
        let size = self.config.size;
        self.tick += 1;
        self.nut_cells.retain(|&i| {
            if self.cells[i].nut == 0 {
                return false;
            }
            self.cells[i].ttl = self.cells[i].ttl.saturating_sub(1);
            if self.cells[i].ttl == 0 {
                self.cells[i].nut = 0;
                return false;
            }
            true
        });
        for j in 0..self.tree_cells.len() {
            let i = self.tree_cells[j];
            if self.cells[i].tree && self.rng.random::<f32>() < self.config.drop_chance {
                self.drop_nut(i);
            }
        }
        self.rebuild_occupancy();
        let cells = &self.cells;
        let occ = &self.occupancy;
        let max_age = self.config.max_age;
        let think = |a: &mut Agent, obs: &mut Vec<(usize, f32)>| {
            Self::observation(size, cells, occ, a, max_age, obs);
            filter(a, obs);
            a.probabilities = Brain::probabilities(a.brain.forward(obs, &mut a.hidden));
        };
        if self.agents.len() >= 256 {
            self.agents.par_iter_mut().for_each_init(
                || Vec::with_capacity(VISUAL_INPUTS + 2),
                |obs, a| think(a, obs),
            );
        } else {
            for a in &mut self.agents {
                think(a, &mut self.observation_scratch);
            }
        }
        for a in &mut self.agents {
            let mut r = self.rng.random::<f32>();
            a.action = 5;
            for (j, p) in a.probabilities.iter().enumerate() {
                r -= p;
                if r <= 0.0 {
                    a.action = j;
                    break;
                }
            }
        }
        self.resolve_actions_with_limit(limit);
        if self.tick.is_multiple_of(10) {
            self.sample();
        }
    }
    // Decisions share a snapshot. Moves into occupied cells are blocked, including swaps.
    // Contested empty destinations fail for everyone. Interactions use seeded shuffled priority.
    pub fn resolve_actions(&mut self) {
        self.resolve_actions_with_limit(usize::MAX);
    }
    fn resolve_actions_with_limit(&mut self, limit: usize) {
        let size = self.config.size;
        let cells_len = size * size;
        self.rebuild_occupancy();
        self.claims.resize(cells_len, 0);
        self.claims.fill(0);
        self.targets.clear();
        self.targets.resize(self.agents.len(), None);
        for (j, a) in self.agents.iter_mut().enumerate() {
            a.age += 1;
            a.energy -= self.config.metabolism;
            match a.action {
                0 => {
                    a.energy -= 0.1;
                    let (dx, dy) = DIR[a.dir];
                    if let Some(i) = index(size, a.x + dx, a.y + dy)
                        && !self.cells[i].tree
                        && !self.occupancy[i]
                    {
                        self.targets[j] = Some(i);
                        self.claims[i] += 1;
                    }
                }
                1 => a.dir = (a.dir + 3) % 4,
                2 => a.dir = (a.dir + 1) % 4,
                3 => a.energy -= self.config.strike_cost,
                4 => a.energy -= 0.1,
                _ => {}
            }
        }
        for (j, a) in self.agents.iter_mut().enumerate() {
            if let Some(i) = self.targets[j]
                && self.claims[i] == 1
                && a.energy > 0.0
            {
                a.x = (i % size) as i32;
                a.y = (i / size) as i32;
            }
        }
        self.order.clear();
        self.order.extend(0..self.agents.len());
        self.order.shuffle(&mut self.rng);
        for &j in &self.order {
            if self.agents[j].energy <= 0.0 {
                continue;
            }
            if self.agents[j].action == 3 {
                self.counters.strikes += 1;
                for side in -((self.config.strike_width as i32 - 1) / 2)
                    ..=(self.config.strike_width as i32 / 2)
                {
                    for depth in 1..=self.config.strike_length.min(size) as i32 {
                        let (x, y) = relative(&self.agents[j], side, depth);
                        if let Some(i) = index(size, x, y) {
                            // A trunk blocks the remainder of this column of the footprint.
                            if self.cells[i].tree {
                                break;
                            }
                            if self.cells[i].nut == 1 {
                                self.cells[i].nut = 2;
                                self.cells[i].ttl = 400;
                                self.agents[j].cracked += 1;
                                self.counters.cracked += 1;
                            }
                        }
                    }
                }
            } else if self.agents[j].action == 4
                && let Some(i) = index(size, self.agents[j].x, self.agents[j].y)
                && self.cells[i].nut == 2
            {
                self.cells[i].nut = 0;
                self.cells[i].ttl = 0;
                self.agents[j].energy =
                    (self.agents[j].energy + self.config.food_energy).min(220.0);
                self.agents[j].eaten += 1;
                self.counters.eaten += 1;
            }
        }
        let before = self.agents.len();
        for a in &self.agents {
            if (a.energy <= 0.0 || a.age >= self.config.max_age)
                && let Ok(i) = self.lives.binary_search_by_key(&a.id, |r| r.id)
            {
                self.lives[i].died = Some(self.tick);
                self.lives[i].outcome = Some(LifeOutcome {
                    position: [a.x, a.y],
                    eaten: a.eaten,
                    cracked: a.cracked,
                    children: a.children,
                    energy: a.energy,
                });
                self.lives[i].cause =
                    Some(if a.energy <= 0.0 { "starvation" } else { "age" }.into());
            }
            if a.energy <= 0.0 {
                self.counters.starved += 1;
            } else if a.age >= self.config.max_age {
                self.counters.old_age += 1;
            }
        }
        self.agents
            .retain(|a| a.energy > 0.0 && a.age < self.config.max_age);
        self.counters.deaths += (before - self.agents.len()) as u64;
        self.rebuild_occupancy();
        let n = self.agents.len();
        for j in 0..n {
            if self.agents.len() >= limit { break; }
            let a = &self.agents[j];
            if a.energy < 180.0 || a.age < 60 || a.age - a.last_birth < 60 {
                continue;
            }
            let offset = self.rng.random_range(0..4);
            for k in 0..4 {
                let (dx, dy) = DIR[(k + offset) % 4];
                let (x, y) = (self.agents[j].x + dx, self.agents[j].y + dy);
                if let Some(i) = index(size, x, y)
                    && !self.cells[i].tree
                    && !self.occupancy[i]
                {
                    let parent = &mut self.agents[j];
                    parent.energy -= 80.0;
                    parent.last_birth = parent.age;
                    parent.children += 1;
                    let mut child = parent.clone();
                    let mutations = child.brain.mutate(&mut self.rng, self.config.mutation);
                    child.parent = Some(parent.id);
                    child.id = self.next_id;
                    self.next_id += 1;
                    child.generation += 1;
                    child.x = x;
                    child.y = y;
                    child.dir = self.rng.random_range(0..4);
                    child.energy = 60.0;
                    child.age = 0;
                    child.last_birth = 0;
                    child.children = 0;
                    child.eaten = 0;
                    child.cracked = 0;
                    child.action = 5;
                    child.hidden = [0.0; HIDDEN];
                    child.probabilities = [1.0 / 6.0; 6];
                    let generation = child.generation;
                    let id = child.id;
                    self.lives.push(LifeRecord {
                        id: child.id,
                        parent: child.parent,
                        lineage: child.lineage,
                        generation: child.generation,
                        born: self.tick,
                        died: None,
                        cause: None,
                        birth_position: Some([x, y]),
                        outcome: None,
                        genome_base: None,
                        mutations: Some(mutations),
                    });
                    self.agents.push(child);
                    self.occupancy[i] = true;
                    self.counters.births += 1;
                    if self.counters.births <= 5 || self.counters.births.is_multiple_of(25) {
                        self.event(format!("Родился #{id:03} · поколение {generation}"));
                    }
                    break;
                }
            }
        }
        if self.agents.is_empty() {
            self.event("Популяция вымерла. Автоподселения нет.".into());
            self.sample();
        }
    }
    fn sample(&mut self) {
        let interval = self
            .lineage_history
            .windows(2)
            .next()
            .map_or(10, |p| (p[1].tick - p[0].tick).max(10));
        if self
            .lineage_history
            .last()
            .is_none_or(|p| self.tick >= p.tick.saturating_add(interval))
        {
            let mut counts = vec![0; self.config.initial_population];
            for a in &self.agents {
                if let Some(n) = counts.get_mut(a.lineage.saturating_sub(1) as usize) {
                    *n += 1;
                }
            }
            if self.lineage_history.len() >= 2048 {
                self.lineage_history = self.lineage_history.iter().step_by(2).cloned().collect();
            }
            self.lineage_history.push(LineageSample {
                tick: self.tick,
                counts,
            });
        }

        let energy = if self.agents.is_empty() {
            0.0
        } else {
            self.agents.iter().map(|a| a.energy).sum::<f32>() / self.agents.len() as f32
        };
        self.history.push_back(Sample {
            tick: self.tick,
            population: self.agents.len(),
            ready: self.cells.iter().filter(|c| c.nut == 2).count(),
            energy,
        });
        if self.history.len() > 600 {
            self.history.pop_front();
        }
    }
    pub fn validate(&mut self) -> Result<(), String> {
        self.config.validate()?;
        let size = self.config.size;
        let cells_len = size * size;
        if self.version != 1 && self.version != 2
            || self.cells.len() != cells_len
            || self.agents.len() > cells_len
            || self.lineage_history.len() > 2048
            || self.lineage_history.iter().any(|p| {
                p.counts.len() != self.config.initial_population
                    || p.counts.iter().sum::<usize>() > cells_len
            })
            || self
                .lineage_history
                .windows(2)
                .any(|p| p[0].tick >= p[1].tick)
            || self.history.len() > 600
            || self.events.len() > 60
        {
            return Err("Несовместимый или повреждённый снимок".into());
        }
        let mut occupied = vec![false; cells_len];
        let mut ids = std::collections::HashSet::new();
        if self
            .cells
            .iter()
            .any(|c| c.nut > 2 || (c.tree && c.nut != 0))
        {
            return Err("Некорректная карта".into());
        }
        for a in &self.agents {
            let i = index(size, a.x, a.y).ok_or("Агент за границей")?;
            if occupied[i]
                || self.cells[i].tree
                || a.dir >= 4
                || a.action >= 6
                || !a.energy.is_finite()
                || a.energy <= 0.0
                || a.energy > 220.0
                || a.age >= self.config.max_age
                || a.last_birth > a.age
                || a.id >= self.next_id
                || !ids.insert(a.id)
                || a.brain.weights.len() != PARAMS
                || a.brain
                    .weights
                    .iter()
                    .any(|w| !w.is_finite() || w.abs() > 5.0)
                || a.hidden
                    .iter()
                    .chain(a.probabilities.iter())
                    .any(|v| !v.is_finite())
            {
                return Err("Некорректные данные дикаря".into());
            }
            occupied[i] = true;
        }
        if self.lives.windows(2).any(|r| r[0].id >= r[1].id)
            || self.lives.iter().any(|r| {
                r.id >= self.next_id
                    || r.born > self.tick
                    || r.died.is_some_and(|t| t < r.born || t > self.tick)
                    || r.birth_position
                        .is_some_and(|[x, y]| index(size, x, y).is_none())
                    || r.outcome.as_ref().is_some_and(|o| {
                        index(size, o.position[0], o.position[1]).is_none() || !o.energy.is_finite()
                    })
                    || r.genome_base.as_ref().is_some_and(|b| {
                        b.weights.len() != PARAMS
                            || b.weights.iter().any(|v| !v.is_finite() || v.abs() > 5.0)
                    })
                    || r.mutations.as_ref().is_some_and(|m| {
                        m.len() > 16
                            || m.iter()
                                .any(|(i, v)| *i >= PARAMS || !v.is_finite() || v.abs() > 5.0)
                    })
            })
        {
            return Err("Повреждённый журнал родословной".into());
        }
        if self.version == 1 || self.lives.is_empty() {
            self.archive_start = self.tick;
            self.lives = self
                .agents
                .iter()
                .map(|a| LifeRecord {
                    id: a.id,
                    parent: a.parent,
                    lineage: a.lineage,
                    generation: a.generation,
                    born: self.tick.saturating_sub(a.age as u64),
                    died: None,
                    cause: None,
                    birth_position: None,
                    outcome: None,
                    genome_base: None,
                    mutations: None,
                })
                .collect();
            self.lives.sort_by_key(|r| r.id);
        }
        if self.genome_archive_start.is_none() {
            self.genome_archive_start = Some(self.tick);
            for a in &self.agents {
                if let Ok(i) = self.lives.binary_search_by_key(&a.id, |r| r.id) {
                    self.lives[i].genome_base = Some(a.brain.clone());
                }
            }
        }
        self.version = 2;
        self.nut_cells = self
            .cells
            .iter()
            .enumerate()
            .filter_map(|(i, c)| (c.nut > 0).then_some(i))
            .collect();
        self.tree_cells = self
            .cells
            .iter()
            .enumerate()
            .filter_map(|(i, c)| c.tree.then_some(i))
            .collect();
        self.occupancy = occupied;
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    fn fixture() -> World {
        let mut w = World::new(Config::default());
        w.cells.fill(Cell::default());
        w.agents.truncate(1);
        w.agents[0].x = 15;
        w.agents[0].y = 15;
        w.agents[0].dir = 0;
        w.agents[0].energy = 100.0;
        w
    }
    #[test]
    fn population_limit_defers_birth_without_charging_parent() {
        let mut limited = fixture();
        limited.agents[0].energy = 200.0;
        limited.agents[0].age = 100;
        limited.agents[0].action = 5;
        let mut normal = limited.clone();
        limited.resolve_actions_with_limit(1);
        normal.resolve_actions_with_limit(2);
        assert_eq!(limited.agents.len(), 1);
        assert_eq!(normal.agents.len(), 2);
        assert_eq!(limited.agents[0].children, 0);
        assert!((limited.agents[0].energy - normal.agents[0].energy - 80.0).abs() < 0.001);
        limited.resolve_actions_with_limit(2);
        assert_eq!(limited.agents.len(), 2);
    }
    #[test]
    fn unlimited_research_path_is_exact() {
        let mut a = World::new(Config::default());
        let mut b = a.clone();
        for _ in 0..100 { a.step(); b.step_with_population_limit(usize::MAX); }
        assert_eq!(serde_json::to_value(a).unwrap(),serde_json::to_value(b).unwrap());
    }
    #[test]
    fn sensor_filter_is_reversible_and_noop_is_exact() {
        let mut normal = World::new(Config::default());
        let mut filtered = normal.clone();
        for _ in 0..100 {
            normal.step();
            filtered.step_with_sensor_filter(|_, _| {});
        }
        assert_eq!(
            serde_json::to_value(&normal).unwrap(),
            serde_json::to_value(&filtered).unwrap()
        );
        let before = filtered.agents[0].brain.weights.clone();
        let id = filtered.agents[0].id;
        filtered.step_with_sensor_filter(|_, obs| obs.retain(|(i, _)| *i >= VISUAL_INPUTS));
        assert_eq!(
            filtered
                .agents
                .iter()
                .find(|a| a.id == id)
                .unwrap()
                .brain
                .weights,
            before
        );
        let mut restored = filtered.clone();
        filtered.step();
        restored.step_with_sensor_filter(|_, _| {});
        assert_eq!(
            serde_json::to_value(&filtered).unwrap(),
            serde_json::to_value(&restored).unwrap()
        );
    }

    #[test]
    fn genome_archive_reconstructs_children_and_preserves_old_unknown_locations() {
        let mut w = World::new(Config {
            initial_population: 1,
            trees: 0,
            metabolism: 0.0,
            strike_cost: 0.0,
            ..Default::default()
        });
        w.agents[0].energy = 220.0;
        w.agents[0].age = 60;
        w.step();
        assert_eq!(w.agents.len(), 2);
        let child = &w.agents[1];
        let record = &w.lives[1];
        assert_eq!(record.birth_position, Some([child.x, child.y]));
        let mut reconstructed = w.lives[0].genome_base.clone().unwrap();
        for &(i, value) in record.mutations.as_ref().unwrap() {
            reconstructed.weights[i] = value;
        }
        assert_eq!(reconstructed.weights, child.brain.weights);
        w.agents[0].energy = -100.0;
        w.step();
        assert!(w.lives[0].outcome.is_some());
        assert_eq!(w.lives[0].outcome.as_ref().unwrap().children, 1);
        let mut legacy = serde_json::to_value(&w).unwrap();
        legacy
            .as_object_mut()
            .unwrap()
            .remove("genome_archive_start");
        for r in legacy["lives"].as_array_mut().unwrap() {
            let r = r.as_object_mut().unwrap();
            for key in ["birth_position", "outcome", "genome_base", "mutations"] {
                r.remove(key);
            }
        }
        let mut loaded: World = serde_json::from_value(legacy).unwrap();
        loaded.validate().unwrap();
        assert_eq!(loaded.genome_archive_start, Some(w.tick));
        assert!(loaded.lives[0].genome_base.is_none());
        assert!(loaded.lives[1].birth_position.is_none());
        assert_eq!(
            loaded.lives[1].genome_base.as_ref().unwrap().weights,
            loaded.agents[0].brain.weights
        );
        let roundtrip = serde_json::to_value(&loaded).unwrap();
        loaded.validate().unwrap();
        assert_eq!(roundtrip, serde_json::to_value(&loaded).unwrap());
    }

    #[test]
    fn manual_settings_outside_slider_ranges_are_usable() {
        let config = Config {
            size: 64,
            trees: 100,
            initial_population: 150,
            max_age: 20000,
            strike_width: 14,
            strike_length: 15,
            mutation: 0.0,
            food_energy: 150.0,
            metabolism: 0.0,
            strike_cost: 20.0,
            ..Default::default()
        };
        config.validate().unwrap();
        let mut w = World::new(config.clone());
        assert_eq!(w.cells.iter().filter(|c| c.tree).count(), 100);
        assert_eq!(w.agents.len(), 150);
        w.step();
        assert_eq!(w.config, config);
        let tiny = Config {
            size: 1,
            trees: 0,
            initial_population: 1,
            max_age: 1,
            ..Default::default()
        };
        let mut w = World::new(tiny);
        w.step();
        assert!(w.agents.is_empty());
        assert!(
            Config {
                size: 1024,
                ..Default::default()
            }
            .validate()
            .is_ok()
        );
        assert!(
            Config {
                size: 1,
                ..Default::default()
            }
            .validate()
            .is_err()
        );
        assert!(
            Config {
                drop_chance: 1.1,
                ..Default::default()
            }
            .validate()
            .is_err()
        );
    }
    #[test]
    fn adjustable_strike_rotates_and_hits_only_configured_rectangle() {
        for dir in 0..4 {
            for (width, length) in [(1, 1), (2, 1), (4, 2), (3, 1), (5, 4), (11, 11)] {
                let mut w = fixture();
                w.config.strike_width = width;
                w.config.strike_length = length;
                w.agents[0].dir = dir;
                w.agents[0].action = 3;
                for c in &mut w.cells {
                    c.nut = 1;
                }
                w.resolve_actions();
                assert_eq!(w.counters.cracked, (width * length) as u64);
                for side in -((width as i32 - 1) / 2)..=width as i32 / 2 {
                    for depth in 1..=length as i32 {
                        let (x, y) = relative(&w.agents[0], side, depth);
                        assert_eq!(w.cells[index(32, x, y).unwrap()].nut, 2);
                    }
                }
                assert_eq!(w.cells[index(32, 15, 15).unwrap()].nut, 1);
            }
        }
    }
    #[test]
    fn world_sizes_boundaries_and_save_resume() {
        for size in [16, 32, 128, 512] {
            let mut w = World::new(Config {
                size,
                ..Default::default()
            });
            assert_eq!(w.cells.len(), size * size);
            assert_eq!(w.cells.iter().filter(|c| c.tree).count(), w.config.trees);
            assert_eq!(
                index(size, size as i32 - 1, size as i32 - 1),
                Some(size * size - 1)
            );
            assert_eq!(index(size, size as i32, 0), None);
            w.agents[0].x = size as i32 - 1;
            w.agents[0].y = size as i32 - 1;
            let mut obs = Vec::new();
            World::observation(size, &w.cells, &w.occupancy, &w.agents[0], 2400, &mut obs);
            assert!(obs.iter().any(|(i, _)| *i < VISUAL_INPUTS && i % 5 == 0));
            // Restore original valid positions for save/load check.
            let mut w = World::new(Config {
                size,
                ..Default::default()
            });
            for _ in 0..20 {
                w.step();
            }
            let mut restored: World =
                serde_json::from_slice(&serde_json::to_vec(&w).unwrap()).unwrap();
            restored.validate().unwrap();
            w.step();
            restored.step();
            assert_eq!(
                serde_json::to_value(&w).unwrap(),
                serde_json::to_value(&restored).unwrap()
            );
        }
    }
    #[test]
    fn archive_keeps_dead_parent_and_child_after_save() {
        let mut w = fixture();
        w.agents[0].energy = 190.0;
        w.agents[0].age = 100;
        w.agents[0].action = 5;
        w.resolve_actions();
        let parent = w.agents[0].id;
        let child = w.agents[1].id;
        w.agents[0].energy = 0.01;
        w.agents[1].action = 5;
        w.resolve_actions();
        let mut loaded: World = serde_json::from_slice(&serde_json::to_vec(&w).unwrap()).unwrap();
        loaded.validate().unwrap();
        let p = loaded.lives.iter().find(|r| r.id == parent).unwrap();
        assert_eq!(p.died, Some(w.tick));
        assert_eq!(p.cause.as_deref(), Some("starvation"));
        assert_eq!(
            loaded.lives.iter().find(|r| r.id == child).unwrap().parent,
            Some(parent)
        );
    }
    #[test]
    fn old_snapshot_migrates_with_archive_start_and_new_rules() {
        let w = World::new(Config::default());
        let mut json = serde_json::to_value(&w).unwrap();
        json["version"] = 1.into();
        json["tick"] = 100.into();
        json.as_object_mut().unwrap().remove("lives");
        for field in ["size", "strike_width", "strike_length"] {
            json["config"].as_object_mut().unwrap().remove(field);
        }
        let mut loaded: World = serde_json::from_value(json).unwrap();
        loaded.validate().unwrap();
        assert_eq!(loaded.version, 2);
        assert_eq!(loaded.config.size, 32);
        assert_eq!(loaded.config.strike_length, 1);
        assert_eq!(loaded.archive_start, 100);
        assert_eq!(loaded.lives.len(), 32);
    }
    #[test]
    fn lineage_history_counts_descendants_and_preserves_start() {
        let mut w = World::new(Config::default());
        assert_eq!(w.lineage_history[0].counts, vec![1; 32]);
        w.agents[1].lineage = 1;
        for tick in (10..100_000).step_by(10) {
            w.tick = tick;
            w.sample();
        }
        assert_eq!(w.lineage_history[0].tick, 0);
        assert!(w.lineage_history.len() <= 2048);
        assert!(w.lineage_history.windows(2).all(|p| p[0].tick < p[1].tick));
        let last = w.lineage_history.last().unwrap();
        assert_eq!(&last.counts[..2], &[2, 0]);
        assert_eq!(last.counts.iter().sum::<usize>(), w.agents.len());
        let mut json = serde_json::to_value(&w).unwrap();
        json.as_object_mut().unwrap().remove("lineage_history");
        let mut legacy: World = serde_json::from_value(json).unwrap();
        legacy.validate().unwrap();
        legacy.sample();
        assert_eq!(legacy.lineage_history[0].tick, w.tick);
    }
    #[test]
    fn strike_then_step_onto_cracked_nut_to_eat() {
        let mut w = fixture();
        let i = index(32, 15, 14).unwrap();
        w.cells[i].nut = 1;
        w.agents[0].action = 4;
        w.resolve_actions();
        assert_eq!(w.counters.eaten, 0);
        w.agents[0].action = 3;
        w.resolve_actions();
        assert_eq!(w.cells[i].nut, 2);
        w.agents[0].action = 4;
        w.resolve_actions();
        assert_eq!(w.counters.eaten, 0);
        w.agents[0].action = 0;
        w.resolve_actions();
        let energy = w.agents[0].energy;
        w.agents[0].action = 4;
        w.resolve_actions();
        assert_eq!(w.cells[i].nut, 0);
        assert!(w.agents[0].energy > energy + 39.0);
    }
    #[test]
    fn tree_blocks_strike_and_border_is_separate() {
        let mut w = fixture();
        w.config.strike_length = 3;
        w.cells[index(32, 15, 14).unwrap()].tree = true;
        w.cells[index(32, 15, 13).unwrap()].nut = 1;
        w.agents[0].action = 3;
        w.resolve_actions();
        assert_eq!(w.cells[index(32, 15, 13).unwrap()].nut, 1);
        w.agents[0].x = 0;
        w.agents[0].y = 0;
        w.cells[index(32, 1, 0).unwrap()].tree = true;
        w.rebuild_occupancy();
        let mut obs = Vec::new();
        World::observation(
            w.config.size,
            &w.cells,
            &w.occupancy,
            &w.agents[0],
            2400,
            &mut obs,
        );
        assert!(obs.iter().any(|(i, _)| *i < VISUAL_INPUTS && i % 5 == 0));
        assert!(obs.iter().any(|(i, _)| *i < VISUAL_INPUTS && i % 5 == 1));
    }
    #[test]
    fn reproduction_conserves_energy_with_cost_and_mutates() {
        let mut w = fixture();
        w.agents[0].energy = 190.0;
        w.agents[0].age = 100;
        w.agents[0].action = 5;
        let old = w.agents[0].brain.weights.clone();
        w.resolve_actions();
        assert_eq!(w.agents.len(), 2);
        assert!(
            (w.agents.iter().map(|a| a.energy).sum::<f32>() - (190.0 - 0.25 - 20.0)).abs() < 0.001
        );
        assert_ne!(w.agents[1].brain.weights, old);
        assert_eq!(w.agents[1].parent, Some(w.agents[0].id));
    }
    #[test]
    fn overlapping_agent_and_nut_are_visible() {
        let mut w = fixture();
        let mut b = w.agents[0].clone();
        b.x += 1;
        b.id = 999;
        w.agents.push(b);
        w.cells[index(32, 16, 15).unwrap()].nut = 1;
        w.rebuild_occupancy();
        let mut obs = Vec::new();
        World::observation(
            w.config.size,
            &w.cells,
            &w.occupancy,
            &w.agents[0],
            2400,
            &mut obs,
        );
        let base = (5 * VISION + 6) * 5;
        assert!(obs.contains(&(base + 2, 1.0)));
        assert!(obs.contains(&(base + 4, 1.0)));
    }
    #[test]
    fn snapshot_resumes_exact_rng_and_simulation() {
        let mut a = World::new(Config::default());
        for _ in 0..25 {
            a.step();
        }
        let mut b: World = serde_json::from_str(&serde_json::to_string(&a).unwrap()).unwrap();
        b.validate().unwrap();
        for _ in 0..50 {
            a.step();
            b.step();
        }
        assert_eq!(
            serde_json::to_string(&a).unwrap(),
            serde_json::to_string(&b).unwrap()
        );
    }
    #[test]
    fn contested_move_has_no_iteration_priority() {
        let mut w = fixture();
        w.agents[0].x = 14;
        w.agents[0].dir = 1;
        w.agents[0].action = 0;
        let mut b = w.agents[0].clone();
        b.x = 16;
        b.dir = 3;
        w.agents.push(b);
        w.resolve_actions();
        assert_eq!(w.agents[0].x, 14);
        assert_eq!(w.agents[1].x, 16);
    }
    #[test]
    fn extinct_population_is_not_reseeded() {
        let mut w = fixture();
        w.agents[0].energy = 0.01;
        w.step();
        let tick = w.tick;
        w.step();
        assert!(w.agents.is_empty());
        assert_eq!(w.tick, tick);
    }
}
