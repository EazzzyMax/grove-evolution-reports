import json,collections,numpy as np
from pathlib import Path
D=Path('outputs/islands');sel=json.load(open(D/'selection.json'));assays={}
for p in (D/'assays').glob('*.jsonl'):
 rows=[json.loads(l) for l in p.open()]
 if not rows:continue
 tasks=collections.defaultdict(list)
 for r in rows:tasks[r['task']].append(r)
 whole=[r for r in rows if r['task'].startswith('whole')];cracked=[r for r in rows if r['task'].startswith('cracked')]
 assays[p.stem]={'brains':len(set(r['agent'] for r in rows)),'n':len(rows),'whole':float(np.mean([r['success'] for r in whole])),'cracked':float(np.mean([r['success'] for r in cracked])),'tasks':{t:float(np.mean([r['success'] for r in rs])) for t,rs in tasks.items()}}
search=[];timeline={}
for r in sel['islands']:
 tag=r['tag'];rows=[json.loads(l) for l in (D/'search'/f'{tag}.jsonl').open()];ext=[v for v in rows if v.get('kind')=='extinction'];final=rows[-1];start=final['tick']-1000000
 before=ext[-1]['counters'] if ext else {k:0 for k in final['counters']}
 delta={k:final['counters'][k]-before[k] for k in before}
 search.append({**r,'colony_counters':delta,'founder_assay':assays.get(tag+'-founders'),'final_assay':assays[tag]})
 timeline[tag]=[v for v in rows if 'colony_age' in v]
transfers=[]
for p in (D/'transfer').glob('*.jsonl'):
 if p.stem.endswith('-lives'):continue
 rows=[json.loads(l) for l in p.open()]
 if rows[-1].get('kind')!='final':continue
 r=dict(rows[-1]);r['initial']=rows[0];r['samples']=[v for v in rows[1:] if 'elapsed'in v];tag=r['tag']+'-'+r['mode'];r['assays']={k:assays.get(tag+'-'+k) for k in ['start','100k','final']};transfers.append(r)
duels=collections.defaultdict(list)
for p in (D/'duels/runs').glob('*.jsonl'):
 rows=[json.loads(l) for l in p.open()];r=rows[-1]
 if r.get('kind')!='final':continue
 tag=r['name'].split('-duel-')[0];duels[tag].append(r)
duel_summary=[]
for tag,rs in duels.items():duel_summary.append({'tag':tag,'n':len(rs),'wins':sum(r['state']['n'][1]>r['state']['n'][0] for r in rs),'extinctions':sum(r['state']['n'][1]==0 for r in rs),'mean_share':float(np.mean([r['state']['n'][1]/max(1,sum(r['state']['n'])) for r in rs])),'runs':rs})
out={'search':search,'assays':assays,'selected':sel['selected'],'transfers':transfers,'duels':duel_summary,'timeline':timeline,'totals':{'search_world_ticks':sum(r['final']['tick'] for r in search),'failed_colonies':sum(r['failed_attempts'] for r in search),'assay_trials':sum(a['n'] for a in assays.values()),'transfer_ticks':sum(r['elapsed'] for r in transfers),'duel_ticks':sum(r['actual_ticks'] for rs in duels.values() for r in rs)}}
(D/'summary.json').write_text(json.dumps(out,indent=2))
print(out['totals'])
for mode in ['free','cap4']:
 rs=[r for r in search if r['mode']==mode];print(mode,'founders',np.mean([r['founder_assay']['whole'] for r in rs if r['founder_assay']]),'final',np.mean([r['final_assay']['whole'] for r in rs]),'generations',np.mean([r['final']['generation'] for r in rs]),'births',np.mean([r['colony_counters']['births'] for r in rs]),'food',np.mean([r['colony_counters']['eaten'] for r in rs]))
for r in transfers:print(r['tag'],r['mode'],r['elapsed'],r['n'],{k:round(v['whole']*100,1) if v else None for k,v in r['assays'].items()})
for r in duel_summary:print(r['tag'],'wins',r['wins'],'of',r['n'],'share',r['mean_share'])
