import pathlib,subprocess,concurrent.futures
r=pathlib.Path('outputs/barbarians');d=pathlib.Path('outputs/detective');e='target/release/examples/detective';jobs=[]
for kind in ['battery','focused','fingerprint','micro_audit']:
 jobs.append((kind,[e,kind,str(r/'source.json'),str(r/f'{kind}.json')]))
for scene in ['solo','drought','expensive','short_ttl','whole_short','ready_short','low_food','poison','wide','dense','frozen_solo','frozen_short_ttl']:
 for opp in ['target','earlier','main13','main689','rotators','chamber']:
  if opp!='target' and scene not in ['solo','expensive','short_ttl']:continue
  for seed in range(1601,1605):
   for order in ['normal','swap']:
    name=f'{scene}-{opp}-{seed}-{order}';jobs.append((name,[e,'contest',str(r/'source.json'),str(d/f'{opp}.json'),str(seed),scene,order,str(r/'contests'/f'{name}.json')]))
def run(job):
 name,cmd=job
 with (r/f'{name}.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=f,check=True)
 return name
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
 for name in pool.map(run,jobs):print(name,flush=True)
