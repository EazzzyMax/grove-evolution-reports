import concurrent.futures,subprocess,pathlib
r=pathlib.Path('outputs/chambers');e='target/release/examples/chambers';p=str(r/'rotators-source.json')
jobs=[[e,'probe',p,str(r/'rotators-probe.json')],[e,'eval',p,str(r/'rotators-eval.json'),'256']]
jobs += [[e,'seasonal',p,str(seed),cond,str(r/f'rotators-{cond}-{seed}.json')] for seed in range(901,907) for cond in ['normal','no_temperature','no_trees','no_compass']]
def run(args):
 result=subprocess.run(args,capture_output=True,text=True)
 return args[-1],result.returncode,result.stderr[-500:]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for result in pool.map(run,jobs):print(*result,flush=True)
