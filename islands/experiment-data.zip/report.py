import os
os.environ['MPLCONFIGDIR']='outputs/comparison/mpl';os.environ['OPENBLAS_NUM_THREADS']='1'
import json,zipfile,html
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
D=Path('outputs/islands');S=Path('outputs/comparison/site/islands');(S/'figures').mkdir(parents=True,exist_ok=True)
s=json.load(open(D/'summary.json'));assert len(s['search'])==32 and len(s['transfers'])==8;assert sum(r['n'] for r in s['duels'])==80
for t in s['transfers']:
 if t['mode']=='large':assert t['elapsed']==1000000 and t['assays']['final']
cols={'free':'#177d75','cap4':'#ad7131'};titles={'free':'Свободное размножение','cap4':'Не более 4 живых'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#c7d4cc','text.color':'#223a31','figure.facecolor':'#fafbf8','axes.facecolor':'#fafbf8','savefig.facecolor':'#fafbf8'})
def save(fig,name):fig.savefig(S/'figures'/f'{name}.svg',bbox_inches='tight');plt.close(fig)
def fmt(x,d=1):return f'{x:,.{d}f}'.replace(',',' ').replace('.',',')
def image(n,c):return f'<figure><a href="figures/{n}.svg" target="_blank"><img src="figures/{n}.svg" alt="{html.escape(c)}" loading="lazy"></a><figcaption>{c} Нажмите на график, чтобы открыть крупно.</figcaption></figure>'
def subset(mode):return sorted([r for r in s['search'] if r['mode']==mode],key=lambda r:r['island'])
def mean(mode,key):return np.mean([key(r) for r in subset(mode)])
def transfer(tag):return next(r for r in s['transfers'] if r['tag']==tag and r['mode']=='large')
def duel(tag):return next(r for r in s['duels'] if r['tag']==tag)
# 4 by 4 mosaics.
for mode in ['free','cap4']:
 fig,axs=plt.subplots(4,4,figsize=(10,10))
 for ax,r in zip(axs.flat,subset(mode)):
  w=json.load(open(D/'search'/f'{r["tag"]}-final.json'));trees=[(i%32,i//32) for i,c in enumerate(w['cells']) if c['tree']];a=w['agents']
  ax.scatter(*zip(*trees),c='#335930',marker='P',s=60);ax.scatter([v['x'] for v in a],[v['y'] for v in a],s=12,c=cols[mode],alpha=.8)
  ax.set_title(f'Зона {r["island"]+1} · {len(a)} живых\nПерезапусков: {r["failed_attempts"]}',fontsize=9);ax.set_aspect('equal');ax.set_xlim(-1,32);ax.set_ylim(32,-1);ax.set_xticks([]);ax.set_yticks([])
 fig.tight_layout();save(fig,'mosaic-'+mode)
# paired founders -> evolved per island.
fig,axs=plt.subplots(1,2,figsize=(9,4.8),sharey=True)
for ax,mode in zip(axs,['free','cap4']):
 rs=subset(mode);vals=np.array([[r['founder_assay']['whole'],r['final_assay']['whole']] for r in rs])*100
 for v in vals:ax.plot([0,1],v,'o-',color=cols[mode],alpha=.3,markersize=4,lw=1)
 ax.plot([0,1],vals.mean(0),'o-',color=cols[mode],lw=3,markersize=9);ax.set_xticks([0,1],['Основатели\nуспешной колонии','Потомки\nчерез миллион']);ax.set_ylim(0,103);ax.set_title(titles[mode]);ax.grid(axis='y',alpha=.15)
axs[0].set_ylabel('Самостоятельная добыча целого ореха, %');save(fig,'learning')
# Restart counts.
fig,ax=plt.subplots(figsize=(9,3.5));xx=np.arange(16)
for mode,dx in [('free',-.18),('cap4',.18)]:ax.bar(xx+dx,[r['failed_attempts'] for r in subset(mode)],width=.34,color=cols[mode],label=titles[mode])
ax.set_xticks(xx,range(1,17));ax.set_xlabel('Зона');ax.set_ylabel('Вымершие колонии');ax.legend();save(fig,'restarts')
# large learning.
fig,ax=plt.subplots(figsize=(9,4.2));palette=['#177d75','#57a69a','#ad7131','#d59857']
for tag,col in zip(s['selected'],palette):
 r=transfer(tag);vals=[r['assays'][k]['whole']*100 for k in ['start','100k','final']];ax.plot([0,100000,1000000],vals,'o-',label=tag,c=col)
ax.set_xticks([0,100000,500000,1000000],['Перенос','100 тыс.','500 тыс.','1 млн']);ax.set_ylim(0,103);ax.set_ylabel('Успешные одиночные задачи, %');ax.legend(ncol=2);ax.grid(alpha=.15);save(fig,'large-learning')
# Populations after migration.
fig,ax=plt.subplots(figsize=(9,3.8))
for tag,col in zip(s['selected'],palette):
 r=transfer(tag);a=r['samples'];ax.plot([v['elapsed']/1000 for v in a],[v['n'][1] for v in a],label=tag,color=col,lw=1)
ax.set_xlabel('Тысяч тактов после переноса');ax.set_ylabel('Живых');ax.legend(ncol=2);ax.grid(alpha=.15);save(fig,'large-population')
# final skills across tasks.
tasks=['whole_front','whole_leftfront','whole_rightfront','whole_behind','whole_far','whole_three','cracked_under','cracked_front','cracked_right'];tn=['Целый впереди','Слева-впереди','Справа-впереди','Целый позади','Целый в 3 клетках','Три целых впереди','Расколотый под ногами','Расколотый впереди','Расколотый справа']
ks=['old','current']+[tag+'-large-final' for tag in s['selected']];labs=['Основной · 1,30 млн','Основной · 6,89 млн']+[tag+' · после 1 млн' for tag in s['selected']]
arr=np.array([[s['assays'][k]['tasks'][t]*100 for t in tasks] for k in ks]);fig,ax=plt.subplots(figsize=(11,4.5));ax.imshow(arr,cmap='YlGnBu',vmin=0,vmax=100,aspect='auto')
for i in range(len(ks)):
 for j in range(len(tasks)):ax.text(j,i,f'{arr[i,j]:.0f}',ha='center',va='center',color='white' if arr[i,j]>60 else '#223a31',fontsize=9)
ax.set_xticks(range(len(tasks)),tn,rotation=45,ha='right');ax.set_yticks(range(len(ks)),labs);save(fig,'skills')
# All island results table.
rows=''
for mode in ['free','cap4']:
 for r in subset(mode):rows+=f'<tr><td>{r["tag"]}</td><td>{r["failed_attempts"]}</td><td>{r["final"]["n"]}</td><td>{r["final"]["generation"]}</td><td>{fmt(r["founder_assay"]["whole"]*100)}%</td><td>{fmt(r["final_assay"]["whole"]*100)}%</td></tr>'
large_rows='';duel_rows=''
for tag in s['selected']:
 r=transfer(tag);large_rows+=f'<tr><td>{tag}</td><td>{fmt(r["assays"]["start"]["whole"]*100)}%</td><td>{fmt(r["assays"]["100k"]["whole"]*100)}%</td><td>{fmt(r["assays"]["final"]["whole"]*100)}%</td><td>{r["n"][1]}</td></tr>'
 pre=duel(tag);post=duel(tag+'-grown');duel_rows+=f'<tr><td>{tag}</td><td>{pre["wins"]}/10</td><td>{post["wins"]}/10</td><td>{fmt(post["mean_share"]*100,2)}%</td></tr>'
maxfail=max(r['max_failed_lifetime'] for r in s['search']);beforewins=sum(duel(t)['wins'] for t in s['selected']);afterwins=sum(duel(t+'-grown')['wins'] for t in s['selected']);best=max(transfer(t)['assays']['final']['whole'] for t in s['selected'])
body=f'''<header><div class="eyebrow">GROVE / ПОЛЕВОЙ ОТЧЁТ 03 · 10 НОЯБРЯ 2026</div><h1>Самостоятельных нашли.<br><em>Чемпионами толпы они не стали.</em></h1><p class="lead">Четыре случайных дикаря, три дерева, 16 изолированных зон. Автоматическое заселение после вымирания, миллион непрерывных тактов и проверка в больших мирах.</p><div class="badges"><span>32 зоны в двух сериях</span><span>857 вымерших колоний</span><span>80 равных дуэлей</span></div><p><a href="../">← Предыдущий отчёт: 1,3 против 6,9 млн тактов</a></p></header>
<nav><a href="#result">Результат</a><a href="#islands">Зоны</a><a href="#large">Большие миры</a><a href="#competition">Конкуренция</a><a href="#method">Методика</a></nav><main>
<section id="result"><h2>Эксперимент доведён до длинных прогонов</h2><div class="cards"><article><b>32 / 32</b><span>зоны нашли колонию, прожившую миллион без перезапуска</span></article><article><b>{fmt(best*100)}%</b><span>лучший итог самостоятельной добычи целых орехов</span></article><article><b>{afterwins} / 40</b><span>побед над основной популяцией после дополнительного миллиона</span></article></div>
<p>Удалось получить потомков, которые надёжно выполняют цепочку <strong>найти целый орех → расколоть → встать на клетку → съесть</strong> без других дикарей. Но основная популяция на 6,89 млн тактов по-прежнему выигрывает соревнование за ресурсы. Эти свойства не совпадают.</p><div class="callout"><strong>Главный результат:</strong> самостоятельную добычу еды можно вырастить с теми же 32 скрытыми нейронами. Ограничение населения до четырёх само по себе не оказалось хорошим способом ускорить её появление. А большой мир в этих прогонах улучшил самостоятельность выбранных семей.</div></section>
<section id="islands"><h2>Твой опыт — и отдельный контроль</h2><p><strong>Серия free:</strong> 16 независимых миров 32×32, в каждом три дерева и четыре случайных основателя. Размножение свободное. <strong>Серия cap4:</strong> ещё 16 миров с теми же начальными seed, но не более четырёх живых одновременно. Это отдельное изменение условий, а не скрытое ограничение первой серии.</p><p>Вымерла вся зона — немедленно добавляются четыре новых случайных мозга на случайные свободные клетки. Деревья, оставшиеся орехи и ход генератора случайных чисел мира сохраняются. Между зонами нет миграции, обмена пищей или генами. Мозаика 4×4 эквивалентна 16 отдельным аренам, а не одному связанному полю 128×128.</p>
{image('mosaic-free','Свободная серия после миллиона непрерывных тактов каждой успешной колонии. Кресты — деревья, точки — дикари. Номера зон в изображении начинаются с 1; имена файлов free-0…free-15 — с 0.')}
<details><summary>Показать 16 зон с потолком в четыре жителя</summary>{image('mosaic-cap4','Контроль cap4. Популяция действительно не превышала четырёх; это проверено по журналам.')}</details>
<h3>Миллион отсчитывался заново после каждого вымирания</h3><p>В сумме потребовалось <strong>889 заселений</strong>: 32 успешных и 857 закончившихся вымиранием. Свободная серия пережила 240 неудачных колоний, ограниченная — 617. Всего на поиск и развитие ушло <strong>{fmt(s['totals']['search_world_ticks'],0)}</strong> мировых тактов. Самая долго жившая неудачная колония вымерла после <strong>{fmt(maxfail,0)}</strong> тактов. Поэтому даже 100 тысяч тактов выживания не были надёжной гарантией.</p>
{image('restarts','Число неудачных колоний до той, которая прожила миллион. Заселение случайными мозгами выполнялось автоматически, без отбора удачных попыток вручную.')}
<h3>Случайный удачный старт или эволюция?</h3><p>По журналу геномов восстановлены четыре основателя последней успешной колонии каждой зоны. Они получили те же задачи, что и потомки через миллион. Это именно основатели успешных колоний: результаты всех отсеянных случайных мозгов в эту среднюю не входят.</p>
{image('learning','Тонкая линия — одна зона; толстая — среднее по 16 зонам. В свободных зонах проверялись до 24 случайных потомков, в cap4 — все четыре.')}
<div class="scroll"><table><thead><tr><th>Серия</th><th>Основатели: целые орехи</th><th>Потомки: целые орехи</th><th>Старшее поколение, среднее</th><th>Рождений за успешный миллион, среднее</th></tr></thead><tbody>
<tr><td>Свободная</td><td>{fmt(mean('free',lambda r:r['founder_assay']['whole'])*100)}%</td><td>{fmt(mean('free',lambda r:r['final_assay']['whole'])*100)}%</td><td>{fmt(mean('free',lambda r:r['final']['generation']),0)}</td><td>{fmt(mean('free',lambda r:r['colony_counters']['births']),0)}</td></tr>
<tr><td>Максимум 4</td><td>{fmt(mean('cap4',lambda r:r['founder_assay']['whole'])*100)}%</td><td>{fmt(mean('cap4',lambda r:r['final_assay']['whole'])*100)}%</td><td>{fmt(mean('cap4',lambda r:r['final']['generation']),0)}</td><td>{fmt(mean('cap4',lambda r:r['colony_counters']['births']),0)}</td></tr>
</tbody></table></div>
<p>У свободной серии прирост среднего результата около 21 процентного пункта, у cap4 — около 6. Однако это <strong>не сравнение при одинаковом количестве поколений или мутаций</strong>. В малой группе резко меньше рождений и возможностей проверить новые мозги.</p><p>Кроме того, четыре жителя при трёх деревьях не обязательно живут сурово: еды на особь может быть много. Когда все четыре места заняты, рождение откладывается без расхода энергии. Это устраняет возможность большой толпы, но одновременно меняет отбор и ослабляет соревнование за еду. Четыре существа всё ещё могут пользоваться орехами, расколотыми друг другом.</p>
<details><summary>Все 32 зоны: попытки, поколения и навыки</summary><div class="scroll"><table><thead><tr><th>Зона</th><th>Вымираний</th><th>Живых</th><th>Поколение</th><th>Основатели</th><th>Потомки</th></tr></thead><tbody>{rows}</tbody></table></div></details></section>
<section id="large"><h2>Ещё миллион тактов в большом мире</h2><p>Из каждой серии выбраны две зоны с наибольшей средней успешностью на задачах с целыми орехами: <strong>free-8, free-11, cap4-9, cap4-14</strong>. Это целенаправленный отбор по тесту, поэтому их высокие стартовые результаты нельзя выдавать за средние всех зон.</p><p>Каждая получила отдельный новый мир <strong>80×80 с 18 деревьями</strong> и 16 стартовыми дикарями. Для свободных семей взяты 16 мозгов из проверенной выборки, для cap4 четыре мозга повторены по четыре раза. Дальше размножение свободное, мутации включены, никакого перезаселения. Все четыре мира прошли <strong>ещё миллион тактов</strong>.</p>
{image('large-population','Рост населения в больших мирах. Это новые автономные сообщества, без основной популяции в качестве помощников.')}
{image('large-learning','Самостоятельность проверена при переносе, на 100 тысячах и на миллионе. Линии соединяют три измерения; поведение между ними не измерялось непрерывно.')}
<div class="scroll"><table><thead><tr><th>Семья</th><th>При переносе</th><th>100 тыс.</th><th>1 млн</th><th>Живых в конце</th></tr></thead><tbody>{large_rows}</tbody></table></div>
<p>Изменения не обязаны быть монотонными: например, у cap4-9 сначала был спад, а затем сильный рост. В этих четырёх отобранных линиях большой мир не уничтожил самостоятельность. Это важное уточнение к гипотезе «толпа обязательно делает их беспомощными поодиночке».</p>
{image('skills','Успех по каждой одиночной задаче после дополнительного миллиона, %. Две верхние строки — одинаково выбранные по 24 мозга из прежних снимков основного мира.')}</section>
<section id="competition"><h2>Самостоятельность ещё не означает победу над местными</h2><h3>Подселение в уже занятый мир</h3><p>В копию основного мира на 6 888 459-м такте, где жили 757 местных дикарей, добавлялись 16 новичков одной семьи. Все четыре вторжения закончились гибелью новичков: cap4-14 — через 293 такта, cap4-9 — через 385, free-8 — через 505, free-11 — через 708. Возраст и энергия местных сохранены как в снимке; новичкам даны возраст 0 и энергия 120. Это проверка вторжения, <strong>не равный турнир</strong>.</p><h3>Равные соревнования до и после большого мира</h3><p>Чтобы убрать преимущество численности, проведены по десять дуэлей на семью: 60 против 60, пять новых карт 120×120 с 40 деревьями, на каждой обмен местами высадки. Возраст и энергия одинаковые, мутации выключены, длительность 20 тысяч тактов. Соперник — неизменная основная популяция из снимка 6,89 млн тактов. Та же проверка повторена после дополнительного миллиона развития в большом мире.</p>
<div class="scroll"><table><thead><tr><th>Семья</th><th>Побед до</th><th>Побед после</th><th>Средняя доля семьи после</th></tr></thead><tbody>{duel_rows}</tbody></table></div>
<p>Суммарно: <strong>{beforewins}/40 побед до и {afterwins}/40 после</strong>. Победа определяется численностью живых потомков в конце, а не обязательным полным вытеснением. Две рассадки одной карты связаны между собой; это пять пар карт на семью.</p><div class="callout warn"><strong>Причина конкурентного преимущества пока не установлена.</strong> Одиночный тест проверяет конкретную цепочку действий в пустом окружении. В населённом мире важны также скорость подбора готовой еды, расход энергии, перемещение и взаимодействие с чужими ударами. Мы не разделили причинный вклад этих факторов. Называть основную популяцию «просто случайной» или островных «умнее вообще» по этим данным нельзя.</div></section>
<section><h2>Что получилось — и что менять дальше</h2><ol><li><strong>Самостоятельные добытчики получены и сохранены.</strong> Лучшие потомки после большого мира надёжно решают все шесть вариантов задач с целыми орехами, включая орех позади и на расстоянии.</li><li><strong>Один миллион тактов помог увидеть изменения, которые на 100 тысячах ещё не были ясны.</strong> Но число тактов нельзя заменять числом проверенных геномов: в cap4 их существенно меньше.</li><li><strong>Простого уменьшения группы недостаточно.</strong> Потолок в четыре сокращает толпу, но оставляет много еды и мало рождений. Более подходящий следующий контроль — дозировать ресурсы на особь и чередовать индивидуальную добычу с конкуренцией.</li><li><strong>Следует сохранять разные удачные стратегии.</strong> Основная линия сильнее в конкуренции, островные потомки лучше решают часть индивидуальных задач. Для универсальности нужно проверять обе способности, а не выбирать победителя по одному показателю.</li></ol></section>
<section id="method"><h2>Методика, данные и сохранения</h2><ul><li>Базовые правила: удар 3×1 вперёд, есть только стоя на расколотом орехе; энергия ореха 60, базовый расход 0,25, дополнительная цена удара 2, плодоношение 0,10, максимальный возраст 10 000, мутация ±0,52 по 16 выбранным параметрам при рождении. Сеть 607→32→6, без памяти и обучения в течение жизни.</li><li>В каждой серии 16 независимых вычисляемых зон. Начальные seed 61000–61015, отдельные генераторы новых поселенцев 82000–82015. В двух сериях одинаковые начальные seed, но при расхождении действий расход случайных чисел и дальнейшие события различаются.</li><li>Критерий завершения поиска: миллион непрерывных тактов после последнего вымирания. Суммарное вычислительное время разных зон различается. Неудачные колонии сохранены в журналах, а не скрыты из истории.</li><li>Одиночные тесты: поле 16×16 без деревьев и соседей, энергия 120, возраст 0, максимум 300 тактов, три seed. Шесть задач с целыми орехами и три с расколотыми. Успех — съесть хотя бы один. У награды за еду нулевая энергия, потому что испытание сразу заканчивается после успеха; рождения исключены. На рисунках «самостоятельность» означает среднее по шести задачам с целыми орехами, а не общий интеллект.</li><li>Основатели проверены все четыре; потомки — случайные до 24 живых из каждой популяции. В ограниченных зонах проверены все четыре. По три повтора одного мозга не являются тремя независимыми эволюциями. Средние по сериям одинаково взвешивают каждую из 16 зон.</li><li>Семьи для переноса выбраны по этим же тестам. Проверки после переноса используют тот же набор задач, поэтому это не независимый тест обобщения на совершенно новые задачи. На каждую выбранную семью выполнен один длинный прогон в большом мире; этого недостаточно для универсальных причинных выводов о плотности.</li><li>Более крупный новый мир имеет примерно ту же плотность деревьев, что основной. Равные дуэли стартуют возле деревьев; они не проверяют поиск еды из далёкой пустыни. Конкуренция жителей и новичков в занятом мире намеренно неравная.</li><li>Выполнено {fmt(s['totals']['search_world_ticks'],0)} тактов поиска, {fmt(s['totals']['transfer_ticks'],0)} тактов переносов и {fmt(s['totals']['duel_ticks'],0)} тактов дуэлей. Одиночных испытаний — {fmt(s['totals']['assay_trials'],0)}. Счётчики мировых тактов не равны числу решений отдельных дикарей.</li><li>18 автоматических тестов проверили ядро и новый исследовательский лимит населения, включая отсутствие платы за отложенное рождение и точное совпадение обычного пути с неограниченным режимом. Отдельно проверены журналы cap4: превышений четырёх живых нет.</li></ul>
<p><strong>Основной мир не изменён:</strong> по-прежнему сохранён и стоит на паузе на такте 6 888 459. Его контрольная сумма сверена с резервной копией. Все 32 островных состояния, четыре больших мира после дополнительного миллиона, промежуточные снимки и журналы геномов хранятся отдельно. Полные многогигабайтные архивы локальные; на сайте доступны компактные результаты и код.</p><div class="downloads"><a href="data.json">Сводные результаты JSON</a><a href="experiment-data.zip">Результаты и код ZIP</a><a href="../">Предыдущий отчёт</a></div></section></main><footer>Grove · Эксперимент с изолированными колониями. Условия и ограничения приведены вместе с результатами.</footer>'''
root=Path('outputs/comparison/site/index.html').read_text();css=root.split('<style>',1)[1].split('</style>',1)[0]
(S/'index.html').write_text('<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Grove — 16 островов и самостоятельная добыча еды</title><meta name="description" content="32 зоны, 857 вымерших колоний, миллион тактов и 80 соревнований"><style>'+css+'</style></head><body>'+body+'</body></html>')
(S/'data.json').write_text(json.dumps(s,separators=(',',':')))
with zipfile.ZipFile(S/'experiment-data.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['summary.json','selection.json','tests.log','evaluate.py','evaluate_transfers.py','founders.py','select_candidates.py','summarize.py','run_duels.py','run_grown_duels.py','report.py','validation.json']:
  z.writestr(name,(D/name).read_text().replace(str(Path.cwd()),'.'))
 for directory in ['search','transfer','assays','duels/runs']:
  for p in (D/directory).glob('*.jsonl'):
   if not p.stem.endswith('-lives'):z.write(p,str(p.relative_to(D)))
 for p in (D/'sources').iterdir():z.write(p,'sources/'+p.name)
print('Report created',S,'total trials',s['totals'])
