import json,numpy as np
from pathlib import Path
from collections import defaultdict
D=Path('outputs/comparison');s=json.load(open(D/'structure.json'));z=np.load(D/'ancestry.npz');parent=z['parent'];born=z['born']
probes=json.load(open(D/'probes.json'));probe={ (r['population'],r['id'],r['state']):r['p'] for r in probes};micro=defaultdict(list)
for file in ['individual.jsonl','individual-extra.jsonl']:
 for line in open(D/file):
  r=json.loads(line);micro[r['population'],r['id'],r['task']].append(r)
for label in ['old','current']:
 a=s[label]['agents'];ids=np.array([v['id'] for v in a]);anc=ids.copy();cut=s[label]['tick']-100000
 while np.any(born[anc]>cut):
  m=born[anc]>cut;anc[m]=parent[anc[m]]
 for v,b in zip(a,anc):v['branch']=int(b)
 table=[]
 for branch in s[label]['cuts']['100000']:
  members=[v for v in a if v['branch']==branch['id']];ms=[]
  for v in members:ms.extend(micro[label,v['id'],'whole_front'])
  table.append({**branch,'occupied_trees':len(set(v['tree'] for v in members)),'p_eat_under':float(np.mean([probe[label,v['id'],'cracked_under'][4] for v in members])),'whole_front_success':float(np.mean([r['success'] for r in ms]))})
 s[label]['branch_details']=table
D.joinpath('structure.json').write_text(json.dumps(s,indent=2))
mg=defaultdict(list)
for (p,i,t),rs in micro.items():mg[p,t].extend(rs)
summary=[]
for (p,t),rs in mg.items():summary.append({'population':p,'task':t,'n':len(rs),'success':float(np.mean([r['success'] for r in rs])),'time_penalized':float(np.mean([r['ticks'] if r['success'] else 300 for r in rs])),'successful_median_ticks':float(np.median([r['ticks'] for r in rs if r['success']])) if any(r['success'] for r in rs) else None})
D.joinpath('micro-summary.json').write_text(json.dumps(summary,indent=2))
for r in summary:print(r)
