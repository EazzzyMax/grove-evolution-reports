import json,pathlib,statistics as st,html,zipfile,csv,io,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=pathlib.Path(__file__).parent; D=json.loads((R/'analysis.json').read_text())
assert not D['missing'],f"Incomplete: {len(D['missing'])}"
assert len(D['duels'])==96
SITE=pathlib.Path('outputs/comparison/site/chambers'); F=SITE/'figures';F.mkdir(parents=True,exist_ok=True)
ARCH=D['architectures'];MODES=D['modes'];LABEL={'solo':'Копия камеры','fresh':'Новая камера','shared':'Общий мир'};COLOR={'solo':'#3687c3','fresh':'#238e6b','shared':'#cf7835'}
fmt=lambda x:f'{x:.1f}'.replace('.',',')
al=lambda a:a.replace('-',' → ')
def runs(a,m):return [r for r in D['runs'] if r['arch']==a and r['mode']==m]
def vals(a,m,s,k):return [r['metrics'][s][k] for r in runs(a,m)]
def mean(a,m,s,k):return st.mean(vals(a,m,s,k))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.facecolor':'#f7f9f3','figure.facecolor':'#f7f9f3','axes.labelcolor':'#263c34','text.color':'#263c34','xtick.color':'#52685e','ytick.color':'#52685e','svg.fonttype':'path'})
def save(fig,name):fig.savefig(F/f'{name}.svg',bbox_inches='tight');plt.close(fig)
fig,axs=plt.subplots(2,2,figsize=(11,7),sharex=True,sharey=True)
for ax,a in zip(axs.flat,ARCH):
 for m in MODES:
  curves=[]
  for r in runs(a,m):
   initial=next(z for z in D['initial'] if z['arch']==a and z['seed']==r['seed'])['metrics']['solo']['food']
   curves.append([initial]+[z['food'] for z in r['learning']]+[r['metrics']['solo']['food']])
  y=np.array(curves);x=np.array([0,2.5,5,7.5,10]);ax.fill_between(x,y.min(0),y.max(0),color=COLOR[m],alpha=.10);ax.plot(x,y.mean(0),color=COLOR[m],label=LABEL[m],lw=2)
 ax.set_title(al(a),fontweight='bold');ax.grid(axis='y',alpha=.2);ax.set_xlabel('Млн решений при эволюции');ax.set_ylabel('Орехов за одиночное испытание')
axs[0,0].legend(fontsize=8);fig.tight_layout();save(fig,'learning')
fig,axs=plt.subplots(1,2,figsize=(11,4.4))
for ax,scene,metric,title in [(axs[0],'nut','success','Съел единственный целый орех, %'),(axs[1],'solo','survival','Дожил один до 5 000 тактов, %')]:
 for j,m in enumerate(MODES):
  x=np.arange(4)+(j-1)*.24;y=[mean(a,m,scene,metric) for a in ARCH];ax.bar(x,y,width=.22,color=COLOR[m],label=LABEL[m]);ax.scatter([xx for xx in x for _ in range(6)],[v for a in ARCH for v in vals(a,m,scene,metric)],s=12,c='#253a32',alpha=.65,zorder=3)
 ax.set_xticks(range(4),[al(a) for a in ARCH]);ax.set_title(title,fontsize=11);ax.set_ylim(0,105);ax.grid(axis='y',alpha=.15)
axs[0].legend(fontsize=8);fig.tight_layout();save(fig,'final')
fig,axs=plt.subplots(1,2,figsize=(11,4.2))
for ax,key,title in [(axs[0],'near','Тактов рядом с исходной точкой / 300'),(axs[1],'east','Смещение на восток, клеток')]:
 for j,temp in enumerate([0,1]):
  y=[next(z for z in D['residence'] if z['tree']==tree and z['temperature']==temp)[key] for tree in [False,True]];ax.bar(np.arange(2)+(j-.5)*.32,y,width=.30,label='Холод' if temp==0 else 'Тепло',color=['#4388b7','#d28b40'][j])
 ax.set_xticks([0,1],['Нет дерева','Есть дерево']);ax.set_title(title,fontsize=11);ax.legend();ax.grid(axis='y',alpha=.15)
fig.tight_layout();save(fig,'tree')
fig,ax=plt.subplots(figsize=(10,4))
for cond,label,color in [('normal','Все чувства','#238e6b'),('no_temperature','Температура всегда 0,5','#cf7835'),('no_trees','Не видят стволы','#3687c3'),('no_compass','Без компаса','#925cb1')]:
 rr=[r for r in D['seasonal'] if r['condition']==cond];y=np.array([[h['alive'] for h in r['history']] for r in rr]);x=[h['tick'] for h in rr[0]['history']];ax.plot(x,y.mean(0),label=label,color=color);ax.fill_between(x,y.min(0),y.max(0),color=color,alpha=.07)
ax.legend(ncol=2,fontsize=8);ax.set_xlabel('Такт');ax.set_ylabel('Живых');ax.grid(alpha=.15);fig.tight_layout();save(fig,'ablations')
rows=''
for a in ARCH:
 for m in MODES:
  r=runs(a,m);food=vals(a,m,'solo','food');init=st.mean(z['metrics']['solo']['food'] for z in D['initial'] if z['arch']==a)
  rows+=f'<tr><td>{al(a)}</td><td>{LABEL[m]}</td><td><b>{fmt(st.mean(food))}</b><small>{fmt(min(food))}–{fmt(max(food))}</small></td><td>{fmt(st.mean(food)/init)}×</td><td>{fmt(mean(a,m,"solo","survival"))}%</td><td>{fmt(mean(a,m,"nut","success"))}%</td><td>{fmt(mean(a,m,"drought","food"))}</td><td>{sum(z["training"][-1]["restarts"] for z in r)}</td></tr>'
duelrows=''
for a in ARCH:
 for left,right in [('solo','shared'),('fresh','shared'),('fresh','solo'),('fresh','rotators')]:
  rr=[z for z in D['duels'] if z['file'].startswith(f'{left}-vs-{right}-{a}-') and z['file'].rsplit('-',1)[0]==f'{left}-vs-{right}-{a}'];assert len(rr)==6
  wins=sum(z['winner']=='a' for z in rr);loss=sum(z['winner']=='b' for z in rr);draw=6-wins-loss
  share=st.mean(z['a_final']/max(1,z['a_final']+z['b_final'])*100 for z in rr)
  duelrows+=f'<tr><td>{al(a)}</td><td>{LABEL[left]} / {LABEL.get(right,"Вращалка")}</td><td>{wins} / {loss} / {draw}</td><td>{fmt(share)}%</td></tr>'
torusrows=''
for a in ARCH:
 for m in MODES:
  rr=runs(a,m);torusrows+=f'<tr><td>{al(a)} · {LABEL[m]}</td><td>{fmt(st.mean(z["torus"]["torus"]["food"] for z in rr))}</td><td>{fmt(st.mean(z["torus"]["torus"]["survival"] for z in rr))}%</td></tr>'
rot=D['rotator_eval'];rt=D['rotator_torus']['torus'];torusrows+=f'<tr><td>1.3 + 3 вращалка</td><td>{fmt(rt["food"])}</td><td>{fmt(rt["survival"])}%</td></tr>'
blindrows=''
for a in ARCH:
 for m in MODES:
  seen=mean(a,m,'solo','food'); blind=st.mean(z['blind']['solo']['food'] for z in runs(a,m));blindrows+=f'<tr><td>{al(a)} · {LABEL[m]}</td><td>{fmt(seen)}</td><td>{fmt(blind)}</td><td>{fmt((1-blind/seen)*100)}%</td></tr>'
benchrows=''
for a in ARCH:
 rr=[x for x in D.get('benchmark',{}).get('records',[]) if x['layers']==[int(v) for v in a.split('-')]]
 if rr:benchrows+=f'<tr><td>{al(a)}</td><td>{rr[0]["weights"]:,}</td><td>{fmt(st.median(x["seconds"]/x["calls"]*1e6 for x in rr))} мкс</td><td>{16/rr[0]["weights"]*100:.3f}%</td></tr>'
best=max([(mean(a,m,'solo','food'),a,m) for a in ARCH for m in MODES]);bestfood,besta,bestm=best
new32=mean('32','fresh','solo','food');shared32=mean('32','shared','solo','food');new3232=mean('32-32','fresh','solo','food');shared3232=mean('32-32','shared','solo','food')
paired=sum(vals('32','fresh','solo','food')[i]>vals('32','shared','solo','food')[i] for i in range(6))
seasonrows=''
for cond,label in [('normal','Все чувства'),('no_temperature','Температура = 0,5'),('no_trees','Стволы не видны'),('no_compass','Компас выключен')]:
 rr=[z for z in D['seasonal'] if z['condition']==cond];seasonrows+=f'<tr><td>{label}</td><td>{fmt(st.mean(z["alive"] for z in rr))}</td><td>{fmt(st.mean(z["counters"]["eaten"] for z in rr))}</td></tr>'
def figure(name,alt,caption):return f'<figure><a href="figures/{name}.svg"><img src="figures/{name}.svg" alt="{alt}" loading="lazy"></a><figcaption>{caption}</figcaption></figure>'
body=f'''
<header><div class="eyebrow">GROVE · КАМЕРНЫЕ ЭКСПЕРИМЕНТЫ · 11 НОЯБРЯ 2026</div>
<h1>Самостоятельность<br>можно отобрать.<br><em>Но это ещё не мастерство.</em></h1>
<p class="lead">Четыре размера мозга, три способа расселять потомство и проверка твоей «вращалки». Мы сравнили не красивое движение по карте, а добычу еды, выживание и конкуренцию.</p>
<div class="badges"><span>72 эволюции с нуля</span><span>720 млн решений</span><span>96 соревнований</span><span>6 повторов каждого варианта</span></div></header>
<nav><a href="#answer">Результат</a><a href="#design">Камеры</a><a href="#brains">Мозги</a><a href="#duels">Битвы</a><a href="#rotators">Вращалка</a><a href="#limits">Оговорки</a><a href="#data">Данные</a></nav><main>
<section id="answer"><h2>Что получилось</h2>
<p><b>Идея с отдельной камерой полезна, но её сильная версия — новый мир для ребёнка.</b> Копия мира наследует уже расколотые родителем орехи. Это всё ещё помощь, хотя родитель живёт отдельно. Поэтому я проверил оба варианта.</p>
<p>У мозга <b>32</b> новые камеры дали в среднем <b>{fmt(new32)}</b> съеденного ореха в независимом одиночном испытании, общий мир — <b>{fmt(shared32)}</b>. Преимущество новых камер есть в <b>{paired} из 6</b> пар повторов. У <b>32 → 32</b> результат — <b>{fmt(new3232)}</b> против <b>{fmt(shared3232)}</b>. Это не гарантия превосходства для любой архитектуры: ниже показаны все результаты.</p>
<p><b>Больше нейронов не дало автоматического выигрыша.</b> Лучшее среднее по одиночной добыче здесь у <b>{al(besta)} · {LABEL[bestm]}</b>: {fmt(bestfood)} ореха. Это выбор лучшей ячейки из 12, а не доказанный универсальный чемпион.</p>
<div class="callout">Главная неприятность: обученные семьи всё ещё часто не съедают единственный целый орех перед собой за 300 тактов. Эволюция заметно улучшила питание в богатой орехами камере, но не превратила каждую особь в аккуратного решателя задач.</div>
{figure('final','Результаты одиночных испытаний для четырёх архитектур','Столбик — среднее шести независимых эволюций; точки — отдельные эволюции. Слева проверяется вся цепочка «расколоть → подойти → съесть», а не только выбор удара. Справа — доля испытаний с выживанием до лимита 5 000 тактов.')}
</section>
<section id="design"><h2>Три способа выращивать потомство</h2>
<div class="cards"><article><h3>Копия камеры</h3><p>Каждый живёт один на 16×16 с двумя деревьями. Ребёнок получает копию оставшейся еды и карты, появляется на месте родителя, затем живёт независимо.</p></article><article><h3>Новая камера</h3><p>Тот же отбор через размножение, но ребёнок получает случайную новую карту. Расколотые родителем орехи ему не достаются.</p></article><article><h3>Общий мир</h3><p>32 основателя на 32×32 с восемью деревьями. Потомки появляются рядом, орехами могут пользоваться все.</p></article></div>
<p>Во всех вариантах — 32 случайных основателя, цена удара 2, расход жизни 0,25 за такт, орех даёт 60 энергии, вероятность падения 0,04. Максимальный возраст 10 000, целый орех живёт 1 200, расколотый 400 тактов. Яда и готовых расколотых орехов при генерации нет. Ширина удара 3, длина 1. Это обычный мир с границами; сезонный тор используется в дополнительных проверках.</p>
<p>На каждый вариант выделено <b>10 млн решений особей</b>. 100 особей, проживших такт, расходуют 100 единиц бюджета. Это позволяет сравнивать одинаковое число взаимодействий с миром, хотя число поколений и затраты процессора различаются. Обучение здесь только эволюционное: наследование, мутации и отбор. Градиентного обучения по награде или демонстрациям нет.</p>
<details><summary>Ограничения популяции и перезапуски</summary><p>Максимум 64 комнаты или 64 особи в общем мире. Когда комнат становится больше 64, одна случайно удаляется, включая возможность удалить новорождённого. Это искусственный нейтральный отбор по вместимости. В общем мире штатный лимит просто откладывает рождение и не списывает энергию. Эти правила не идентичны.</p><p>Родитель в камере платит обычные 80 энергии; ребёнок начинает с 60. Потомок не успевает совершить действие в родительской комнате. Когда вымирает весь эксперимент, появляются 32 новых случайных основателя; бюджет не обнуляется. Пустые отдельные камеры не заселяются заново. Случайные семена 801–806; внутри одной архитектуры исходные мозги совпадают между тремя режимами.</p></details>
<h3>Как менялась способность жить одному</h3>
{figure('learning','Кривые обучения по независимым одиночным испытаниям','Каждые 2,5 млн решений замораживаем мозги и проверяем в новых одинаковых условиях: один агент, два дерева, 5 000 тактов, размножение запрещено. Линия — среднее, полупрозрачная зона — минимум–максимум шести эволюций, не доверительный интервал. В каждой точке 128 испытаний на эволюцию.')}
<div class="scroll"><table><thead><tr><th>Мозг</th><th>Обучение</th><th>Орехов одному<br>среднее / диапазон повторов</th><th>К случайным мозгам</th><th>Жив на 5 000</th><th>Один орех съеден</th><th>Орехов в засуху</th><th>Полных перезапусков*</th></tr></thead><tbody>{rows}</tbody></table></div>
<p class="muted">* Сумма по шести эволюциям. Засуха — вероятность падения 0,01 вместо 0,04. Статистика относится к финальным живым мозгам, а не к отобранным вручную лучшим особям. «Орехов» — за испытание, включая раннюю смерть; рост может означать и более долгую жизнь, и более быструю добычу.</p>
</section>
<section id="vision"><h2>Они действительно используют зрение?</h2><p>Те же финальные мозги, те же 128 одиночных испытаний на семейство, но все визуальные входы обнулены: орехи, стволы, границы и другие агенты больше не видны. Входы энергии и возраста сохранены. Геномы исходных популяций не менялись: обнулены только копии для проверки.</p><div class="scroll"><table><thead><tr><th>Источник</th><th>Орехов со зрением</th><th>Орехов без зрения</th><th>Снижение</th></tr></thead><tbody>{blindrows}</tbody></table></div><p><b>У новых камер 32 отключение зрения снизило добычу со 105,5 до 9,8 ореха: на 90,7%. У 32 → 32 — со 101,1 до 10,3: на 89,8%.</b></p><p>Падение добычи показывает зависимость успеха от визуальной информации в этой задаче. Оно не доказывает наличие планирования: достаточно полезной реакции на текущую картинку. Остаточная добыча без зрения может происходить за счёт случайных действий и устойчивых циклов поведения.</p></section>
<section id="brains"><h2>Что дали дополнительные слои</h2>
<p><b>32 → 32 — важный контроль.</b> Он добавляет глубину при небольшом увеличении числа весов. А 128 увеличивает в основном ширину первого слоя. Поэтому «два слоя» и «много параметров» — разные изменения, и результаты не стоит сводить к одному сравнению «маленький / большой».</p>
<div class="scroll"><table><thead><tr><th>Скрытые слои</th><th>Параметров</th><th>Один расчёт мозга*</th><th>16 мутаций / размер мозга</th></tr></thead><tbody>{benchrows}</tbody></table></div>
<p>* Медиана пяти измерений по 100 000 вызовов на Apple M1 Pro, одно фиксированное разреженное наблюдение, без мира и отрисовки. Это локальная стоимость прямого прохода, а не скорость всей игры и не результат для любого заполнения поля зрения.</p>
<p>Во всех новых сетях одинаковая схема инициализации Glorot, tanh в скрытых слоях, 733 входа и 6 выходных действий. На рождение приходится 16 случайных изменений весов с силой 0,25. <b>Для больших сетей это меньшая доля параметров.</b> Поэтому мы проверили эти архитектуры с текущим мутационным оператором Grove, а не выяснили предел возможностей каждого размера при индивидуальной настройке.</p>
<p>Ни один дополнительный слой не добавляет память о прошлом. Все четыре сети реагируют на текущее наблюдение. Они могут отличаться сложностью реакции, но не получают автоматически план или внутреннюю историю маршрута.</p>
</section>
<section id="duels"><h2>Самостоятельный не обязательно побеждает в толпе</h2>
<p>Для каждого обученного семейства — одна свежая арена 32×32, восемь деревьев, 16 особей против 16, случайное размещение и случайная выборка мозгов. 20 000 тактов, предел 128 жителей, размножение и мутации включены. Победа означает большую численность потомков в конце; это не турнир с отдельным контролем способностей к драке.</p>
<div class="scroll"><table><thead><tr><th>Мозг</th><th>Первый / второй участник</th><th>Победы / поражения / ничьи первого</th><th>Средняя доля первого в конце</th></tr></thead><tbody>{duelrows}</tbody></table></div>
<div class="callout">Успех в одиночной камере и успех в общей популяции — разные цели отбора. Соревнование само по себе не доказывает «паразитизм»: преимущество может происходить от скорости размножения, расхода энергии, движения и доступа к пище. Для доказательства присвоения чужой работы нужен учёт того, кто расколол каждый съеденный орех.</div>
<p><b>Самый наглядный пример — 32 → 32:</b> семейства общего мира победили и копируемые, и новые камеры в 6 из 6 соревнований каждого типа. При этом новая камера давала более высокую одиночную добычу. Это разные специализации, а не противоречие.</p><p>У каждой строки только шесть независимых обученных семейств и по одной арене на семейство. Этого хватает увидеть сильные различия в этой партии, но не оценить точный глобальный процент побед. «Вращалка» — одна сохранённая популяция другого возраста, а не равный по бюджету обучения соперник.</p>
</section>
<section id="main13"><h2>Дополнительная проверка: основная на 1,30 млн</h2>
<p>По твоему запросу проверена исходная <b>«Основная · 1,30 млн»</b>: 622 мозга, сохранение на такте 1 298 578. Те же условия, те же семена испытаний, 256 попыток на каждую обычную задачу и 128 на сезонном торе. Это новая проверка исторической популяции; она не входит в 72 эволюции с нуля.</p>
<div class="scroll"><table><thead><tr><th>Задача</th><th>Основная 1,30 млн</th><th>Вращалка</th></tr></thead><tbody>
<tr><td>Целый орех впереди, съели за 300 тактов</td><td>241/256 · 94,1%</td><td>256/256 · 100%</td></tr>
<tr><td>Целый орех перед стволом, съели</td><td>233/256 · 91,0%</td><td>256/256 · 100%</td></tr>
<tr><td>Расколотый орех впереди, съели</td><td>256/256 · 100%</td><td>256/256 · 100%</td></tr>
<tr><td>Время до еды с целым орехом, только успешные попытки</td><td>32,7 такта</td><td>3,1 такта</td></tr>
<tr><td>Один в обычном мире: орехов за испытание</td><td>61,8</td><td>2,4</td></tr>
<tr><td>Один в обычном мире: жив на 5 000</td><td>37,5%</td><td>0%</td></tr>
<tr><td>Засуха в обычном мире: орехов за испытание</td><td>25,7</td><td>1,8</td></tr>
<tr><td>Один на сезонном торе: орехов за испытание</td><td>67,0</td><td>6,2</td></tr>
<tr><td>Один на сезонном торе: жив на 5 000</td><td>49,2%</td><td>0%</td></tr>
</tbody></table></div>
<p><b>Все 241 особь, расколовшие единственный целый орех, затем его съели.</b> Оставшиеся 15 в этой постановке не раскололи его за отведённое время. Навык добычи у исходной популяции тоже развит, но «вращалка» исполняет его значительно быстрее.</p>
<p>По самостоятельному выживанию в этих аренах исходная популяция устойчивее «вращалки». Однако звание «самой приспособленной вообще» из этого не следует: новые камеры 32 дали больше еды в обычном одиночном мире (105,5 против 61,8), а основная 1,30 млн дала больше при засухе (25,7 против 22,6). Преимущество зависит от условий. Сезонный тест — маленький тор 16×16, а не исходная большая среда «вращалки».</p>
</section>
<section id="rotators"><h2>Что на самом деле делает «1.3 + 3 вращалка»</h2>
<p>Взята именно сохранённая популяция с этим названием: <b>315 мозгов, сохранение на такте 2 658 308</b>. В одиночных микрозадачах она съела целый орех перед собой в <b>{fmt(rot['nut']['success'])}%</b> из 256 испытаний. Рядом со стволом — {fmt(rot['nut_tree']['success'])}%. Это конкретная отработанная цепочка действий: здесь она заметно точнее новых семейств.</p>
<p>Но перенос в обычную маленькую камеру дал только <b>{fmt(rot['solo']['food'])}</b> съеденного ореха за испытание и <b>{fmt(rot['solo']['ticks'])}</b> наблюдаемых тактов жизни. При этом меняется сразу несколько условий: появляются границы, отключаются компас и температура, меняется геометрия пищи. Поэтому вывод «сама добывать не умеет» был бы неверным.</p>
<h3>Проверка без этой части подмены условий</h3>
<p>Дополнительная арена 16×16 — сезонный тор с компасом и температурой, два дерева, сезон 3 000, один агент, лимит 5 000 тактов, размножение запрещено. Это тоже перенос в новый маленький мир, а не восстановление её исходного эксперимента.</p>
<div class="scroll"><table><thead><tr><th>Источник мозга</th><th>Орехов одному на торе</th><th>Жив на 5 000</th></tr></thead><tbody>{torusrows}</tbody></table></div>
<h3>Ствол действительно удерживает. С теплом всё сложнее</h3>
<p>Чтобы отделить влияние дерева от еды, я убрал все орехи и их падение. Одна особь на торе 64×64 начинает в трёх клетках от дерева; парный контроль — та же точка без дерева. Температуру принудительно удерживаем на 0 или 1. Каждый из 315 мозгов проверен в четырёх направлениях: <b>5 040 испытаний по 300 тактов</b>.</p>
{figure('tree','Влияние дерева и температуры на удержание и движение','Слева — сколько тактов агент находился в квадрате ±5 клеток от исходной точки дерева; без дерева считаем относительно той же точки. Справа — подписанное смещение на восток без обнуления при переходе через край. Это средние по мозгам одной родственной популяции, а не по независимым эволюциям.')}
<p>Без дерева они находятся рядом с исходной точкой около 14–15 тактов из 300. С деревом — около 113–127. Значит, твоя наблюдаемая привязанность к стволу не выдумка: еда для неё не обязательна. Но в этом контроле <b>холод не заставил их быстрее покинуть дерево</b>; среднее смещение на восток, наоборот, больше в тепле.</p>
<p>Это не опровергает твои наблюдения в полном мире. Там меняются сразу температура, запас орехов, энергия, соседи и положение деревьев. Результат говорит более узко: простая гипотеза «один сигнал холода включает уход от ствола» этим тестом не подтверждается.</p>
<h3>Отключение чувств в полном сезонном мире</h3>
<p>Ещё 24 эволюционирующих мира: шесть семян на каждый вариант, 128×128, 90 деревьев, 32 основателя из первых 32 мозгов пресета, 12 000 тактов. Либо все чувства, либо температура всегда 0,5, либо невидимые стволы, либо выключенный компас. Сами деревья и сезоны остаются.</p>
{figure('ablations','Численность с отключёнными сенсорами','Среднее шести миров; зоны — диапазон минимум–максимум. Сохранённые мозги одинаковы, меняются семена мира. Потомки мутируют, поэтому результат включает возможную адаптацию к вмешательству.')}
<div class="scroll"><table><thead><tr><th>Условие</th><th>Живых в конце, среднее</th><th>Съедено за мир, среднее</th></tr></thead><tbody>{seasonrows}</tbody></table></div>
<p>Ни одно отключение не вызвало общего краха в этой среде. Это не означает, что чувства не используются: избыток локальных ориентиров и общий доступ к еде могут компенсировать потерю одного канала, а суммарная добыча упирается в ресурс мира.</p>
</section>
<section id="limits"><h2>Где легко обмануться</h2><ul>
<li><b>128 испытаний ≠ 128 независимых эволюций.</b> Мозги внутри семьи близкие родственники, иногда один мозг проверяется несколько раз. Независимых запусков каждого метода шесть.</li>
<li><b>Одинаковый бюджет решений ≠ одинаковая экология.</b> В камерах еды на особь больше, нет соседей, другие границы и правила ограничения числа потомков. Мы сравниваем целые режимы обучения, а не выделяем единственную причину улучшения.</li>
<li><b>Оценочные миры не отбирали родителей.</b> Их семена одинаковы между методами и отличаются от обучения. Но фиксированный набор тестов — ограниченная проверка обобщения, не все возможные миры.</li>
<li><b>Во время одиночной проверки размножение отключено.</b> Энергия на ребёнка не списывается, поэтому выживать легче, чем при обучении. Это одинаково для всех тестируемых мозгов.</li>
<li><b>Начальный запас еды есть.</b> В новых комнатах лежат целые орехи от штатной генерации мира. Проверка не требует ждать первого падения. В микрозадаче с одним орехом другой еды нет.</li>
<li><b>5 000 тактов — потолок наблюдения.</b> Выжившие могли бы жить дольше; среднее наблюдаемое время не равно полной продолжительности жизни. Для сравнения показаны доля доживших и добыча.</li>
<li><b>Битвы с «вращалкой» проходят с границами.</b> Это проверка переноса и конкуренции в заданной арене; она не ранжирует её исходное сезонное поведение.</li>
</ul>
<h3>Что я бы пробовал дальше</h3>
<p>Для обучения самостоятельности я бы оставил новые камеры и начал с <b>32 или 32 → 32</b>. Дорогие 128 сейчас не выглядят обязательными. Следующая полезная ступень — разнообразить именно стартовые запасы и расстояние до еды: часть новых камер с одним доступным целым орехом, часть с редкой пищей. Это уменьшит возможность выживать за счёт бессистемных действий среди густо рассыпанной еды. Но это предложение следующего эксперимента, а не уже проверенный рецепт.</p>
<p>Отдельно стоит повторить сравнение с настройкой мутаций для каждого размера сети. Текущий результат отвечает «что происходит с нынешними 16 изменениями на ребёнка», а не «какая архитектура лучше вообще».</p>
</section>
<section id="data"><h2>Проверить и повторить</h2><p>Сохранены исходные и финальные мозги, промежуточные снимки, рождения, мутации, смерти, удаления по лимиту и перезапуски. Рабочие файлы лежат локально в <code>outputs/chambers/</code>; основная симуляция и пользовательские пресеты не перезаписаны.</p><div class="downloads"><a href="analysis.json">Сводные данные JSON</a><a href="experiment-data.zip">Сырые испытания и код ZIP</a><a href="../">Предыдущие отчёты</a></div><p>Архив содержит результаты проверок и исходники исследовательского запуска. Полные большие геномы и журналы эволюций остаются на Mac. Воспроизведение новых семейств начинается с указанных семян; сохранённая пользовательская «вращалка» в публичный архив не включена.</p></section>
</main><footer>Эксперимент проведён на текущем ядре Grove. Все числа относятся к описанным условиям; слова «умнее» и «лучше» без указания задачи здесь намеренно не используются.</footer>
'''
css='''*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:65px}body{margin:0;background:#f2f5ee;color:#253c32;font:16px/1.7 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}header,main,footer{max-width:1120px;margin:auto;padding:32px 28px}header{padding-top:55px}h1{font-size:clamp(36px,6vw,66px);line-height:1.08;letter-spacing:-2px;margin:22px 0}h1 em{font-style:normal;color:#188065}.eyebrow{font:11px/1.5 ui-monospace,monospace;letter-spacing:1px;color:#5d7769}.lead{font-size:20px;max-width:850px;color:#577064}h2{font-size:30px;line-height:1.25;letter-spacing:-.6px}h3{font-size:21px;line-height:1.3}p{max-width:980px}a{color:#08775d}nav{position:sticky;top:0;z-index:2;background:#173f32;display:flex;justify-content:center;gap:10px;overflow:auto;padding:9px;white-space:nowrap}nav a{font-size:13px;color:#f0f5eb;text-decoration:none;padding:5px 9px}section{border-bottom:1px solid #ccd9ca;padding:15px 0 30px}.badges,.downloads{display:flex;flex-wrap:wrap;gap:8px}.badges span{background:#e0ebdc;border-radius:4px;padding:5px 10px;font-size:12px}.callout{border-left:4px solid #248c6b;background:#e2eddf;padding:19px 23px;margin:24px 0}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.cards article{background:#e4edde;border:1px solid #cddcc7;border-radius:8px;padding:18px}.cards h3{margin-top:0}.cards p{font-size:14px;margin-bottom:0}figure{background:#f7f9f3;border:1px solid #d6dfd0;border-radius:9px;margin:26px 0;padding:15px}figure img{display:block;width:100%;height:auto}figcaption,.muted{font-size:13px;color:#5d7265;line-height:1.5}figcaption{padding:10px 0 2px}.scroll{overflow:auto;border:1px solid #d3ddcf;border-radius:7px;margin:22px 0}table{border-collapse:collapse;width:100%;background:#fafbf7;font-size:13px;line-height:1.5}td,th{text-align:left;padding:10px 12px;border-bottom:1px solid #dde5d8}th{background:#e2ebdc}td small{display:block;color:#758374}td:first-child{white-space:nowrap}details{background:#e8eee1;padding:17px;border-radius:8px}summary{cursor:pointer;font-weight:600}li{margin:13px 0}code{font-size:12px;overflow-wrap:anywhere}.downloads a{background:#194f3c;color:white;padding:10px 15px;border-radius:5px;text-decoration:none;font-size:13px}footer{font-size:13px;color:#6d8072;padding-bottom:60px}@media(max-width:640px){header,main,footer{padding:24px 17px}h1{letter-spacing:-1px}h2{font-size:26px}.lead{font-size:18px}.cards{grid-template-columns:1fr}nav{justify-content:flex-start}.callout{padding:15px}figure{margin:24px -9px;padding:5px}figcaption{padding:10px}body{font-size:15px}td,th{padding:9px}ul{padding-left:20px}}'''
(SITE/'index.html').write_text('<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Grove — камеры, четыре мозга и самостоятельность</title><meta name="description" content="72 эволюции: 32, 32→32, 128, 128→32; одиночные камеры, соревнования и поведение у дерева."><style>'+css+'</style></head><body>'+body+'</body></html>')
shutil.copy(R/'analysis.json',SITE/'analysis.json')
with zipfile.ZipFile(SITE/'experiment-data.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 z.write('examples/chambers.rs','source/examples/chambers.rs')
 for p in (R/'sources').glob('*'):
  if p.is_file():z.write(p,'source/'+('src/' if p.suffix=='.rs' else '')+p.name)
 for p in R.glob('*.py'):z.write(p,'source/outputs/chambers/'+p.name)
 if (R/'REPRODUCE.md').exists():z.write(R/'REPRODUCE.md','source/REPRODUCE.md')
 z.write(R/'source-hashes.json','source/source-hashes.json')
 for p in list(R.glob('*/eval.json'))+list(R.glob('*/initial-eval.json'))+list(R.glob('*/torus-eval.json'))+list(R.glob('*/blind-eval.json'))+list(R.glob('*/learning-*.json'))+list(R.glob('*/summary.json'))+list((R/'duels').glob('*.json'))+list(R.glob('rotators-*.json'))+[R/'main13-eval.json',R/'main13-torus-eval.json',R/'analysis.json',R/'benchmark.json']:
  if p.name=='rotators-source.json' or '-701/' in str(p):continue
  if p.exists():z.write(p,'data/'+str(p.relative_to(R)))
print('Report ready:',SITE)
