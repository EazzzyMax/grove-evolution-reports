import json,subprocess,concurrent.futures,os,time
from pathlib import Path
D=Path('outputs/islands');pending=set(json.load(open(D/'selection.json'))['selected'])
def run(job):
 tag,seed,swap=job;env=os.environ.copy();env['ISLAND_WORLD']=str(D/'transfer'/f'{tag}-large-final.json');env['ISLAND_TAG']=tag+'-grown'
 r=subprocess.run(['target/release/examples/island_duel','duel','normal',str(seed),str(swap),'20000','frozen'],env=env,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stderr)
 return r.stdout.strip()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as e:
 futures=[]
 while pending:
  for tag in sorted(list(pending)):
   if not (D/'transfer'/f'{tag}-large-final.json').exists():continue
   pending.remove(tag)
   for seed in range(1,6):
    for swap in range(2):futures.append(e.submit(run,(tag,seed,swap)))
  if pending:time.sleep(3)
 for i,f in enumerate(concurrent.futures.as_completed(futures)):print(i+1,f.result(),flush=True)
