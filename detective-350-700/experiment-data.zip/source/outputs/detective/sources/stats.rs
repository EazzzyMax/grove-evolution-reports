use serde::{Deserialize, Serialize};
#[derive(Clone, Default, Serialize, Deserialize)]
pub struct Travel { pub steps: u64, pub east: i64 }
#[derive(Clone, Default, Serialize, Deserialize)]
pub struct Bucket {
    #[serde(default)]
    pub distributions: std::collections::BTreeMap<usize, [f64;3]>,
    #[serde(default)]
    pub individuals: std::collections::BTreeMap<u64, [u64;7]>,
    #[serde(default)]
    pub life_samples: Vec<[f64;3]>,
    pub start: u64, pub end: u64, pub period: u64,
    pub agent_ticks: u64, pub strikes: u64, pub useful: u64, pub cracked: u64,
    pub eaten: u64, pub attempts: u64, pub steps: u64,
    pub age_samples: Vec<u32>,
    pub deaths: u64, pub ages: u64, pub children: u64, pub childless: u64,
    pub travel_deaths: u64, pub life_steps: u64, pub east: i64,
    pub births: u64, pub population: usize,
}
#[derive(Clone, Default, Serialize, Deserialize)]
pub struct Stats { pub current: Bucket, pub history: Vec<Bucket> }
impl Stats {
    pub fn begin(&mut self, tick: u64, period: u64) {
        if self.current.period != period {
            if self.current.end > self.current.start { self.flush(); }
            self.current = Bucket { start: tick.saturating_sub(1), end: tick.saturating_sub(1), period, ..Default::default() };
        }
    }
    pub fn finish(&mut self, tick: u64, population: usize) {
        self.current.end = tick; self.current.population = population;
        if tick.saturating_sub(self.current.start) >= self.current.period { self.flush(); }
    }
    fn flush(&mut self) {
        let b=&mut self.current;
        for metric in [0,1,5,6,7,8] {
            let samples:Vec<f64>=b.individuals.values().filter_map(|v|match metric {
                0=>ratio(v[2],v[1]).map(|x|x*100.0), 1=>ratio(v[3],v[1]),
                5=>Some(v[4] as f64),6=>ratio(v[4],v[0]).map(|x|x*1000.0),
                7=>ratio(v[6],v[0]).map(|x|x*1000.0),_=>ratio(v[5]-v[6],v[5]).map(|x|x*100.0)
            }).collect();
            if let Some(d)=distribution(samples) {b.distributions.insert(metric,d);}
        }
        for (metric,column) in [(3,0),(9,1),(10,2)] {
            if let Some(d)=distribution(b.life_samples.iter().map(|v|v[column]).filter(|v| if metric==9 {*v>=0.0} else if metric==10 {*v!=f64::MIN} else {true}).collect()) {b.distributions.insert(metric,d);}
        }
        if let Some(d)=distribution(b.age_samples.iter().map(|&v|v as f64).collect()) {b.distributions.insert(2,d);}
        b.individuals.clear(); b.life_samples.clear();
        let next = Bucket { start: self.current.end, end: self.current.end, period: self.current.period, ..Default::default() };
        self.history.push(std::mem::replace(&mut self.current, next));
    }
}
pub fn ratio(a: u64,b: u64) -> Option<f64> { (b>0).then(|| a as f64/b as f64) }
pub fn series(b: &Bucket, metric: usize) -> Option<f64> {
    match metric {
        0 => ratio(b.useful,b.strikes).map(|v|100.0*v),
        1 => ratio(b.cracked,b.strikes),
        2 => ratio(b.ages,b.deaths),
        3 => ratio(b.children,b.deaths),
        4 => ratio(b.childless,b.deaths).map(|v|100.0*v),
        5 => Some(b.eaten as f64),
        6 => ratio(b.eaten,b.agent_ticks).map(|v|1000.0*v),
        7 => ratio(b.steps,b.agent_ticks).map(|v|1000.0*v),
        8 => ratio(b.attempts.saturating_sub(b.steps),b.attempts).map(|v|100.0*v),
        9 => ratio(b.life_steps,b.travel_deaths),
        10 => (b.travel_deaths>0).then(||b.east as f64/b.travel_deaths as f64),
        13 => Some(b.births as f64),
        14 => Some(b.deaths as f64),

        _ => Some(b.population as f64),
    }
}
#[cfg(test)] mod tests {
    use super::*;
    #[test] fn season_windows_and_missing_data() {
        let mut s=Stats::default();
        for tick in 1..=3000 {s.begin(tick,3000);s.current.strikes+=1;s.finish(tick,10);}
        assert_eq!(s.history.len(),1); assert_eq!(s.history[0].strikes,3000);
        assert_eq!(series(&s.history[0],2),None);
        s.begin(3001,3000); s.finish(3001,10);
        s.begin(3002,1000); assert_eq!(s.history.len(),2);
        assert_eq!(s.current.start,3001); assert_eq!(s.current.period,1000);
    }
}

// Linear-interpolated quantiles: top-10 threshold is Q90, top-90 is Q10.
pub fn distribution(mut values: Vec<f64>) -> Option<[f64;3]> {
    if values.is_empty() {return None;}
    values.sort_by(f64::total_cmp);
    let q=|p:f64| {let i=(values.len()-1) as f64*p;let lo=i.floor() as usize;let hi=i.ceil() as usize;values[lo]+(values[hi]-values[lo])*(i-lo as f64)};
    Some([q(0.9),values.iter().sum::<f64>()/values.len() as f64,q(0.1)])
}
pub fn lines(b:&Bucket,metric:usize)->[Option<f64>;3] {
    if let Some(d)=b.distributions.get(&metric) {return d.map(Some);}
    if metric==2 {if let Some(d)=distribution(b.age_samples.iter().map(|&v|v as f64).collect()) {return d.map(Some);}}
    [None,if metric==5 {None} else {series(b,metric)},None]
}

#[cfg(test)] mod quantile_tests {
    use super::*;
    #[test] fn thresholds_are_not_tail_averages() {
        let d=distribution((0..=100).map(|v|v as f64).collect()).unwrap();
        assert_eq!(d,[90.0,50.0,10.0]);
        assert_eq!(distribution(vec![7.0]),Some([7.0;3]));
        assert_eq!(distribution(vec![]),None);
    }
    #[test] fn individual_ratios_and_saved_history() {
        let mut s=Stats::default(); s.begin(1,1);
        s.current.individuals.insert(1,[10,10,10,20,4,10,10]);
        s.current.individuals.insert(2,[10,1,0,0,0,10,0]);
        s.finish(1,2);
        assert_eq!(lines(&s.history[0],0),[Some(90.0),Some(50.0),Some(10.0)]);
        let saved=serde_json::to_vec(&s).unwrap();let loaded:Stats=serde_json::from_slice(&saved).unwrap();
        assert_eq!(lines(&loaded.history[0],0),lines(&s.history[0],0));
        assert!(loaded.history[0].individuals.is_empty());
    }
}
