import concurrent.futures,subprocess,pathlib
r=pathlib.Path('outputs/barbarians');e='target/release/examples/barbarian_probe'
jobs=[(mode,p,name) for mode in ['clutter','poison'] for p,name in [(r/'source.json','barbarians'),(pathlib.Path('outputs/detective/target.json'),'350700')]]
def run(j):
 mode,p,name=j;subprocess.run([e,mode,str(p),str(r/f'{name}-{mode}.json')],check=True);return name,mode
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
 for result in pool.map(run,jobs):print(result,flush=True)
