//! Headless research only. Does not modify Grove checkpoints or installed presets.
#![allow(dead_code)]
#[path="../src/brain.rs"] mod brain;
#[path="../outputs/detective/sources/sim_research.rs"] mod sim;
#[path="../src/stats.rs"] mod stats;
use brain::*;use sim::*;
use rand::{Rng,SeedableRng,seq::SliceRandom};use rand_chacha::ChaCha8Rng;
use serde::{Serialize,Deserialize};use serde_json::json;
use std::{fs::{self,File},io::{BufReader,BufWriter,Write},time::Instant};
const OUT:&str="outputs/chambers";
#[derive(Clone,Serialize,Deserialize)] struct Pool {name:String,brains:Vec<Brain>}
fn write_json<T:Serialize>(path:&str,v:&T){let mut f=BufWriter::new(File::create(path).unwrap());serde_json::to_writer(&mut f,v).unwrap();f.flush().unwrap();}
fn pool(path:&str)->Pool {let v:serde_json::Value=serde_json::from_reader(BufReader::new(File::open(path).unwrap())).unwrap();let mut b:Vec<Brain>=serde_json::from_value(v["brains"].clone()).unwrap();for b in &mut b {upgrade(b);assert!(b.valid());} Pool{name:v["name"].as_str().or_else(||v["info"]["name"].as_str()).unwrap_or("pool").into(),brains:b}}
fn cfg(seed:u64,mode:&str)->Config {Config{size:if mode=="shared"{32}else{16},initial_population:if mode=="shared"{32}else{1},trees:if mode=="shared"{8}else{2},seed,drop_chance:0.04,food_energy:60.0,strike_cost:2.0,metabolism:0.25,mutation:0.25,max_age:10000,nut_lifetime:1200,cracked_lifetime:400,ready_fraction:0.0,..Default::default()}}
fn compact(w:&mut World){w.lives.retain(|l|w.agents.iter().any(|a|a.id==l.id));for l in &mut w.lives{l.genome_base=None;}w.history.clear();w.lineage_history.clear();w.events.clear();w.stats=Default::default();}
fn put(w:&mut World,brains:&[Brain]) {for (i,a) in w.agents.iter_mut().enumerate(){a.brain=brains[i%brains.len()].clone();}compact(w);}
struct Room {w:World,uid:u64}
fn train(arch:&str,mode:&str,seed:u64,budget:u64){
 let layers:Vec<usize>=arch.split('-').map(|s|s.parse().unwrap()).collect();let name=format!("{mode}-{arch}-{seed}");let dir=format!("{OUT}/{name}");fs::create_dir_all(&dir).unwrap();
 let mut rng=ChaCha8Rng::seed_from_u64(seed^0x498EF);let mut roots=Vec::new();let mut rooms=Vec::new();let mut uid=0u64;
 let mut log=BufWriter::new(File::create(format!("{dir}/events.jsonl")).unwrap());
 let make=|rng:&mut ChaCha8Rng|Brain::configured(rng,&layers).unwrap();
 for _ in 0..32 {roots.push(make(&mut rng));}
 write_json(&format!("{dir}/initial.json"),&Pool{name:format!("initial-{arch}-{seed}"),brains:roots.clone()});
 if mode=="shared" {let mut w=World::new(cfg(seed,mode));put(&mut w,&roots);rooms.push(Room{w,uid:0});}
 else {for (i,b) in roots.iter().enumerate(){let mut w=World::new(cfg(seed.wrapping_mul(1000)+i as u64,mode));put(&mut w,std::slice::from_ref(b));uid+=1;rooms.push(Room{w,uid});}}
 writeln!(log,"{}",json!({"kind":"protocol","name":name,"budget_agent_ticks":budget,"cap":64,"config":cfg(seed,mode),"layers":layers,"root_rooms":32,"seed":seed})).unwrap();
 let started=Instant::now();let mut work=0;let mut births=0;let mut deaths=0;let mut culled=0;let mut restarts=0;let mut eaten=0;let mut cracked=0;let mut strikes=0;let mut max_gen=0;let mut next_checkpoint=budget/4;let mut history=Vec::new();let mut cycles=0u64;
 while work<budget {
  let mut newborns=Vec::new();let mut dead=Vec::new();
  for (ri,room) in rooms.iter_mut().enumerate(){
   if work>=budget {break;}
   let w=&mut room.w;let old=w.counters.clone();let old_n=w.agents.len();let old_id=w.next_id;let before=if mode=="shared" {None}else{Some((w.agents[0].age,w.agents[0].eaten,w.agents[0].cracked,w.agents[0].children,w.agents[0].generation,w.agents[0].x,w.agents[0].y))};
   work+=old_n as u64;w.step_with_population_limit(if mode=="shared"{64}else{2});
   births+=w.counters.births-old.births;deaths+=w.counters.deaths-old.deaths;eaten+=w.counters.eaten-old.eaten;cracked+=w.counters.cracked-old.cracked;strikes+=w.counters.strikes-old.strikes;
   for l in w.lives.iter().filter(|l|l.died==Some(w.tick)){writeln!(log,"{}",json!({"kind":"death","work":work,"room":room.uid,"id":l.id,"parent":l.parent,"born":l.born,"tick":w.tick,"cause":l.cause,"outcome":l.outcome})).unwrap();}
   for a in w.agents.iter().filter(|a|a.id>=old_id){max_gen=max_gen.max(a.generation);let mutations=w.lives.iter().find(|l|l.id==a.id).and_then(|l|l.mutations.as_ref());writeln!(log,"{}",json!({"kind":"birth","work":work,"room":room.uid,"id":a.id,"parent":a.parent,"generation":a.generation,"position":[a.x,a.y],"mutations":mutations})).unwrap();}
   if mode!="shared" && w.agents.len()==2 {
    let child=w.agents.pop().unwrap();let child_record=w.lives.iter().find(|l|l.id==child.id).cloned();compact(w);let mut fork=w.clone();
    let mut child=child;child.x=w.agents[0].x;child.y=w.agents[0].y;
    fork.agents=vec![child];if let Some(l)=child_record {fork.lives.push(l);}fork.rng=ChaCha8Rng::seed_from_u64(rng.random());compact(&mut fork);
    if mode=="fresh" {
        let mut fresh=World::new(cfg(rng.random(),mode));let mut child=fork.agents.pop().unwrap();
        child.x=fresh.agents[0].x;child.y=fresh.agents[0].y;fresh.next_id=child.id+1;fresh.agents=vec![child];fresh.lives.clear();fork=fresh;
    }
    uid+=1;writeln!(log,"{}",json!({"kind":"fork","work":work,"child_room":uid,"parent_room":room.uid})).unwrap();newborns.push(Room{w:fork,uid});
   }
   if w.agents.is_empty(){if let Some(b)=before{writeln!(log,"{}",json!({"kind":"room_death","work":work,"uid":room.uid,"age_before":b.0,"eaten_before":b.1,"cracked_before":b.2,"children":b.3,"generation":b.4})).unwrap();}dead.push(ri);}
   if cycles%500==0 {compact(w);}
  }
  for i in dead.into_iter().rev(){rooms.swap_remove(i);}
  rooms.extend(newborns);
  while rooms.len()>64 {let i=rng.random_range(0..rooms.len());writeln!(log,"{}",json!({"kind":"capacity_cull","uid":rooms[i].uid,"work":work})).unwrap();rooms.swap_remove(i);culled+=1;}
  if rooms.is_empty(){restarts+=1;let newroots:Vec<_>=(0..32).map(|_|make(&mut rng)).collect();write_json(&format!("{dir}/restart-{restarts}.json"),&Pool{name:format!("restart-{restarts}"),brains:newroots.clone()});
   if mode=="shared"{let mut w=World::new(cfg(rng.random(),mode));put(&mut w,&newroots);uid+=1;rooms.push(Room{w,uid});}
   else{for b in &newroots{let mut w=World::new(cfg(rng.random(),mode));put(&mut w,std::slice::from_ref(b));uid+=1;rooms.push(Room{w,uid});}}
   writeln!(log,"{}",json!({"kind":"restart","work":work,"restart":restarts,"first_room":rooms[0].uid})).unwrap();
  }
  if work>=next_checkpoint || work>=budget {
   let brains=rooms.iter().flat_map(|r|r.w.agents.iter().map(|a|a.brain.clone())).collect();
   write_json(&format!("{dir}/checkpoint-{}.json",history.len()+1),&Pool{name:name.clone(),brains});
   let rec=json!({"work":work,"alive":rooms.iter().map(|r|r.w.agents.len()).sum::<usize>(),"births":births,"deaths":deaths,"capacity_culls":culled,"restarts":restarts,"eaten":eaten,"cracked":cracked,"strikes":strikes,"generation":max_gen,"seconds":started.elapsed().as_secs_f64()});
   history.push(rec);log.flush().unwrap();next_checkpoint+=budget/4;
  }
  cycles+=1;
 }
 let finalpool=Pool{name:name.clone(),brains:rooms.iter().flat_map(|r|r.w.agents.iter().map(|a|a.brain.clone())).collect()};write_json(&format!("{dir}/final.json"),&finalpool);write_json(&format!("{dir}/summary.json"),&history);
 eprintln!("DONE {name} work={work} births={births} restarts={restarts} gen={max_gen} sec={:.1}",started.elapsed().as_secs_f64());
}
fn observe(w:&World,a:&Agent,temperature:Option<f32>)->Vec<(usize,f32)> {let mut occ=vec![false;w.cells.len()];for b in &w.agents{occ[w.config.index(b.x,b.y).unwrap()]=true;}let mut obs=Vec::new();World::observation_wrapped(w.config.size,&w.cells,&occ,a,w.config.max_age,w.config.seasonal,&mut obs);if w.config.seasonal {obs.push((VISUAL_INPUTS+6,temperature.unwrap_or_else(||w.config.fertility(a.x as usize,w.tick))));}obs}
fn probe(p:&Pool)->serde_json::Value {
 let mut records=Vec::new();
 for scene in ["empty","whole_ahead","ready_ahead","ready_under","poison_under","tree_ahead","tree_left","tree_right","tree_behind"] {
  for temp in [0.0,0.5,1.0] {for dir in 0..4 {
   let mut w=World::new(Config{size:32,initial_population:1,trees:0,seasonal:true,..Default::default()});w.agents[0].x=16;w.agents[0].y=16;w.agents[0].dir=dir;w.agents[0].energy=60.;w.agents[0].age=200;
   let (right,forward)=match scene{"tree_left"=>(-1,0),"tree_right"=>(1,0),"tree_behind"=>(0,-1),"ready_under"|"poison_under"=>(0,0),_=>(0,1)};
   let (x,y)=relative(&w.agents[0],right,forward);let i=w.config.index(x,y).unwrap();
   match scene {"whole_ahead"=>w.cells[i].nut=1,"ready_ahead"|"ready_under"=>w.cells[i].nut=2,"poison_under"=>w.cells[i].nut=3,s if s.starts_with("tree")=>w.cells[i].tree=true,_=>{}}
   let obs=observe(&w,&w.agents[0],Some(temp));let mut probabilities=[0.0f64;6];
   for b in &p.brains {for (j,v) in Brain::probabilities(b.forward(&obs,&mut [0.;32])).iter().enumerate(){probabilities[j]+=*v as f64/p.brains.len() as f64;}}
   records.push(json!({"scene":scene,"temperature":temp,"direction":dir,"p":probabilities}));
  }}
 }
 json!({"name":p.name,"n":p.brains.len(),"records":records})
}
fn scenario(brain:&Brain,seed:u64,scene:&str)->World {
 let mut c=cfg(seed,"solo");c.seasonal=scene.ends_with("torus");c.initial_population=1;c.trees=if scene=="solo"||scene=="drought"||scene.ends_with("torus"){2}else{0};c.drop_chance=if scene=="drought"||scene=="drought_torus"{0.01}else if scene=="solo"||scene=="torus"{0.04}else{0.0};
 let mut w=World::new(c);put(&mut w,std::slice::from_ref(brain));
 if scene!="solo"&&scene!="drought"&&!scene.ends_with("torus") {
  w.agents[0].x=8;w.agents[0].y=8;w.agents[0].dir=0;w.agents[0].energy=120.0;
  let i=7*16+8;w.cells[i].nut=if scene=="ready"{2}else{1};w.cells[i].ttl=1200;
  if scene=="nut_tree" {w.cells[6*16+8].tree=true;}
  w.validate().unwrap();
 }
 w
}
fn evaluate(p:&Pool,seed:u64,count:usize)->serde_json::Value {
 evaluate_scenes(p,seed,count,&["nut","ready","nut_tree","solo","drought"])
}
fn evaluate_scenes(p:&Pool,seed:u64,count:usize,scenes:&[&str])->serde_json::Value {
 let mut records=Vec::new();
 let mut chosen:Vec<_>=(0..p.brains.len()).collect();chosen.shuffle(&mut ChaCha8Rng::seed_from_u64(seed));
 for &scene in scenes {
  for n in 0..count {let bi=chosen[n%chosen.len()];let brain=&p.brains[bi];let mut w=scenario(brain,seed+n as u64,scene);let limit=if scene=="solo"||scene=="drought"||scene.ends_with("torus"){5000}else{300};let mut first_food=None;let mut first_crack=None;let mut east=0;let mut steps=0;
   for _ in 0..limit {if w.agents.is_empty(){break;}w.step_with_population_limit(1);if w.counters.eaten>0&&first_food.is_none(){first_food=Some(w.tick);}if w.counters.cracked>0&&first_crack.is_none(){first_crack=Some(w.tick);}if let Some(a)=w.agents.first(){if let Some(t)=&a.travel{east=t.east;steps=t.steps;}}}
   records.push(json!({"scene":scene,"trial":n,"brain":bi,"ticks":w.tick,"alive":!w.agents.is_empty(),"eaten":w.counters.eaten,"cracked":w.counters.cracked,"strikes":w.counters.strikes,"first_food":first_food,"first_crack":first_crack,"steps":steps,"east":east}));
  }
 }
 json!({"name":p.name,"records":records})
}
fn duel(a:&Pool,b:&Pool,seed:u64)->serde_json::Value {
 let mut w=World::new(Config{initial_population:32,..cfg(seed,"shared")});let mut order:Vec<_>=(0..32).collect();order.shuffle(&mut ChaCha8Rng::seed_from_u64(seed^0xabc));
 let mut sampling=ChaCha8Rng::seed_from_u64(seed^0xdef);let mut ai:Vec<_>=(0..a.brains.len()).collect();let mut bi:Vec<_>=(0..b.brains.len()).collect();ai.shuffle(&mut sampling);bi.shuffle(&mut sampling);
 for (j,&i) in order.iter().enumerate(){w.agents[i].brain=if j<16 {a.brains[ai[j%ai.len()]].clone()}else{b.brains[bi[(j-16)%bi.len()]].clone()};w.agents[i].lineage=if j<16{1}else{2};}compact(&mut w);
 let mut history=Vec::new();for tick in 0..20000 {if w.agents.is_empty(){break;}w.step_with_population_limit(128);if tick%1000==999{history.push(json!({"tick":w.tick,"a":w.agents.iter().filter(|a|a.lineage==1).count(),"b":w.agents.iter().filter(|a|a.lineage==2).count()}));compact(&mut w);}}
 json!({"a":a.name,"b":b.name,"seed":seed,"history":history})
}
fn seasonal(p:&Pool,seed:u64,condition:&str)->serde_json::Value {
 let mut w=World::new(Config{size:128,trees:90,initial_population:32,seasonal:true,season_period:3000,seed,food_energy:60.,drop_chance:0.04,strike_cost:2.,mutation:0.25,max_age:10000,..Default::default()});put(&mut w,&p.brains);
 let mut history=Vec::new();let mut states=std::collections::BTreeMap::<String,[f64;4]>::new();
 let mut previous_steps=0;let mut previous_east=0;
 for tick in 0..12000 {
  if w.agents.is_empty(){break;}
  // Keep statistics before each step; counters continue across checkpoint compaction.
  if tick%20==0 {for a in &w.agents {
   let t=w.config.fertility(a.x as usize,w.tick);let zone=if t<0.2{"cold"}else if t>0.8{"warm"}else{"edge"};
   let near=(-2..=2).any(|dy|(-2..=2).any(|dx|w.cells[w.config.index(a.x+dx,a.y+dy).unwrap()].tree));
   let row=states.entry(format!("{zone}_{}",if near{"tree"}else{"open"})).or_default();
   let obs=observe(&w,a,None);let ps=Brain::probabilities(a.brain.forward(&obs,&mut [0.;32]));
   row[0]+=1.;row[1]+=ps[0] as f64;row[2]+=ps[3] as f64;row[3]+=ps[4] as f64;
  }}
  w.step_with_sensor_filter(|_,obs|match condition {
   "no_temperature"=>{for (i,v) in obs {if *i==611 {*v=0.5;}}},
   "no_trees"=>obs.retain(|(i,_)|!(*i<VISUAL_INPUTS && *i%5==1)),
   "no_compass"=>obs.retain(|(i,_)|!(*i>=607 && *i<=610)),_=>{}
  });
  let b=&w.stats.current;previous_steps=b.steps;previous_east=b.east;
  if tick%500==499 {history.push(json!({"tick":w.tick,"alive":w.agents.len(),"births":w.counters.births,"eaten":w.counters.eaten,"cracked":w.counters.cracked,"mean_x":w.agents.iter().map(|a|a.x as f64).sum::<f64>()/w.agents.len().max(1) as f64,"agent_ticks":b.agent_ticks,"steps":b.steps,"live_mean_east":w.agents.iter().map(|a|a.travel.as_ref().map_or(0,|t|t.east) as f64).sum::<f64>()/w.agents.len().max(1) as f64}));compact(&mut w);}
 }
 json!({"name":p.name,"seed":seed,"condition":condition,"ticks":w.tick,"alive":w.agents.len(),"counters":w.counters,"history":history,"states":states,"last_steps":previous_steps,"last_death_east":previous_east})
}
fn residence(p:&Pool)->serde_json::Value {
 let mut records=Vec::new();
 for tree in [false,true] {for temp in [0.0,1.0] {for dir in 0..4 {for (bi,b) in p.brains.iter().enumerate() {
  let mut w=World::new(Config{size:64,initial_population:1,trees:0,seasonal:true,drop_chance:0.,seed:4400+bi as u64,metabolism:0.25,strike_cost:2.,..Default::default()});
  w.agents[0].brain=b.clone();w.agents[0].x=35;w.agents[0].y=32;w.agents[0].dir=dir;if tree {w.cells[32*64+32].tree=true;}w.validate().unwrap();
  let mut near=0;let mut east=0;let mut steps=0;let mut actions=[0u32;6];
  for _ in 0..300 {if w.agents.is_empty(){break;}
   let a=&w.agents[0];let dx=(a.x-32).abs().min(64-(a.x-32).abs());let dy=(a.y-32).abs().min(64-(a.y-32).abs());if dx<=5&&dy<=5 {near+=1;}
   w.step_with_sensor_filter(|_,obs|{for (i,v) in obs{if *i==611 {*v=temp;}}});
   if let Some(a)=w.agents.first(){actions[a.action]+=1;if let Some(t)=&a.travel{east=t.east;steps=t.steps;}}
  }
  records.push(json!({"tree":tree,"temperature":temp,"direction":dir,"brain":bi,"near":near,"ticks":w.tick,"east":east,"steps":steps,"actions":actions}));
 }}}}
 json!({"name":p.name,"records":records})
}
fn benchmark()->serde_json::Value {
 let mut records=Vec::new();
 for rep in 0..5 {for layers in [vec![32],vec![128],vec![128,32],vec![32,32]] {
  let mut rng=ChaCha8Rng::seed_from_u64(111);let b=Brain::configured(&mut rng,&layers).unwrap();
  let mut w=World::new(cfg(444,"solo"));put(&mut w,std::slice::from_ref(&b));let obs=observe(&w,&w.agents[0],None);let mut hidden=[0.;32];
  let start=Instant::now();for _ in 0..100000 {std::hint::black_box(b.forward(std::hint::black_box(&obs),&mut hidden));}
  records.push(json!({"layers":layers,"rep":rep,"weights":b.weights.len(),"active_inputs":obs.len(),"calls":100000,"seconds":start.elapsed().as_secs_f64()}));
 }} json!({"records":records})
}
fn legacy_main(){rayon::ThreadPoolBuilder::new().num_threads(1).build_global().unwrap();let args:Vec<_>=std::env::args().collect();match args[1].as_str(){
 "benchmark"=>write_json(&args[2],&benchmark()),
 "train"=>train(&args[2],&args[3],args[4].parse().unwrap(),args[5].parse().unwrap()),
 "eval"=>{let p=pool(&args[2]);write_json(&args[3],&evaluate(&p,900001,args.get(4).map_or(64,|s|s.parse().unwrap())));},
 "blind_eval"=>{let mut p=pool(&args[2]);for b in &mut p.brains {let n=b.layers.as_ref().expect("configured brain")[0];for input in (0..VISUAL_INPUTS).chain(POISON_INPUT..SENSOR_COUNT){b.weights[input*n..(input+1)*n].fill(0.0);}}write_json(&args[3],&evaluate_scenes(&p,900001,128,&["solo"]));},
 "learning_eval"=>{let p=pool(&args[2]);write_json(&args[3],&evaluate_scenes(&p,900001,128,&["solo"]));},
 "torus_eval"=>{let p=pool(&args[2]);write_json(&args[3],&evaluate_scenes(&p,900001,128,&["torus","drought_torus"]));},
 "probe"=>{let p=pool(&args[2]);write_json(&args[3],&probe(&p));},
 "residence"=>{let p=pool(&args[2]);write_json(&args[3],&residence(&p));},
 "seasonal"=>{let p=pool(&args[2]);write_json(&args[5],&seasonal(&p,args[3].parse().unwrap(),&args[4]));},
 "duel"=>{let a=pool(&args[2]);let b=pool(&args[3]);write_json(&args[5],&duel(&a,&b,args[4].parse().unwrap()));},
 _=>panic!("train/eval/probe/duel")}}

#[cfg(test)] mod research_tests {
 use super::*;
 #[test] fn fork_keeps_one_agent_and_does_not_share_future_food(){
  let mut w=World::new(cfg(5,"solo"));w.agents[0].energy=220.;w.agents[0].age=60;w.step_with_population_limit(2);assert_eq!(w.agents.len(),2);
  let child=w.agents.pop().unwrap();let mut fork=w.clone();fork.agents=vec![child];fork.rng=ChaCha8Rng::seed_from_u64(66);
  assert_eq!(w.agents.len(),1);assert_eq!(fork.agents.len(),1);assert_eq!(w.cells.iter().map(|c|c.nut).collect::<Vec<_>>(),fork.cells.iter().map(|c|c.nut).collect::<Vec<_>>());
  let i=w.cells.iter().position(|c|c.nut==1).unwrap();fork.cells[i].nut=0;assert_eq!(w.cells[i].nut,1);
  assert_eq!(fork.agents[0].energy,60.);assert!(w.agents[0].energy<140.1);
 }
 #[test] fn diagnostic_can_complete_crack_move_eat(){
  let b=Brain::configured(&mut ChaCha8Rng::seed_from_u64(1),&[32]).unwrap();let mut w=scenario(&b,1,"nut");w.control=Some(w.agents[0].id);
  w.teach_step(3);assert_eq!(w.cells[7*16+8].nut,2);w.teach_step(0);w.teach_step(4);assert_eq!(w.counters.eaten,1);
 }
}

fn masked(b:&Brain,kind:&str)->Brain {
 let mut out=b.clone();let n=out.layers.as_ref().map_or(HIDDEN,|l|l.first().copied().unwrap_or(OUTPUTS));
 for i in 0..SENSOR_COUNT {
  let remove=match kind {"blind"=>i<VISUAL_INPUTS||i>=POISON_INPUT,"no_wall"=>i<VISUAL_INPUTS&&i%5==0,"no_tree"=>i<VISUAL_INPUTS&&i%5==1,"no_whole"=>i<VISUAL_INPUTS&&i%5==2,"no_ready"=>i<VISUAL_INPUTS&&i%5==3,"no_agents"=>i<VISUAL_INPUTS&&i%5==4,"no_energy"=>i==VISUAL_INPUTS,_=>false};
  if remove {let k=if out.layers.is_some()||i<INPUTS{i*n}else{PARAMS+(i-INPUTS)*HIDDEN};out.weights[k..k+n].fill(0.);}
 }out
}
fn detective_world(b:&Brain,seed:u64,scene:&str)->World {
 let mut c=cfg(seed,"solo");
 match scene {
  "drought"=>c.drop_chance=0.01,"famine"=>c.drop_chance=0.002,"rich"=>c.drop_chance=0.16,
  "low_food"=>c.food_energy=10.,"high_food"=>c.food_energy=120.,
  "expensive"=>c.strike_cost=8.,"cheap"=>c.strike_cost=0.1,
  "whole_short"=>c.nut_lifetime=30,"ready_short"=>c.cracked_lifetime=15,"ttl100"=>{c.nut_lifetime=100;c.cracked_lifetime=100;},"cost20"=>c.strike_cost=20.,"short_ttl"=>{c.nut_lifetime=30;c.cracked_lifetime=15;},"long_ttl"=>{c.nut_lifetime=5000;c.cracked_lifetime=5000;},
  "poison"=>c.poison_chance=0.25,"wide"=>{c.strike_width=7;c.strike_length=3;},"narrow"=>c.strike_width=1,
  "sparse"=>c.size=64,"dense_trees"=>c.trees=8,_=>{}
 }
 let micro=scene.starts_with("micro_");if micro {c.trees=0;c.drop_chance=0.;}
 let mut w=World::new(c);let mb=masked(b,scene);put(&mut w,&[mb]);
 if micro {
  w.agents[0].x=8;w.agents[0].y=8;w.agents[0].dir=0;w.agents[0].energy=120.;
  let (x,y,nut)=match scene {
   "micro_nut"|"micro_tree"=>(8,7,1),"micro_far"=>(8,3,1),"micro_side"=>(11,8,1),"micro_behind"=>(8,11,1),
   "micro_ready"=>(8,7,2),"micro_under"=>(8,8,2),"micro_whole_under"=>(8,8,1),"micro_poison"=>(8,8,3),_=>(0,0,0)};
  if nut>0 {let i=y*16+x;w.cells[i].nut=nut;w.cells[i].ttl=1200;}
  if scene=="micro_tree" {w.cells[6*16+8].tree=true;}
  if scene=="micro_tree_empty" {w.cells[7*16+8].tree=true;}
  if scene=="micro_wall" {w.agents[0].y=0;}
  w.validate().unwrap();
 }w
}
fn battery(p:&Pool,count:usize)->serde_json::Value {
 let scenes=["solo","drought","famine","rich","low_food","high_food","expensive","cheap","short_ttl","long_ttl","poison","wide","narrow","sparse","dense_trees","helper","blind","no_tree","no_whole","no_ready","no_energy",
 "micro_nut","micro_tree","micro_far","micro_side","micro_behind","micro_ready","micro_under","micro_whole_under","micro_poison","micro_empty","micro_tree_empty","micro_wall"];
 let mut chosen:Vec<_>=(0..p.brains.len()).collect();chosen.shuffle(&mut ChaCha8Rng::seed_from_u64(770001));let mut records=Vec::new();
 for scene in scenes {for trial in 0..count {
  let bi=chosen[trial%chosen.len()];let seed=770001+trial as u64;let mut w=detective_world(&p.brains[bi],seed,scene);
  let limit=if scene.starts_with("micro_"){if scene=="micro_empty"||scene=="micro_tree_empty"||scene=="micro_wall"{1000}else{300}}else{5000};
  let mut first_food=None;let mut first_crack=None;let mut useful=0;let mut actions=[0u32;6];let mut near_tree=0;let mut alive_ticks=0;let mut steps=0;
  for _ in 0..limit {
   if w.agents.is_empty(){break;}
   if scene=="helper" {for cell in &mut w.cells {if cell.nut==1 {cell.nut=2;}}}
   let a=&w.agents[0];if (-2..=2).any(|dy|(-2..=2).any(|dx|w.config.index(a.x+dx,a.y+dy).is_some_and(|i|w.cells[i].tree))){near_tree+=1;}
   alive_ticks+=1;let old_cracked=w.counters.cracked;w.step_with_population_limit(1);if w.counters.cracked>old_cracked{useful+=1;}
   if w.counters.eaten>0&&first_food.is_none(){first_food=Some(w.tick);}if w.counters.cracked>0&&first_crack.is_none(){first_crack=Some(w.tick);}
   if let Some(a)=w.agents.first(){actions[a.action]+=1;steps=a.travel.as_ref().map_or(0,|t|t.steps);}
  }
  records.push(json!({"scene":scene,"trial":trial,"brain":bi,"seed":seed,"ticks":w.tick,"alive":!w.agents.is_empty(),"eaten":w.counters.eaten,"cracked":w.counters.cracked,"strikes":w.counters.strikes,"poisoned":w.counters.poisoned,"useful":useful,"first_food":first_food,"first_crack":first_crack,"steps":steps,"near_tree":near_tree,"alive_ticks":alive_ticks,"actions":actions,"energy":w.agents.first().map(|a|a.energy)}));
 }eprintln!("{} {scene} done",p.name);}
 json!({"name":p.name,"brains":p.brains.len(),"trials_per_scene":count,"records":records})
}
fn fingerprint(p:&Pool)->serde_json::Value {
 let mut records=Vec::new();
 for scene in ["empty","whole","ready","poison","tree","wall","neighbor"] {for distance in [0,1,2,3,4,5] {for energy in [20.,60.,120.,200.] {
  if distance==0&&(scene=="tree"||scene=="wall"||scene=="neighbor"){continue;}
  let mut w=World::new(Config{size:32,trees:0,initial_population:1,drop_chance:0.,max_age:10000,..cfg(4,"solo")});w.agents[0].x=16;w.agents[0].y=16;w.agents[0].dir=0;w.agents[0].energy=energy;w.agents[0].age=200;
  let i=(16-distance)*32+16;match scene {"whole"=>w.cells[i].nut=1,"ready"=>w.cells[i].nut=2,"poison"=>w.cells[i].nut=3,"tree"=>w.cells[i].tree=true,"wall"=>w.agents[0].y=distance as i32-1,_=>{}}
  let mut obs=observe(&w,&w.agents[0],None);
  if scene=="neighbor" {let row=RADIUS-distance as i32;obs.push(((row as usize*VISION+RADIUS as usize)*5+4,1.));}
  let mut sum=[0f64;6];let mut ps=Vec::new();for b in &p.brains {let pr=Brain::probabilities(b.forward(&obs,&mut [0.;32]));for j in 0..6 {sum[j]+=pr[j] as f64/p.brains.len() as f64;}ps.push(pr);}
  records.push(json!({"scene":scene,"distance":distance,"energy":energy,"mean":sum,"individual":ps}));
 }}}
 json!({"name":p.name,"records":records})
}
fn arena_config(seed:u64,scene:&str)->Config {
 let frozen=scene.starts_with("frozen_");let scene=scene.strip_prefix("frozen_").unwrap_or(scene);
 let mut c=cfg(seed,"shared");c.initial_population=32;c.size=32;c.trees=8;
 match scene {"drought"=>c.drop_chance=0.01,"expensive"=>c.strike_cost=8.,"whole_short"=>c.nut_lifetime=30,"ready_short"=>c.cracked_lifetime=15,"ttl100"=>{c.nut_lifetime=100;c.cracked_lifetime=100;},"cost20"=>c.strike_cost=20.,"cheap"=>c.strike_cost=0.1,"short_ttl"=>{c.nut_lifetime=30;c.cracked_lifetime=15;},"low_food"=>c.food_energy=10.,"poison"=>c.poison_chance=0.25,"wide"=>{c.strike_width=7;c.strike_length=3;},"dense"=>c.initial_population=128,_=>{}}if frozen {c.mutation=0.;}c
}
fn contest(a:&Pool,b:&Pool,seed:u64,scene:&str,swap:bool)->serde_json::Value {
 let mut w=World::new(arena_config(seed,scene));let mut rng=ChaCha8Rng::seed_from_u64(seed^444);let mut order:Vec<_>=(0..w.agents.len()).collect();order.shuffle(&mut rng);
 let mut ai:Vec<_>=(0..a.brains.len()).collect();let mut bi:Vec<_>=(0..b.brains.len()).collect();ai.shuffle(&mut rng);bi.shuffle(&mut rng);
 for (j,&i) in order.iter().enumerate(){let group=(j<w.agents.len()/2)^swap;w.agents[i].brain=if group{a.brains[ai[(j%(w.agents.len()/2))%ai.len()]].clone()}else{b.brains[bi[(j%(w.agents.len()/2))%bi.len()]].clone()};w.agents[i].lineage=if group{1}else{2};}
 compact(&mut w);let mut history=Vec::new();let mut own=[0u64;2];let mut other=[0u64;2];let mut unknown=[0u64;2];let mut self_food=[0u64;2];
 for _ in 0..10000 {
  if w.agents.is_empty(){break;}
  w.step_with_population_limit(256);
  for e in w.research_food.drain(..) {let g=(e[4]-1) as usize;if e[2]==e[4] {own[g]+=1;}else if e[2]!=0 {other[g]+=1;}else {unknown[g]+=1;}if e[1]==e[3]{self_food[g]+=1;}}
  if w.tick%500==0 {history.push(json!({"tick":w.tick,"a":w.agents.iter().filter(|a|a.lineage==1).count(),"b":w.agents.iter().filter(|a|a.lineage==2).count(),"own":own,"other":other,"unknown":unknown,"self_food":self_food}));compact(&mut w);}
 }
 json!({"a":a.name,"b":b.name,"seed":seed,"scene":scene,"swap":swap,"ticks":w.tick,"final_a":w.agents.iter().filter(|a|a.lineage==1).count(),"final_b":w.agents.iter().filter(|a|a.lineage==2).count(),"history":history,"own":own,"other":other,"unknown":unknown,"self_food":self_food})
}
fn focused(p:&Pool,count:usize)->serde_json::Value {
 let mut order:Vec<_>=(0..p.brains.len()).collect();order.shuffle(&mut ChaCha8Rng::seed_from_u64(880001));let mut records=Vec::new();
 for scene in ["normal","no_wall","whole_short","ready_short","ttl100","cost20","far_center","nut_wall","ready_wall"] {
  for trial in 0..count {
   let bi=order[trial%order.len()];let mut w=detective_world(&p.brains[bi],880001+trial as u64,scene);
   let micro=["far_center","nut_wall","ready_wall"].contains(&scene);
   if micro {
    w=World::new(Config{size:32,trees:0,initial_population:1,drop_chance:0.,..cfg(880001+trial as u64,"solo")});put(&mut w,&[p.brains[bi].clone()]);
    w.agents[0].x=16;w.agents[0].y=if scene=="far_center"{16}else{2};w.agents[0].dir=0;w.agents[0].energy=120.;
    let y=if scene=="far_center"{11}else{1};w.cells[y*32+16].nut=if scene=="ready_wall"{2}else{1};w.cells[y*32+16].ttl=1200;w.validate().unwrap();
   }
   let limit=if micro{300}else{5000};let mut first=None;for _ in 0..limit {if w.agents.is_empty(){break;}w.step_with_population_limit(1);if w.counters.eaten>0&&first.is_none(){first=Some(w.tick);}}
   records.push(json!({"scene":scene,"trial":trial,"brain":bi,"ticks":w.tick,"alive":!w.agents.is_empty(),"eaten":w.counters.eaten,"strikes":w.counters.strikes,"cracked":w.counters.cracked,"first_food":first}));
  }
 }json!({"name":p.name,"records":records})
}
fn micro_audit(p:&Pool)->serde_json::Value {
 let mut records=Vec::new();for scene in ["micro_nut","micro_whole_under","micro_side","micro_behind"] {for (bi,b) in p.brains.iter().enumerate(){for rep in 0..4 {
  let mut w=detective_world(b,720001+rep*10000+bi as u64,scene);let mut first=None;
  for _ in 0..300 {if w.agents.is_empty(){break;}w.step_with_population_limit(1);if w.counters.eaten>0 {first=Some(w.tick);break;}}
  records.push(json!({"scene":scene,"brain":bi,"rep":rep,"success":first.is_some(),"first_food":first}));
 }}}json!({"name":p.name,"records":records})
}
fn detective_main(){rayon::ThreadPoolBuilder::new().num_threads(1).build_global().unwrap();let a:Vec<_>=std::env::args().collect();match a[1].as_str(){
 "micro_audit"=>write_json(&a[3],&micro_audit(&pool(&a[2]))),
 "focused"=>write_json(&a[3],&focused(&pool(&a[2]),256)),
 "battery"=>write_json(&a[3],&battery(&pool(&a[2]),a.get(4).map_or(192,|x|x.parse().unwrap()))),
 "fingerprint"=>write_json(&a[3],&fingerprint(&pool(&a[2]))),
 "contest"=>write_json(&a[7],&contest(&pool(&a[2]),&pool(&a[3]),a[4].parse().unwrap(),&a[5],a[6]=="swap")),
 _=>panic!("battery/fingerprint/contest")}}
#[cfg(test)] #[path="../src/sim.rs"] mod original;
#[cfg(test)] mod detective_tests {
 use super::*;

 #[test] fn instrumentation_preserves_world_and_random_draws(){
  let c=cfg(42,"shared");let rc:original::Config=serde_json::from_value(serde_json::to_value(&c).unwrap()).unwrap();let mut a=World::new(c);let mut b=original::World::new(rc);
  for _ in 0..500 {a.step();b.step();}
  assert_eq!(serde_json::to_value(&a).unwrap(),serde_json::to_value(&b).unwrap());
  assert_eq!(a.research_food.len() as u64,a.counters.eaten);
 }
}

#[cfg(test)] mod sensor_tests {
 use super::*;
 #[test] fn zero_weights_equal_removing_visual_inputs(){
  let mut rng=ChaCha8Rng::seed_from_u64(23);let mut legacy=Brain::random(&mut rng);upgrade(&mut legacy);
  for b in [legacy,Brain::configured(&mut rng,&[32]).unwrap()] {
   let mut w=World::new(cfg(42,"solo"));put(&mut w,&[b.clone()]);let mut obs=observe(&w,&w.agents[0],None);obs.extend([(0,1.),(5,1.),(POISON_INPUT,1.)]);
   let filtered:Vec<_>=obs.iter().copied().filter(|(i,_)|!(*i<VISUAL_INPUTS&&*i%5==0)).collect();
   let expected=b.forward(&filtered,&mut [0.;32]);let actual=masked(&b,"no_wall").forward(&obs,&mut [0.;32]);
   for (x,y) in expected.iter().zip(actual){assert!((x-y).abs()<1e-5);}
  }
 }
}
fn clutter(p:&Pool)->serde_json::Value {
 let mut records=Vec::new();
 for cue in ["ready_under","whole_front"] {for density in [0,4,12,36,80] {for rep in 0..24 {
  let mut w=World::new(Config{size:32,trees:0,initial_population:1,drop_chance:0.,..cfg(666,"solo")});w.agents[0].x=16;w.agents[0].y=16;w.agents[0].dir=0;w.agents[0].energy=120.;w.agents[0].age=200;
  let center=16*32+16;let front=15*32+16;w.cells[if cue=="ready_under"{center}else{front}].nut=if cue=="ready_under"{2}else{1};
  let mut positions:Vec<_>=(-5..=5).flat_map(|dy|(-5..=5).map(move|dx|((16+dy)*32+16+dx) as usize)).filter(|&i|i!=center&&i!=front).collect();positions.shuffle(&mut ChaCha8Rng::seed_from_u64(82000+rep));for &i in positions.iter().take(density){w.cells[i].nut=1;}
  let obs=observe(&w,&w.agents[0],None);let mut mean=[0f64;6];
  for b in &p.brains {let q=Brain::probabilities(b.forward(&obs,&mut [0.;32]));for i in 0..6{mean[i]+=q[i] as f64/p.brains.len() as f64;}}
  records.push(json!({"cue":cue,"density":density,"rep":rep,"p":mean}));
 }}}
 json!({"name":p.name,"records":records})
}
fn poison_control(p:&Pool)->serde_json::Value {
 let mut order:Vec<_>=(0..p.brains.len()).collect();order.shuffle(&mut ChaCha8Rng::seed_from_u64(910001));let mut records=Vec::new();
 for disabled in [false,true] {for trial in 0..384 {
  let bi=order[trial%order.len()];let mut b=p.brains[bi].clone();
  if disabled {let n=b.layers.as_ref().map_or(HIDDEN,|l|l[0]);for input in POISON_INPUT..SENSOR_COUNT {let k=if b.layers.is_some(){input*n}else{PARAMS+(input-INPUTS)*HIDDEN};b.weights[k..k+n].fill(0.);}}
  let mut w=detective_world(&b,910001+trial as u64,"poison");for _ in 0..5000{if w.agents.is_empty(){break;}w.step_with_population_limit(1);}
  records.push(json!({"disabled":disabled,"trial":trial,"brain":bi,"ticks":w.tick,"eaten":w.counters.eaten,"poisoned":w.counters.poisoned,"alive":!w.agents.is_empty()}));
 }}json!({"name":p.name,"records":records})
}
fn main(){rayon::ThreadPoolBuilder::new().num_threads(1).build_global().unwrap();let a:Vec<_>=std::env::args().collect();let p=pool(&a[2]);write_json(&a[3],&if a[1]=="clutter"{clutter(&p)}else{poison_control(&p)});}
