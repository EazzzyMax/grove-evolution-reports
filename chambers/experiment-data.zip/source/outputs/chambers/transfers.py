import pathlib, subprocess, concurrent.futures, time
r=pathlib.Path('outputs/chambers');e='target/release/examples/chambers'
jobs=[('torus_eval',r/'rotators-source.json',r/'rotators-torus-eval.json')]
for arch in ['32','128','128-32','32-32']:
 for seed in range(801,807):
  for mode in ['solo','shared','fresh']:
   d=r/f'{mode}-{arch}-{seed}'
   jobs.append(('torus_eval',d/'final.json',d/'torus-eval.json'))
   for n in [1,2,3]: jobs.append(('learning_eval',d/f'checkpoint-{n}.json',d/f'learning-{n}.json'))
def ready(p):return p.exists() and (p.parent/'summary.json').exists() if p.name!='rotators-source.json' else p.exists()
def run(job):
 command,p,out=job
 if not out.exists():subprocess.run([e,command,str(p),str(out)],check=True)
 print(str(out),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 active={}
 while jobs or active:
  for f in list(active):
   if f.done():f.result();del active[f]
  for job in list(jobs):
   if len(active)>=2:break
   if ready(job[1]):active[pool.submit(run,job)]=job;jobs.remove(job)
  time.sleep(.5)
