import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import json,pathlib,numpy as np
from scipy.cluster.hierarchy import linkage,fcluster
from scipy.spatial.distance import squareform
r=pathlib.Path(__file__).parent;v=json.loads((r/'target.json').read_text());a=np.array([b['weights'] for b in v['brains']],np.float32);d=(a*a).sum(1)[:,None]+(a*a).sum(1)[None,:]-2*a@a.T;d=np.sqrt(np.maximum((d+d.T)/2,0)/a.shape[1]);np.fill_diagonal(d,0)
z=linkage(squareform(d,checks=False),method='average');labels=fcluster(z,2,criterion='maxclust');rows=json.loads((r/'target-battery.json').read_text())['records'];out={'labels4':fcluster(z,.04,criterion='distance').tolist(),'labels':labels.tolist(),'cuts':{},'groups':[]}
for t in [.02,.025,.03,.035,.04,.045,.05]:
 l=fcluster(z,t,criterion='distance');out['cuts'][str(t)]=sorted(np.bincount(l)[1:].tolist(),reverse=True)
for label in [1,2]:
 ids=np.where(labels==label)[0];g={'label':label,'n':len(ids),'scenes':{}}
 for scene in sorted({x['scene'] for x in rows}):
  rr=[x for x in rows if x['scene']==scene and labels[x['brain']]==label];g['scenes'][scene]={'n':len(rr),'eaten':float(np.mean([x['eaten'] for x in rr])),'success':float(np.mean([x['eaten']>0 for x in rr]))}
 out['groups'].append(g)
# PCA of 454 brains via sample Gram matrix, coordinates scaled to RMS units.
c=a-a.mean(0);ev,vec=np.linalg.eigh(c@c.T/a.shape[1]);out['pca']=(vec[:,-2:]*np.sqrt(np.maximum(ev[-2:],0))).tolist();out['pca_variance']=float(ev[-2:].sum()/ev.sum())
(r/'clusters.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print('cuts',out['cuts']);print('groups',[(g['n'],{s:g['scenes'][s] for s in ['solo','micro_far','short_ttl']}) for g in out['groups']])
