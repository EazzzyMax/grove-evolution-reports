import json, pathlib, statistics as st, collections
R=pathlib.Path(__file__).parent
ARCH=['32','32-32','128','128-32']; MODES=['solo','fresh','shared']; SEEDS=list(range(801,807))
def read(p):return json.loads(p.read_text())
def metrics(rows):
 return {'success':st.mean(x['eaten']>0 for x in rows)*100,'food':st.mean(x['eaten'] for x in rows),'ticks':st.mean(x['ticks'] for x in rows),'survival':st.mean(x['alive'] for x in rows)*100,'cracked':st.mean(x['cracked'] for x in rows),'strikes':st.mean(x['strikes'] for x in rows),'steps':st.mean(x['steps'] for x in rows)}
def scenes(path):
 rows=read(path)['records'];return {s:metrics([x for x in rows if x['scene']==s]) for s in sorted(set(x['scene'] for x in rows))}
data={'architectures':ARCH,'modes':MODES,'seeds':SEEDS,'runs':[],'initial':[],'duels':[],'missing':[]}
for arch in ARCH:
 for seed in SEEDS:
  d=R/f'solo-{arch}-{seed}'
  if (d/'initial-eval.json').exists():data['initial'].append({'arch':arch,'seed':seed,'metrics':scenes(d/'initial-eval.json')})
  else:data['missing'].append(str(d/'initial-eval.json'))
  for mode in MODES:
   d=R/f'{mode}-{arch}-{seed}';row={'arch':arch,'mode':mode,'seed':seed,'learning':[]}
   for file,key in [('summary.json','training'),('eval.json','metrics'),('torus-eval.json','torus'),('blind-eval.json','blind')]:
    if (d/file).exists():row[key]=read(d/file) if key=='training' else scenes(d/file)
    else:data['missing'].append(str(d/file))
   for n in [1,2,3]:
    p=d/f'learning-{n}.json'
    if p.exists():row['learning'].append({'work':n*2500000,**scenes(p)['solo']})
    else:data['missing'].append(str(p))
   data['runs'].append(row)
for p in sorted((R/'duels').glob('*.json')):
 v=read(p);h=v['history'];last=h[-1] if h else {'a':0,'b':0,'tick':0};data['duels'].append({'file':p.name,**v,'a_final':last['a'],'b_final':last['b'],'winner':'a' if last['a']>last['b'] else 'b' if last['b']>last['a'] else 'draw'})
for file,key in [('rotators-eval.json','rotator_eval'),('rotators-torus-eval.json','rotator_torus')]:
 if (R/file).exists():data[key]=scenes(R/file)
 else:data['missing'].append(file)
for file,key in [('main13-eval.json','main13_eval'),('main13-torus-eval.json','main13_torus')]:
 if (R/file).exists():data[key]=scenes(R/file)
res=read(R/'rotators-residence.json')['records'];data['residence']=[]
for tree in [False,True]:
 for temp in [0,1]:
  rows=[x for x in res if x['tree']==tree and x['temperature']==temp]
  data['residence'].append({'tree':tree,'temperature':temp,'trials':len(rows),**{k:st.mean(x[k] for x in rows) for k in ['near','east','steps','ticks']}})
data['seasonal']=[read(R/f'rotators-{cond}-{seed}.json') for cond in ['normal','no_temperature','no_trees','no_compass'] for seed in range(901,907)]
data['probe']=read(R/'rotators-probe.json')
if (R/'benchmark.json').exists():data['benchmark']=read(R/'benchmark.json')
(R/'analysis.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
print('Completed final evals',sum('metrics' in x for x in data['runs']),'/72; learning',sum(len(x['learning']) for x in data['runs']),'/216; duels',len(data['duels']),'/96; missing',len(data['missing']))
for a in ARCH:
 for m in MODES:
  rows=[r for r in data['runs'] if r['arch']==a and r['mode']==m and 'metrics' in r]
  if rows:print(a,m,len(rows),'solo food',round(st.mean(r['metrics']['solo']['food'] for r in rows),2),'nut%',round(st.mean(r['metrics']['nut']['success'] for r in rows),1),'survive%',round(st.mean(r['metrics']['solo']['survival'] for r in rows),1))
