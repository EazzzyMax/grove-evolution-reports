from pathlib import Path
import subprocess,time,json
D=Path('outputs/islands');selected=json.load(open(D/'selection.json'))['selected']
while True:
 for tag in selected:
  for mode in ['large','dense']:
   for stage in ['start','100k','final']:
    p=D/'transfer'/f'{tag}-{mode}-{stage}.json';name=f'{tag}-{mode}-{stage}'
    if not p.exists() or (D/'assays'/f'{name}.jsonl').exists():continue
    subprocess.run(['target/release/examples/island_eval',str(p),name],check=True)
 if len(list((D/'transfer').glob('*-final.json')))==8:break
 time.sleep(3)
