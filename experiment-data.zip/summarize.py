import json,numpy as np
from pathlib import Path
from collections import defaultdict
D=Path('outputs/comparison'); groups=defaultdict(list);raw=[]
for p in sorted((D/'runs').glob('*.jsonl')):
 lines=p.read_text().splitlines()
 if not lines:continue
 r=json.loads(lines[-1])
 if r.get('kind')!='final' or r['duration']!=20000:continue
 raw.append(r);groups[(r['mode'],r['condition'],r['evolve'])].append(r)
out=[]
for (mode,condition,evolve),rs in groups.items():
 def metric(r):
  ns=r['state']['n'];e=r['exposure'];c=r['state']['counters'];return {'population':sum(ns),'current_share':ns[1]/max(1,sum(ns)),'old_alive':ns[0],'current_alive':ns[1],'late_population':sum(r['late_population']),'food_per_1000_agent_ticks':1000*c['eaten']/max(1,sum(e)),'strikes_per_nut':c['strikes']/max(1,c['cracked']),'births_per_1000_agent_ticks':1000*c['births']/max(1,sum(e)),'food_total':c['eaten'],'old_age':c['old_age']}
 vals=[metric(r) for r in rs]
 out.append({'mode':mode,'condition':condition,'evolve':evolve,'n':len(rs),'metrics':{k:{'mean':float(np.mean([v[k] for v in vals])),'min':float(min(v[k] for v in vals)),'max':float(max(v[k] for v in vals)),'values':[v[k] for v in vals]} for k in vals[0]},'current_wins':sum(r['state']['n'][1]>r['state']['n'][0] for r in rs),'old_extinctions':sum(r['state']['n'][0]==0 for r in rs),'current_extinctions':sum(r['state']['n'][1]==0 for r in rs)})
probes=json.load(open(D/'probes.json'));pg=defaultdict(list)
for r in probes:pg[r['population'],r['state']].append(r['p'])
pr=[{'population':k[0],'state':k[1],'mean':np.mean(v,axis=0).tolist(),'p10':np.quantile(v,.1,axis=0).tolist(),'p90':np.quantile(v,.9,axis=0).tolist()} for k,v in pg.items()]
summary={'completed':len(raw),'trials':out,'probes':pr,'raw':raw}
D.joinpath('summary.json').write_text(json.dumps(summary,indent=2))
print('completed',len(raw))
for r in out:print(r['mode'],r['condition'],r['evolve'],r['n'],{k:round(v['mean'],3) for k,v in r['metrics'].items()},'wins',r['current_wins'])
for r in pr:print(r['population'],r['state'],np.round(r['mean'],3))
