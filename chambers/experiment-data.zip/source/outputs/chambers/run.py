import subprocess,concurrent.futures,pathlib,time,json,sys
root=pathlib.Path('outputs/chambers');exe='target/release/examples/chambers'
budget=int(sys.argv[1]); seeds=[int(x) for x in sys.argv[2:]]
jobs=[(a,m,s) for a in ['32','128','128-32'] for m in ['solo','shared'] for s in seeds]
def run(job):
 a,m,s=job;name=f'{m}-{a}-{s}';f=open(root/f'{name}.log','w');r=subprocess.run([exe,'train',a,m,str(s),str(budget)],stdout=f,stderr=f);return name,r.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
 for job,result in pool.map(run,jobs):print(job,result,flush=True)
