//! Frozen historical populations, matched ecological trials. Does not write app saves.
#![allow(dead_code)]
#[path = "../src/brain.rs"]
mod brain;
#[path = "../src/sim.rs"]
mod sim;
use brain::*;
use rand::{SeedableRng, seq::SliceRandom};
use serde_json::{Value, json};
use sim::*;
use std::{
    collections::BTreeMap,
    fs::File,
    io::{BufReader, BufWriter, Write},
};
const OUT: &str = "outputs/comparison";
fn load(name: &str) -> World {
    let mut w: World = serde_json::from_reader(BufReader::new(
        File::open(format!("{OUT}/{name}.json")).unwrap(),
    ))
    .unwrap();
    w.validate().unwrap();
    w
}
fn archive(w: &mut World) {
    w.lives = w
        .agents
        .iter()
        .map(|a| LifeRecord {
            id: a.id,
            parent: None,
            lineage: a.lineage,
            generation: a.generation,
            born: 0,
            died: None,
            cause: None,
            birth_position: Some([a.x, a.y]),
            outcome: None,
            genome_base: None,
            mutations: None,
        })
        .collect();
    w.genome_archive_start = Some(0);
    w.lineage_history.clear();
    w.history.clear();
    w.events.clear();
}
fn prepare(mode: &str, condition: &str, seed: u64, swap: usize, evolve: bool) -> World {
    let old = load("old");
    let cur = load("current");
    let mut c = old.config.clone();
    c.initial_population = 120;
    c.seed = 18000 + seed;
    c.mutation = if evolve { 0.52 } else { 0.0 };
    if condition == "sparse" {
        c.trees = 10;
    }
    if condition == "drought" {
        c.drop_chance = 0.025;
    }
    if condition == "expensive" {
        c.strike_cost = 6.0;
    }
    let mut w = World::new(c);
    let mut rng = rand_chacha::ChaCha8Rng::seed_from_u64(29000 + seed);
    let ts: Vec<_> = w
        .cells
        .iter()
        .enumerate()
        .filter(|(_, c)| c.tree)
        .map(|(i, _)| ((i % w.config.size) as i32, (i / w.config.size) as i32))
        .collect();
    let mut slots: Vec<_> = w
        .cells
        .iter()
        .enumerate()
        .filter(|(i, c)| {
            !c.tree
                && ts.iter().any(|(x, y)| {
                    let dx = (*i % w.config.size) as i32 - x;
                    let dy = (*i / w.config.size) as i32 - y;
                    dx * dx + dy * dy <= 25
                })
        })
        .map(|(i, _)| i)
        .collect();
    slots.shuffle(&mut rng);
    let mut pools = [old.agents, cur.agents];
    for p in &mut pools {
        p.shuffle(&mut rng);
    }
    let families: Vec<Value> = if mode == "champion" {
        serde_json::from_reader(File::open("outputs/lab/families.json").unwrap()).unwrap()
    } else {
        vec![]
    };
    let champion: Vec<Brain> = if mode == "champion" {
        serde_json::from_value(families[3]["brains"].clone()).unwrap()
    } else {
        vec![]
    };
    let mut counts = [0usize; 2];
    for (i, a) in w.agents.iter_mut().enumerate() {
        let group = match mode {
            "old" => 0,
            "current" => 1,
            _ => (i + swap) % 2,
        };
        a.brain = if mode == "champion" && group == 0 {
            champion[counts[group] % champion.len()].clone()
        } else {
            pools[group][counts[group] % pools[group].len()]
                .brain
                .clone()
        };
        counts[group] += 1;
        a.lineage = group as u64 + 1;
        a.x = (slots[i] % w.config.size) as i32;
        a.y = (slots[i] / w.config.size) as i32;
    }
    archive(&mut w);
    w.validate().unwrap();
    w.rng = rand_chacha::ChaCha8Rng::seed_from_u64(39000 + seed);
    w
}
fn sample(w: &World) -> Value {
    let mut n = [0usize; 2];
    for a in &w.agents {
        n[a.lineage as usize - 1] += 1;
    }
    json!({"tick":w.tick,"n":n,"counters":w.counters})
}
fn trial(mode: &str, condition: &str, seed: u64, swap: usize, duration: u64, evolve: bool) {
    let mut w = prepare(mode, condition, seed, swap, evolve);
    let name = format!(
        "{mode}-{condition}-{seed}-{swap}-{}",
        if evolve { "mut" } else { "frozen" }
    );
    let mut f = BufWriter::new(File::create(format!("{OUT}/runs/{name}.jsonl")).unwrap());
    writeln!(f,"{}",json!({"kind":"metadata","name":name,"mode":mode,"condition":condition,"seed":seed,"swap":swap,"duration":duration,"evolve":evolve,"config":w.config,"initial":w.agents.iter().map(|a|json!({"id":a.id,"group":a.lineage,"x":a.x,"y":a.y,"dir":a.dir})).collect::<Vec<_>>()})).unwrap();
    let mut exposure = [0u64; 2];
    let mut actions = [[0u64; 6]; 2];
    let mut late_pop = [0u64; 2];
    let mut late_ticks = 0;
    let mut parent_genome = BTreeMap::new();
    for a in &w.agents {
        parent_genome.insert(a.id, a.brain.weights.clone());
    }
    for t in 0..duration {
        if t % 500 == 0 {
            writeln!(f, "{}", sample(&w)).unwrap();
            f.flush().unwrap();
        }
        if w.agents.is_empty() {
            break;
        }
        if condition == "pulses" {
            w.config.drop_chance = if t % 4000 < 2000 { 0.2 } else { 0.0 };
        }
        if condition == "short_pulses" {
            w.config.drop_chance = if t % 1000 < 500 { 0.2 } else { 0.0 };
        }
        for a in &w.agents {
            exposure[a.lineage as usize - 1] += 1;
        }
        w.step_with_sensor_filter(|_, obs| {
            if condition == "no_nuts" {
                obs.retain(|(i, _)| *i >= VISUAL_INPUTS || i % 5 != 2 && i % 5 != 3);
            }
        });
        // Completed actions of surviving agents only; counters below include deaths too.
        for a in &w.agents {
            if a.age > 0 {
                actions[a.lineage as usize - 1][a.action] += 1;
            }
        }
        if t >= duration / 2 {
            for a in &w.agents {
                late_pop[a.lineage as usize - 1] += 1;
            }
            late_ticks += 1;
        }
    }
    let mut totals = [[0u64; 5]; 2];
    let mut lifetimes: [Vec<u64>; 2] = [vec![], vec![]];
    for r in &w.lives {
        let g = r.lineage as usize - 1;
        if r.born > 0 {
            totals[g][0] += 1;
        }
        if let Some(o) = &r.outcome {
            totals[g][1] += o.eaten as u64;
            totals[g][2] += o.cracked as u64;
            totals[g][3] += 1;
            lifetimes[g].push(r.died.unwrap() - r.born);
        }
    }
    for a in &w.agents {
        let g = a.lineage as usize - 1;
        totals[g][1] += a.eaten as u64;
        totals[g][2] += a.cracked as u64;
        totals[g][4] += a.children as u64;
    }
    if !evolve {
        for a in &w.agents {
            let mut id = a.id;
            while !parent_genome.contains_key(&id) {
                id = w.lives[w.lives.binary_search_by_key(&id, |r| r.id).unwrap()]
                    .parent
                    .unwrap();
            }
            assert_eq!(&a.brain.weights, parent_genome.get(&id).unwrap());
        }
    }
    assert_eq!(totals.iter().map(|v| v[1]).sum::<u64>(), w.counters.eaten);
    let result = json!({"kind":"final","name":name,"mode":mode,"condition":condition,"seed":seed,"swap":swap,"evolve":evolve,"duration":duration,"actual_ticks":w.tick,"state":sample(&w),"exposure":exposure,"totals":totals,"actions_survivors":actions,"late_population":late_pop.map(|n|n as f64/(duration/2)as f64),"observed_late_ticks":late_ticks,"death_lifetime_mean":lifetimes.map(|v|v.iter().sum::<u64>()as f64/v.len().max(1)as f64)});
    writeln!(f, "{result}").unwrap();
    f.flush().unwrap();
    println!("{} {}", name, sample(&w));
}
fn probes() {
    let mut result = vec![];
    for label in ["old", "current"] {
        let w = load(label);
        for (name, extras) in [
            ("empty", vec![]),
            ("cracked_under", vec![(5, 5, 3)]),
            ("whole_front", vec![(5, 4, 2)]),
            ("cracked_front", vec![(5, 4, 3)]),
            ("cracked_left", vec![(4, 5, 3)]),
            ("cracked_right", vec![(6, 5, 3)]),
            ("tree_front", vec![(5, 4, 1)]),
            ("neighbor_front", vec![(5, 4, 4)]),
        ] {
            for a in &w.agents {
                let mut obs = vec![(VISUAL_INPUTS, 0.5), (VISUAL_INPUTS + 1, 0.1)];
                for &(x, y, c) in &extras {
                    obs.push(((y * 11 + x) * 5 + c, 1.));
                }
                obs.sort_by_key(|v| v.0);
                let p = Brain::probabilities(a.brain.forward(&obs, &mut [0.; HIDDEN]));
                result.push(json!({"population":label,"id":a.id,"state":name,"p":p}));
            }
        }
    }
    serde_json::to_writer(File::create(format!("{OUT}/probes.json")).unwrap(), &result).unwrap();
}
fn individual() {
    let mut f = BufWriter::new(File::create(format!("{OUT}/individual.jsonl")).unwrap());
    let base = World::new(Config {
        size: 16,
        trees: 0,
        initial_population: 1,
        food_energy: 0.,
        mutation: 0.,
        max_age: 10000,
        strike_cost: 2.,
        ..Default::default()
    });
    for label in ["old", "current"] {
        let source = load(label);
        for a in &source.agents {
            for (task, dx, dy, nut) in [
                ("cracked_under", 0, 0, 2),
                ("cracked_front", 0, -1, 2),
                ("cracked_right", 1, 0, 2),
                ("cracked_far", 0, -3, 2),
                ("whole_front", 0, -1, 1),
            ] {
                for seed in 1..=3 {
                    let mut w = base.clone();
                    for c in &mut w.cells {
                        c.nut = 0;
                        c.ttl = 0;
                    }
                    w.agents[0].brain = a.brain.clone();
                    w.agents[0].x = 8;
                    w.agents[0].y = 8;
                    w.agents[0].dir = 0;
                    w.agents[0].lineage = 1;
                    let i = index(16, 8 + dx, 8 + dy).unwrap();
                    w.cells[i].nut = nut;
                    w.cells[i].ttl = 2000;
                    archive(&mut w);
                    w.validate().unwrap();
                    w.rng = rand_chacha::ChaCha8Rng::seed_from_u64(seed);
                    while w.tick < 300 && !w.agents.is_empty() && w.counters.eaten == 0 {
                        w.step();
                    }
                    writeln!(f,"{}",json!({"population":label,"id":a.id,"task":task,"seed":seed,"success":w.counters.eaten>0,"ticks":w.tick,"strikes":w.counters.strikes})).unwrap();
                }
            }
        }
    }
    f.flush().unwrap();
}
fn individual_extra() {
    let mut f = BufWriter::new(File::create(format!("{OUT}/individual-extra.jsonl")).unwrap());
    let base = World::new(Config {
        size: 16,
        trees: 0,
        initial_population: 1,
        food_energy: 0.,
        mutation: 0.,
        max_age: 10000,
        strike_cost: 2.,
        ..Default::default()
    });
    for label in ["old", "current"] {
        let source = load(label);
        for a in &source.agents {
            for (task, dx, dy, nut) in [
                ("whole_front_energy40", 0, -1, 1),
                ("whole_front_energy80", 0, -1, 1),
                ("whole_front_energy160", 0, -1, 1),
                ("whole_leftfront", -1, -1, 1),
                ("whole_rightfront", 1, -1, 1),
                ("whole_three", 0, -1, 1),
            ] {
                for seed in 1..=3 {
                    let mut w = base.clone();
                    for c in &mut w.cells {
                        c.nut = 0;
                        c.ttl = 0;
                    }
                    w.agents[0].brain = a.brain.clone();
                    w.agents[0].x = 8;
                    w.agents[0].y = 8;
                    w.agents[0].dir = 0;
                    w.agents[0].lineage = 1;
                    w.agents[0].energy = if task.ends_with("40") {
                        40.
                    } else if task.ends_with("80") {
                        80.
                    } else if task.ends_with("160") {
                        160.
                    } else {
                        120.
                    };
                    let i = index(16, 8 + dx, 8 + dy).unwrap();
                    w.cells[i].nut = nut;
                    w.cells[i].ttl = 2000;
                    if task == "whole_three" {
                        for x in [7, 9] {
                            let j = index(16, x, 7).unwrap();
                            w.cells[j].nut = 1;
                            w.cells[j].ttl = 2000;
                        }
                    }
                    archive(&mut w);
                    w.validate().unwrap();
                    w.rng = rand_chacha::ChaCha8Rng::seed_from_u64(seed);
                    while w.tick < 300 && !w.agents.is_empty() && w.counters.eaten == 0 {
                        w.step();
                    }
                    writeln!(f,"{}",json!({"population":label,"id":a.id,"task":task,"seed":seed,"success":w.counters.eaten>0,"ticks":w.tick,"strikes":w.counters.strikes})).unwrap();
                }
            }
        }
    }
    f.flush().unwrap();
}
fn grid() {
    let mut rows = vec![];
    for label in ["old", "current"] {
        let w = load(label);
        for channel in [2, 3] {
            for y in 0..11 {
                for x in 0..11 {
                    let obs = vec![
                        ((y * 11 + x) * 5 + channel, 1.),
                        (VISUAL_INPUTS, 0.5),
                        (VISUAL_INPUTS + 1, 0.1),
                    ];
                    let mut p = [0f64; 6];
                    for a in &w.agents {
                        let q = Brain::probabilities(a.brain.forward(&obs, &mut [0.; HIDDEN]));
                        for j in 0..6 {
                            p[j] += q[j] as f64 / w.agents.len() as f64;
                        }
                    }
                    rows.push(json!({"population":label,"channel":channel,"x":x,"y":y,"p":p}));
                }
            }
        }
    }
    serde_json::to_writer(File::create(format!("{OUT}/grid.json")).unwrap(), &rows).unwrap();
}
fn main() {
    rayon::ThreadPoolBuilder::new()
        .num_threads(1)
        .build_global()
        .unwrap();
    let args: Vec<_> = std::env::args().collect();
    if args[1] == "validate-full" {
        let w = load("current-full");
        println!(
            "Valid full checkpoint: tick={}, alive={}, lives={}, next_id={}",
            w.tick,
            w.agents.len(),
            w.lives.len(),
            w.next_id
        );
        return;
    }
    if args[1] == "individual-extra" {
        individual_extra();
        return;
    }
    if args[1] == "individual" {
        individual();
        return;
    }
    if args[1] == "grid" {
        grid();
        return;
    }
    if args[1] == "probe" {
        probes();
        return;
    }
    trial(
        &args[1],
        &args[2],
        args[3].parse().unwrap(),
        args[4].parse().unwrap(),
        args[5].parse().unwrap(),
        args.get(6).is_some_and(|a| a == "mut"),
    );
}
#[cfg(test)]
mod research_tests {
    use super::*;
    #[test]
    fn paired_swaps_keep_positions_and_reverse_labels() {
        let a = prepare("duel", "normal", 1, 0, false);
        let b = prepare("duel", "normal", 1, 1, false);
        assert_eq!(a.config, b.config);
        for (x, y) in a.agents.iter().zip(&b.agents) {
            assert_eq!(
                (x.x, x.y, x.dir, x.energy, x.age),
                (y.x, y.y, y.dir, y.energy, y.age)
            );
            assert_eq!(x.lineage + y.lineage, 3);
        }
        assert_eq!(a.agents.iter().filter(|x| x.lineage == 1).count(), 60);
    }
    #[test]
    fn repeat_seed_reproduces_ecology() {
        let mut a = prepare("duel", "normal", 2, 0, false);
        let mut b = a.clone();
        for _ in 0..100 {
            a.step();
            b.step();
        }
        assert_eq!(
            serde_json::to_vec(&a).unwrap(),
            serde_json::to_vec(&b).unwrap()
        );
    }
}
