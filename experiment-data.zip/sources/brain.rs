//! Fixed-topology, sparse-input MLP. Input-major SIMD rows avoid multiplying zeros.
use rand::Rng;
use serde::{Deserialize, Serialize};
use wide::f32x8;

pub const VISION: usize = 11;
pub const RADIUS: i32 = 5;
pub const VISUAL_INPUTS: usize = VISION * VISION * 5;
pub const INPUTS: usize = VISUAL_INPUTS + 2;
pub const HIDDEN: usize = 32;
pub const OUTPUTS: usize = 6;
pub const PARAMS: usize = INPUTS * HIDDEN + HIDDEN + HIDDEN * OUTPUTS + OUTPUTS;
pub const ACTIONS: [&str; 6] = ["Вперёд", "Налево", "Направо", "Удар", "Есть", "Ждать"];

#[derive(Clone, Serialize, Deserialize)]
pub struct Brain {
    pub weights: Vec<f32>,
}

impl Brain {
    pub fn random(rng: &mut impl Rng) -> Self {
        let mut weights = vec![0.0; PARAMS];
        for w in &mut weights[..INPUTS * HIDDEN] {
            *w = rng.random_range(-0.25..0.25);
        }
        let start = INPUTS * HIDDEN + HIDDEN;
        for w in &mut weights[start..start + HIDDEN * OUTPUTS] {
            *w = rng.random_range(-0.35..0.35);
        }
        Self { weights }
    }
    pub fn mutate(&mut self, rng: &mut impl Rng, strength: f32) -> Vec<(usize, f32)> {
        let mut changes = Vec::new();
        if strength == 0.0 {
            return changes;
        }
        // Sparse mutations, including biases. Do not reset the parent's learned policy.
        changes.reserve(16);
        for _ in 0..16 {
            let i = rng.random_range(0..PARAMS);
            self.weights[i] =
                (self.weights[i] + rng.random_range(-1.0..1.0) * strength).clamp(-5.0, 5.0);
            changes.push((i, self.weights[i]));
        }
        changes
    }
    pub fn forward(
        &self,
        observation: &[(usize, f32)],
        hidden: &mut [f32; HIDDEN],
    ) -> [f32; OUTPUTS] {
        let mut accum = [f32x8::ZERO; 4];
        for (chunk, a) in accum.iter_mut().enumerate() {
            *a = f32x8::new(
                self.weights[INPUTS * HIDDEN + chunk * 8..INPUTS * HIDDEN + chunk * 8 + 8]
                    .try_into()
                    .unwrap(),
            );
        }
        for &(input, value) in observation {
            let row = &self.weights[input * HIDDEN..(input + 1) * HIDDEN];
            for (chunk, a) in accum.iter_mut().enumerate() {
                *a += f32x8::new(row[chunk * 8..chunk * 8 + 8].try_into().unwrap())
                    * f32x8::splat(value);
            }
        }
        for (chunk, a) in accum.iter().enumerate() {
            let values = a.to_array();
            for j in 0..8 {
                hidden[chunk * 8 + j] = values[j].tanh();
            }
        }
        let mut out = [0.0; OUTPUTS];
        let start = INPUTS * HIDDEN + HIDDEN;
        for (o, result) in out.iter_mut().enumerate() {
            let mut v = f32x8::ZERO;
            for chunk in 0..4 {
                let h = f32x8::new(hidden[chunk * 8..chunk * 8 + 8].try_into().unwrap());
                let w = f32x8::new(
                    self.weights
                        [start + o * HIDDEN + chunk * 8..start + o * HIDDEN + chunk * 8 + 8]
                        .try_into()
                        .unwrap(),
                );
                v += h * w;
            }
            *result = v.reduce_add() + self.weights[PARAMS - OUTPUTS + o];
        }
        out
    }
    pub fn probabilities(logits: [f32; OUTPUTS]) -> [f32; OUTPUTS] {
        let max = logits.iter().copied().fold(f32::NEG_INFINITY, f32::max);
        let mut p = logits.map(|x| ((x - max) / 0.8).exp());
        let sum: f32 = p.iter().sum();
        p.iter_mut().for_each(|x| *x /= sum);
        p
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand::SeedableRng;
    #[test]
    fn sparse_simd_matches_dense_reference() {
        let mut rng = rand_chacha::ChaCha8Rng::seed_from_u64(1);
        let b = Brain::random(&mut rng);
        let obs = [
            (0, 1.0),
            (4, 1.0),
            (83, 1.0),
            (VISUAL_INPUTS, 0.4),
            (VISUAL_INPUTS + 1, 0.1),
        ];
        let mut hidden = [0.0; HIDDEN];
        let fast = b.forward(&obs, &mut hidden);
        let mut reference = [0.0; HIDDEN];
        for (j, h) in reference.iter_mut().enumerate() {
            *h = (b.weights[INPUTS * HIDDEN + j]
                + obs
                    .iter()
                    .map(|&(i, v)| b.weights[i * HIDDEN + j] * v)
                    .sum::<f32>())
            .tanh();
        }
        for (o, actual) in fast.iter().enumerate() {
            let expected = b.weights[PARAMS - OUTPUTS + o]
                + (0..HIDDEN)
                    .map(|j| reference[j] * b.weights[INPUTS * HIDDEN + HIDDEN + o * HIDDEN + j])
                    .sum::<f32>();
            assert!((actual - expected).abs() < 1e-5);
        }
        let p = Brain::probabilities(fast);
        assert!((p.iter().sum::<f32>() - 1.0).abs() < 1e-6);
    }
}
