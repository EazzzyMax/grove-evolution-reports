import json,mmap,hashlib
from pathlib import Path
out=Path('outputs/comparison')
for label,path in [('old',Path('outputs/lab/source-world.json')),('current',out/'current-full.json')]:
 with path.open('rb') as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as m:
  i=m.find(b',"archive_start":'); assert i>0
  d=json.loads(b'{"version":2,"lives":[]'+m[i:])
  d['archive_start']=d['tick']; d['genome_archive_start']=d['tick']
  d['lives']=[dict(id=a['id'],parent=a['parent'],lineage=a['lineage'],generation=a['generation'],born=d['tick']-a['age'],died=None,cause=None,genome_base=a['brain']) for a in sorted(d['agents'],key=lambda a:a['id'])]
  (out/f'{label}.json').write_text(json.dumps(d,separators=(',',':')))
  meta={'tick':d['tick'],'population':len(d['agents']),'generations':[min(a['generation'] for a in d['agents']),max(a['generation'] for a in d['agents'])],'counters':d['counters'],'config':d['config'],'bytes':len(m),'sha256':hashlib.sha256(m).hexdigest()}
  (out/f'{label}-metadata.json').write_text(json.dumps(meta,indent=2));print(label,meta)
