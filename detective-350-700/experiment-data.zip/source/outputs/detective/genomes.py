import os
os.environ['OPENBLAS_NUM_THREADS']='1'
os.environ['VECLIB_MAXIMUM_THREADS']='1'
import numpy as np,json,pathlib,hashlib
R=pathlib.Path(__file__).parent
names=['target','earlier','main13','main689','rotators','chamber'];A={};out={}
for name in names:
 p=json.loads((R/f'{name}.json').read_text());brains=p['brains'];arr=[]
 for b in brains:
  w=np.array(b['weights'],dtype=np.float32)
  if b.get('layers') is None:
   w=np.pad(w,(0,max(0,23686-len(w))))
   w=np.concatenate([w[:607*32],w[19654:23686],w[607*32:608*32],w[608*32:19648].reshape(6,32).T.reshape(-1),w[19648:19654]])
  arr.append(w)
 A[name]=np.stack(arr);assert A[name].shape[1]==23686
 rng=np.random.default_rng(488);pairs=rng.integers(0,len(arr),size=(2000,2));pairs=pairs[pairs[:,0]!=pairs[:,1]]
 rms=np.sqrt(((A[name][pairs[:,0]]-A[name][pairs[:,1]])**2).mean(1))
 out[name]={'count':len(arr),'unique':len({hashlib.sha256(x.tobytes()).digest() for x in arr}),'within_rms_mean':float(rms.mean()),'within_rms_p10_p50_p90':np.quantile(rms,[.1,.5,.9]).tolist()}
# All target brains compared to every candidate brain in each reference pool.
a=A['target'];nearest={}
for name,b in A.items():
 if name=='target':continue
 dist=(a*a).sum(1)[:,None]+(b*b).sum(1)[None,:]-2*(a@b.T)
 idx=dist.argmin(1);rms=np.sqrt(np.maximum(dist[np.arange(len(a)),idx],0)/a.shape[1]);exact=(a==b[idx]).mean(1)
 nearest[name]={'nearest_rms_mean':float(rms.mean()),'nearest_rms_p10_p50_p90':np.quantile(rms,[.1,.5,.9]).tolist(),'same_coordinate_fraction_mean':float(exact.mean()),'matched_reference_indices':idx.tolist(),'per_target_rms':rms.tolist()}
result={'within':out,'target_nearest':nearest,'note':'Aligned input/output layout for legacy and configured 32. Distances are genetic similarity, not proof of direct ancestry; no hidden-neuron permutation matching.'}
(R/'genomes.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps({'within':out,'nearest':{k:{kk:vv for kk,vv in v.items() if kk not in ['matched_reference_indices','per_target_rms']} for k,v in nearest.items()}},ensure_ascii=False,indent=2))
