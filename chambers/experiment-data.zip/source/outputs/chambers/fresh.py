import subprocess,concurrent.futures,pathlib
r=pathlib.Path('outputs/chambers');e='target/release/examples/chambers'
def run(job):
 a,seed=job;name=f'fresh-{a}-{seed}'
 with open(r/f'{name}.log','w') as f: result=subprocess.run([e,'train',a,'fresh',str(seed),'10000000'],stdout=f,stderr=f)
 return name,result.returncode
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for result in pool.map(run,[(a,s) for a in ['32','128','128-32'] for s in range(801,807)]):print(*result,flush=True)
