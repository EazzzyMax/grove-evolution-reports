# Grove chamber experiments — 2026-11-11

Run from the extracted `source/` directory. Rust 1.95 or newer, Python 3.
The Rust harness imports the frozen production brain, world and statistics modules in src/.
It writes only to outputs/chambers/. It does not load installed app settings or modify presets.

```sh
mkdir -p outputs/chambers
cargo build --release --example chambers
cargo test --release --example chambers
python3 outputs/chambers/run.py 10000000 801 802 803 804 805 806
python3 outputs/chambers/fresh.py
python3 outputs/chambers/add_32_32.py
python3 outputs/chambers/evaluate.py
python3 outputs/chambers/blind.py
```

The first three runners create 72 training runs: four architectures, three regimes, six seeds.
Each has 10 million individual decisions, including time before complete-extinction restarts.
Final living brains are evaluated without choosing the best individuals.
`add_32_32.py` also evaluates its own final and initial brains; `evaluate.py` covers the other architectures.

`transfers.py` evaluates every checkpoint at 2.5, 5 and 7.5 million decisions in the same solo environment, and final brains on a seasonal torus.
`duels.py` runs 96 matches (24 of them against the historical preset).
Those two scripts expect the private historical pool at outputs/chambers/rotators-source.json;
it is not distributed. Remove the historical-pool jobs to reproduce only newly evolved populations.
The historical pool contains 315 brains called “1.3 + 3 вращалка”, saved at tick 2658308.
`interventions.py` and the `probe` / `residence` commands also require that pool.

Hardware: Apple M1 Pro, 8 logical CPUs, 16 GiB RAM, macOS.
Inference benchmark (run without concurrent experiment workers):

```sh
target/release/examples/chambers benchmark outputs/chambers/benchmark.json
```

Protocol details are in the published report and harness. Notable limitations:
- More food per agent and different geometry in chambers than in shared training.
- Chamber capacity 64 uses random eviction; shared cap 64 defers births without energy cost.
- 16 mutated weights per birth for every architecture; no per-architecture mutation tuning.
- Single-agent tests suppress births without charging their energy cost.
- Normal arenas have walls and no compass/temperature. Additional torus tests enable both.
- Each trained family contributes 128 trials per scenario, not 128 independent evolution seeds.
- Scores at 5000 ticks are censored; no claim of complete lifetime measurement.
- One battle arena per independently trained family; match outcomes are noisy and task-dependent.

Raw result JSON is in the archive's data/ directory. Training roots, checkpoints, final brains and lineage event logs remain on the user's Mac because of size.
Each events.jsonl includes root seeds, child mutations, room forks, deaths, capacity culls and restarts.
Output pools contain weights and architecture layouts. Their serialization is a research pool,
not a directly installed UI preset. They can be converted through the app population-preset format.
