from pathlib import Path
import subprocess,time,json,collections
D=Path('outputs/islands')
while True:
 finals=list((D/'search').glob('*-final.json'))
 for p in finals:
  tag=p.name.removesuffix('-final.json')
  if not (D/'assays'/f'{tag}.jsonl').exists():subprocess.run(['target/release/examples/island_eval',str(p),tag],check=True)
 if len(finals)==32:break
 time.sleep(3)
for tag in ['old','current']:
 subprocess.run(['target/release/examples/island_eval',f'outputs/comparison/{tag}.json',tag],check=True)
