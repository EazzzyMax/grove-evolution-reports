import concurrent.futures,pathlib,subprocess,json,shutil
r=pathlib.Path('outputs/nutphobes');keys=['base_early','base_late']+[f'step{i}' for i in range(1,7)];jobs=[]
for k in keys:
 d=r/k;d.mkdir(exist_ok=True)
 for kind in ['battery','focused','fingerprint','micro_audit','clutter','patches']:
  old=pathlib.Path('outputs/barbarians')/({'clutter':'barbarians-clutter'}.get(kind,kind)+'.json')
  if k=='base_early' and old.exists():shutil.copy2(old,d/f'{kind}.json');continue
  exe='nutphobes' if kind=='patches' else 'barbarian_probe' if kind=='clutter' else 'detective'
  jobs.append((k+'-'+kind,['target/release/examples/'+exe,kind,str(r/f'{k}.json'),str(d/f'{kind}.json')]))
(r/'contests').mkdir(exist_ok=True)
for step in keys[2:]:
 for scene in ['solo','short_ttl','rich','long_ttl']:
  for seed in range(1601,1607):
   for order in ['normal','swap']:
    name=f'{step}-vs-base_late-{scene}-{seed}-{order}'
    jobs.append((name,['target/release/examples/nutphobes','contest',str(r/f'{step}.json'),str(r/'base_late.json'),str(seed),scene,order,str(r/'contests'/f'{name}.json')]))
for i in range(2,7):
 for scene in ['short_ttl','rich']:
  for seed in range(1601,1605):
   for order in ['normal','swap']:
    name=f'step{i}-vs-step{i-1}-{scene}-{seed}-{order}'
    jobs.append((name,['target/release/examples/nutphobes','contest',str(r/f'step{i}.json'),str(r/f'step{i-1}.json'),str(seed),scene,order,str(r/'contests'/f'{name}.json')]))
def run(job):
 name,cmd=job
 if pathlib.Path(cmd[-1]).exists():return 'skip '+name
 with (r/f'{name}.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=f,check=True)
 return name
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
 for name in pool.map(run,jobs):print(name,flush=True)
