import os
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['VECLIB_MAXIMUM_THREADS']='1'
import numpy as np,json,pathlib,hashlib
r=pathlib.Path('outputs/barbarians');a=json.load(open(r/'source.json'));b=json.load(open('outputs/detective/target.json'));x=np.array([z['weights'] for z in a['brains']],np.float32);y=np.array([z['weights'] for z in b['brains']],np.float32)
out={'info':a['info'],'n':len(x),'unique':len({hashlib.sha256(z.tobytes()).digest() for z in x})}
d=(x*x).sum(1)[:,None]+(y*y).sum(1)[None,:]-2*x@y.T;idx=d.argmin(1);out['nearest_previous_rms_mean']=float(np.sqrt(np.maximum(d[np.arange(len(x)),idx],0)/x.shape[1]).mean());out['nearest_equal_weights']=float((x==y[idx]).mean())
rng=np.random.default_rng(123)
for name,z in [('barbarians',x),('350700',y)]:
 p=rng.integers(0,len(z),size=(2000,2));p=p[p[:,0]!=p[:,1]];out[name+'_within_rms']=float(np.sqrt(((z[p[:,0]]-z[p[:,1]])**2).mean(1)).mean())
(r/'genomes.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(out)
