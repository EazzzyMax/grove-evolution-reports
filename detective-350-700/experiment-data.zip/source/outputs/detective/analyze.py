import pathlib,json,statistics as s,collections
R=pathlib.Path(__file__).parent
N=['target','earlier','main13','main689','rotators','chamber']
def read(p):return json.loads(p.read_text())
def summarize(rows):
 out={}
 for scene in sorted({x['scene'] for x in rows}):
  z=[x for x in rows if x['scene']==scene];times=[x['first_food'] for x in z if x['first_food'] is not None]
  d={'n':len(z),'ate':sum(x['eaten']>0 for x in z),'success':s.mean(x['eaten']>0 for x in z)*100,'food':s.mean(x['eaten'] for x in z),'ticks':s.mean(x['ticks'] for x in z),'survival':s.mean(x['alive'] for x in z)*100,'first_food':s.mean(times) if times else None,'strikes':s.mean(x['strikes'] for x in z),'cracked':s.mean(x['cracked'] for x in z)}
  if 'useful' in z[0]:d.update({'useful_pct':100*sum(x['useful'] for x in z)/max(1,sum(x['strikes'] for x in z)),'actions':[sum(x['actions'][i] for x in z) for i in range(6)],'poison_deaths':sum(x['poisoned'] for x in z)})
  out[scene]=d
 return out
D={'manifest':read(R/'manifest.json'),'battery':{},'focused':{},'fingerprint':{},'contests':{},'genomes':read(R/'genomes.json'),'clusters':read(R/'clusters.json')}
for name in N:
 for k in ['battery','focused']:D[k][name]=summarize(read(R/f'{name}-{k}.json')['records'])
 D['fingerprint'][name]=[{k:v for k,v in x.items() if k!='individual'} for x in read(R/f'{name}-fingerprint.json')['records']]
groups=collections.defaultdict(list)
for p in (R/'contests').glob('*.json'):
 v=read(p);opp=p.name.split('-')[1];groups[(v['scene'],opp)].append(v)
for (scene,opp),z in groups.items():
 D['contests'][scene+':'+opp]={'n':len(z),'wins':sum(x['final_a']>x['final_b'] for x in z),'losses':sum(x['final_a']<x['final_b'] for x in z),'extinct_both':sum(x['final_a']==x['final_b']==0 for x in z),'ties_alive':sum(x['final_a']==x['final_b'] and x['final_a']>0 for x in z),'final_a':s.mean(x['final_a'] for x in z),'final_b':s.mean(x['final_b'] for x in z),'own':[sum(x['own'][i] for x in z) for i in [0,1]],'other':[sum(x['other'][i] for x in z) for i in [0,1]],'self_food':[sum(x['self_food'][i] for x in z) for i in [0,1]],'unknown':[sum(x['unknown'][i] for x in z) for i in [0,1]],'runs':[{'seed':x['seed'],'swap':x['swap'],'a':x['final_a'],'b':x['final_b']} for x in sorted(z,key=lambda x:(x['seed'],x['swap']))]}
v=read(R/'target-micro-audit.json')['records'];D['audit']={}
for scene in sorted({x['scene'] for x in v}):
 z=[x for x in v if x['scene']==scene];D['audit'][scene]={'n':len(z),'success':sum(x['success'] for x in z),'mean_ticks':s.mean(x['first_food'] for x in z if x['success'])}
D['total_contests']=sum(x['n'] for x in D['contests'].values());assert D['total_contests']==432
(R/'analysis.json').write_text(json.dumps(D,ensure_ascii=False,indent=2));print('432 contests, 6 populations, 33 battery + 9 focused scenes, 7264 all-brain micro trials')
