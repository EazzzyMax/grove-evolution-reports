# Barbarians vs 350+700 — 2026-11-11

The user confirmed that Barbarians are a continuation of 350+700.
New preset: 175 brains, saved tick 5,586,618; legacy layout 733 -> 32 -> 6.
Population weights are intentionally not published. SHA-256 and metadata of the
new source are in analysis.json. Historical inputs are the frozen pools from
the 350+700 investigation, not newly generated substitutes.

To reproduce from source/ (Rust 1.95+, Python 3):
- Put the Barbarians preset at outputs/barbarians/source.json.
- Put old pools at outputs/detective/{target,earlier,main13,main689,rotators,chamber}.json.
- `target` is 350+700. The chamber is fresh-32-802 from the chamber experiments.

    cargo build --release --example detective --example barbarian_probe
    python3 outputs/barbarians/run.py
    python3 outputs/barbarians/extra.py

run.py performs 33 x 192 battery trials, 9 x 256 focused trials, an all-brain
micro audit (175 x 4 x 4), policy fingerprints, and 216 contests.
extra.py tests both old and new brains with extra visual clutter and with the
poison channel disabled. No seasonal or temperature tests were performed.

Each contest cell has four map seeds, each played with mirrored groups.
These are eight matches, not eight independent maps. Frozen variants retain
reproduction but set mutation strength to zero.

For analysis, also supply outputs/detective/analysis.json from the prior report.
NumPy and Matplotlib are required for plotting, NumPy for genome comparisons.
The archive includes all new raw rollout outcomes and aggregate fingerprints;
full individual network probability arrays and original genomes remain local.

The frozen simulation instrumented for nut ownership is identical to the one
validated in the previous investigation. Its instrumentation was tested against
full serialized production world state and RNG after 500 ticks. Original app
code and population presets were not modified.
