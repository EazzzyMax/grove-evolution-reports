"""Additional architecture, identical seeds/budgets/evaluation as original batch."""
import concurrent.futures, json, pathlib, subprocess
root = pathlib.Path('outputs/chambers')
exe = 'target/release/examples/chambers'
def run(job):
    mode, seed = job
    folder = root / f'{mode}-32-32-{seed}'
    with open(root / f'{mode}-32-32-{seed}.log', 'w') as log:
        subprocess.run([exe, 'train', '32-32', mode, str(seed), '10000000'], stdout=log, stderr=log, check=True)
    print('trained', folder.name, flush=True)
    subprocess.run([exe, 'eval', str(folder/'final.json'), str(folder/'eval.json'), '128'], check=True)
    if mode == 'solo':
        subprocess.run([exe, 'eval', str(folder/'initial.json'), str(folder/'initial-eval.json'), '128'], check=True)
    print('evaluated', folder.name, flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    list(pool.map(run, [(mode, seed) for mode in ['solo', 'shared', 'fresh'] for seed in range(801, 807)]))
