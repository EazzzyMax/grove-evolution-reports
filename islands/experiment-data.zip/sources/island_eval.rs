#![allow(dead_code)]
#[path="../src/brain.rs"]mod brain;#[path="../src/sim.rs"]mod sim;
use sim::*;use rand::{SeedableRng,seq::SliceRandom};use serde_json::json;use std::{fs::{self,File},io::{BufReader,BufWriter,Write},path::Path};
fn read(path:&str)->World{let mut w:World=serde_json::from_reader(BufReader::new(File::open(path).unwrap())).unwrap();w.validate().unwrap();w}
fn main(){rayon::ThreadPoolBuilder::new().num_threads(1).build_global().unwrap();let args:Vec<_>=std::env::args().collect();let path=&args[1];let tag=&args[2];let source=read(path);let mut pool=source.agents;if path.contains("/transfer/"){pool.retain(|a|a.lineage==2);}let mut rng=rand_chacha::ChaCha8Rng::seed_from_u64(91001);pool.shuffle(&mut rng);pool.truncate(24);
 let out=format!("outputs/islands/assays/{tag}.jsonl");if Path::new(&out).exists(){return;}fs::create_dir_all("outputs/islands/assays").unwrap();let mut f=BufWriter::new(File::create(&out).unwrap());
 let base=World::new(Config{size:16,trees:0,initial_population:1,food_energy:0.,mutation:0.,max_age:10000,strike_cost:2.,..Default::default()});
 for a in &pool{for (task,dx,dy,nut) in [("whole_front",0,-1,1),("whole_leftfront",-1,-1,1),("whole_rightfront",1,-1,1),("whole_behind",0,1,1),("whole_far",0,-3,1),("whole_three",0,-1,1),("cracked_under",0,0,2),("cracked_front",0,-1,2),("cracked_right",1,0,2)]{for seed in 1..=3{
  let mut w=base.clone();for c in &mut w.cells{c.nut=0;c.ttl=0;}w.agents[0].brain=a.brain.clone();w.agents[0].x=8;w.agents[0].y=8;w.agents[0].dir=0;
  let j=index(16,8+dx,8+dy).unwrap();w.cells[j].nut=nut;w.cells[j].ttl=2000;if task=="whole_three"{for x in [7,9]{let j=index(16,x,7).unwrap();w.cells[j].nut=1;w.cells[j].ttl=2000;}}
  w.validate().unwrap();w.rng=rand_chacha::ChaCha8Rng::seed_from_u64(seed);while w.tick<300&&!w.agents.is_empty()&&w.counters.eaten==0{w.step_with_population_limit(1);}
  writeln!(f,"{}",json!({"source":tag,"agent":a.id,"task":task,"seed":seed,"success":w.counters.eaten>0,"ticks":w.tick,"strikes":w.counters.strikes})).unwrap();
 }}}f.flush().unwrap();println!("{tag}: {} brains tested",pool.len());}
