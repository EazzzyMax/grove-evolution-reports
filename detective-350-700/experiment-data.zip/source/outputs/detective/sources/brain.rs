//! Fixed-topology, sparse-input MLP. Input-major SIMD rows avoid multiplying zeros.
use rand::Rng;
use serde::{Deserialize, Serialize};
use wide::f32x8;

pub const VISION: usize = 11;
pub const RADIUS: i32 = 5;
pub const VISUAL_INPUTS: usize = VISION * VISION * 5;
pub const INPUTS: usize = VISUAL_INPUTS + 2;
pub const HIDDEN: usize = 32;
pub const OUTPUTS: usize = 6;
pub const PARAMS: usize = INPUTS * HIDDEN + HIDDEN + HIDDEN * OUTPUTS + OUTPUTS;
pub const ACTIONS: [&str; 6] = ["Вперёд", "Налево", "Направо", "Удар", "Есть", "Ждать"];

#[derive(Clone, Serialize, Deserialize)]
pub struct Brain {
    pub weights: Vec<f32>,
    #[serde(default, skip_serializing_if="Option::is_none")]
    pub layers: Option<Vec<usize>>,
}

impl Brain {
    pub fn random(rng: &mut impl Rng) -> Self {
        let mut weights = vec![0.0; PARAMS];
        for w in &mut weights[..INPUTS * HIDDEN] {
            *w = rng.random_range(-0.25..0.25);
        }
        let start = INPUTS * HIDDEN + HIDDEN;
        for w in &mut weights[start..start + HIDDEN * OUTPUTS] {
            *w = rng.random_range(-0.35..0.35);
        }
        Self { weights, layers:None }
    }
    pub fn mutate(&mut self, rng: &mut impl Rng, strength: f32) -> Vec<(usize, f32)> {
        let mut changes = Vec::new();
        if strength == 0.0 {
            return changes;
        }
        // Sparse mutations, including biases. Do not reset the parent's learned policy.
        changes.reserve(16);
        for _ in 0..16 {
            let i = rng.random_range(0..self.weights.len());
            self.weights[i] =
                (self.weights[i] + rng.random_range(-1.0..1.0) * strength).clamp(-5.0, 5.0);
            changes.push((i, self.weights[i]));
        }
        changes
    }
    pub fn forward(
        &self,
        observation: &[(usize, f32)],
        hidden: &mut [f32; HIDDEN],
    ) -> [f32; OUTPUTS] {
        if let Some(layers)=&self.layers {return self.dynamic_forward(observation,hidden,layers);}
        let mut accum = [f32x8::ZERO; 4];
        for (chunk, a) in accum.iter_mut().enumerate() {
            *a = f32x8::new(
                self.weights[INPUTS * HIDDEN + chunk * 8..INPUTS * HIDDEN + chunk * 8 + 8]
                    .try_into()
                    .unwrap(),
            );
        }
        for &(input, value) in observation {
            let start = if input < INPUTS {
                input * HIDDEN
            } else {
                PARAMS + (input - INPUTS) * HIDDEN
            };
            if start + HIDDEN > self.weights.len() {
                continue;
            }
            let row = &self.weights[start..start + HIDDEN];
            for (chunk, a) in accum.iter_mut().enumerate() {
                *a += f32x8::new(row[chunk * 8..chunk * 8 + 8].try_into().unwrap())
                    * f32x8::splat(value);
            }
        }
        for (chunk, a) in accum.iter().enumerate() {
            let values = a.to_array();
            for j in 0..8 {
                hidden[chunk * 8 + j] = values[j].tanh();
            }
        }
        let mut out = [0.0; OUTPUTS];
        let start = INPUTS * HIDDEN + HIDDEN;
        for (o, result) in out.iter_mut().enumerate() {
            let mut v = f32x8::ZERO;
            for chunk in 0..4 {
                let h = f32x8::new(hidden[chunk * 8..chunk * 8 + 8].try_into().unwrap());
                let w = f32x8::new(
                    self.weights
                        [start + o * HIDDEN + chunk * 8..start + o * HIDDEN + chunk * 8 + 8]
                        .try_into()
                        .unwrap(),
                );
                v += h * w;
            }
            *result = v.reduce_add() + self.weights[PARAMS - OUTPUTS + o];
        }
        out
    }
    pub fn probabilities(logits: [f32; OUTPUTS]) -> [f32; OUTPUTS] {
        let max = logits.iter().copied().fold(f32::NEG_INFINITY, f32::max);
        let mut p = logits.map(|x| ((x - max) / 0.8).exp());
        let sum: f32 = p.iter().sum();
        p.iter_mut().for_each(|x| *x /= sum);
        p
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand::SeedableRng;
    #[test]
    fn sparse_simd_matches_dense_reference() {
        let mut rng = rand_chacha::ChaCha8Rng::seed_from_u64(1);
        let b = Brain::random(&mut rng);
        let obs = [
            (0, 1.0),
            (4, 1.0),
            (83, 1.0),
            (VISUAL_INPUTS, 0.4),
            (VISUAL_INPUTS + 1, 0.1),
        ];
        let mut hidden = [0.0; HIDDEN];
        let fast = b.forward(&obs, &mut hidden);
        let mut reference = [0.0; HIDDEN];
        for (j, h) in reference.iter_mut().enumerate() {
            *h = (b.weights[INPUTS * HIDDEN + j]
                + obs
                    .iter()
                    .map(|&(i, v)| b.weights[i * HIDDEN + j] * v)
                    .sum::<f32>())
            .tanh();
        }
        for (o, actual) in fast.iter().enumerate() {
            let expected = b.weights[PARAMS - OUTPUTS + o]
                + (0..HIDDEN)
                    .map(|j| reference[j] * b.weights[INPUTS * HIDDEN + HIDDEN + o * HIDDEN + j])
                    .sum::<f32>();
            assert!((actual - expected).abs() < 1e-5);
        }
        let p = Brain::probabilities(fast);
        assert!((p.iter().sum::<f32>() - 1.0).abs() < 1e-6);
    }
}

pub const POISON_INPUT: usize = INPUTS + 5;
pub const POISON_PARAMS: usize = PARAMS + (5 + VISION * VISION) * HIDDEN;
pub fn upgrade(brain: &mut Brain) { if brain.layers.is_none() && [PARAMS, PARAMS+4*HIDDEN, PARAMS+5*HIDDEN].contains(&brain.weights.len()) {brain.weights.resize(POISON_PARAMS,0.0);} }
impl Brain {
    /// One supervised cross-entropy step, including the softmax temperature.
    pub fn demonstrate(&mut self, obs:&[(usize,f32)], action:usize) {
        if self.layers.is_some() {self.dynamic_demonstrate(obs,action);return;}
        let mut hidden=[0.0;HIDDEN];
        let p=Self::probabilities(self.forward(obs,&mut hidden));
        let delta: [f32;OUTPUTS]=std::array::from_fn(|o|(p[o]-f32::from(o==action))/0.8);
        let output=INPUTS*HIDDEN+HIDDEN;
        let dh:[f32;HIDDEN]=std::array::from_fn(|h| (1.0-hidden[h]*hidden[h])* (0..OUTPUTS).map(|o|delta[o]*self.weights[output+o*HIDDEN+h]).sum::<f32>());
        let rate=0.01;
        for o in 0..OUTPUTS {
            self.weights[PARAMS-OUTPUTS+o]=(self.weights[PARAMS-OUTPUTS+o]-rate*delta[o]).clamp(-5.0,5.0);
            for h in 0..HIDDEN {let i=output+o*HIDDEN+h;self.weights[i]=(self.weights[i]-rate*delta[o]*hidden[h]).clamp(-5.0,5.0);}
        }
        for h in 0..HIDDEN {let i=INPUTS*HIDDEN+h;self.weights[i]=(self.weights[i]-rate*dh[h]).clamp(-5.0,5.0);}
        for &(input,value) in obs {
            let start=if input<INPUTS {input*HIDDEN}else{PARAMS+(input-INPUTS)*HIDDEN};
            if start+HIDDEN<=self.weights.len() {for h in 0..HIDDEN {self.weights[start+h]=(self.weights[start+h]-rate*dh[h]*value).clamp(-5.0,5.0);}}
        }
    }
}

#[cfg(test)] mod demonstration_tests {
    use super::*;use rand::SeedableRng;
    #[test] fn demonstration_increases_target_probability() {
        let mut b=Brain::random(&mut rand_chacha::ChaCha8Rng::seed_from_u64(42));upgrade(&mut b);
        let obs=[(0,1.0),(VISUAL_INPUTS,0.5),(POISON_INPUT,1.0)];
        let before=Brain::probabilities(b.forward(&obs,&mut [0.0;HIDDEN]))[4];
        b.demonstrate(&obs,4);
        let after=Brain::probabilities(b.forward(&obs,&mut [0.0;HIDDEN]))[4];assert!(after>before);
        assert!(b.weights.iter().all(|v|v.is_finite() && v.abs()<=5.0));
    }
}


pub const SENSOR_COUNT:usize=POISON_INPUT+VISION*VISION;
pub const MAX_NEURONS:usize=256;
pub const MAX_LAYERS:usize=8;
pub fn architecture_params(layers:&[usize])->Option<usize> {
    if layers.len()>MAX_LAYERS || layers.iter().any(|&n|n==0 || n>MAX_NEURONS) {return None;}
    let mut prev=SENSOR_COUNT;let mut count=0;
    for n in layers.iter().copied().chain(std::iter::once(OUTPUTS)) {count+=(prev+1)*n;prev=n;}
    Some(count)
}
impl Brain {
    pub fn valid(&self)->bool {
        let length=if let Some(layers)=&self.layers {architecture_params(layers)==Some(self.weights.len())}else{[PARAMS,PARAMS+4*HIDDEN,PARAMS+5*HIDDEN,POISON_PARAMS].contains(&self.weights.len())};
        length && self.weights.iter().all(|v|v.is_finite() && v.abs()<=5.0)
    }
    pub fn architecture(&self)->Vec<usize> {self.layers.clone().unwrap_or_else(||vec![HIDDEN])}
    pub fn description(&self)->String {
        std::iter::once(SENSOR_COUNT).chain(self.architecture()).chain(std::iter::once(OUTPUTS)).map(|n|n.to_string()).collect::<Vec<_>>().join(" → ")
    }
    pub fn configured(rng:&mut impl Rng,layers:&[usize])->Result<Self,String> {
        let count=architecture_params(layers).ok_or("Допустимо 0–8 скрытых слоёв по 1–256 нейронов")?;
        let mut weights=Vec::with_capacity(count);let mut prev=SENSOR_COUNT;
        for n in layers.iter().copied().chain(std::iter::once(OUTPUTS)) {
            let scale=(6.0/(prev+n) as f32).sqrt();
            weights.extend((0..prev*n).map(|_|rng.random_range(-scale..scale)));
            weights.resize(weights.len()+n,0.0);prev=n;
        }
        Ok(Self{weights,layers:Some(layers.to_vec())})
    }
    // Input-major rows preserve sparse evaluation of the large sensory layer.
    // Two fixed stack buffers avoid allocating for each agent's decision.
    fn dynamic_forward(&self,obs:&[(usize,f32)],preview:&mut [f32;HIDDEN],layers:&[usize])->[f32;OUTPUTS] {
        let mut previous=[0.0;MAX_NEURONS];let mut next=[0.0;MAX_NEURONS];
        let mut input=SENSOR_COUNT;let mut offset=0;preview.fill(0.0);
        for (depth,n) in layers.iter().copied().chain(std::iter::once(OUTPUTS)).enumerate() {
            next[..n].copy_from_slice(&self.weights[offset+input*n..offset+(input+1)*n]);
            if depth==0 {for &(i,value) in obs {if i<input {for j in 0..n {next[j]+=value*self.weights[offset+i*n+j];}}}}
            else {for i in 0..input {for j in 0..n {next[j]+=previous[i]*self.weights[offset+i*n+j];}}}
            if depth<layers.len() {for v in &mut next[..n] {*v=v.tanh();}}
            if depth==0 && !layers.is_empty() {let k=n.min(HIDDEN);preview[..k].copy_from_slice(&next[..k]);}
            std::mem::swap(&mut previous,&mut next);offset+=(input+1)*n;input=n;
        }
        previous[..OUTPUTS].try_into().unwrap()
    }
    fn dynamic_demonstrate(&mut self,obs:&[(usize,f32)],action:usize) {
        let layers=self.layers.as_ref().unwrap();
        let sizes:Vec<_>=std::iter::once(SENSOR_COUNT).chain(layers.iter().copied()).chain(std::iter::once(OUTPUTS)).collect();
        let mut input=vec![0.0;SENSOR_COUNT];for &(i,v) in obs {if i<SENSOR_COUNT {input[i]+=v;}}
        let mut activations=vec![input];let mut offsets=Vec::new();let mut offset=0;
        for depth in 0..sizes.len()-1 {
            let (m,n)=(sizes[depth],sizes[depth+1]);offsets.push(offset);
            let mut a=self.weights[offset+m*n..offset+(m+1)*n].to_vec();
            for i in 0..m {let value=activations[depth][i];if value!=0.0 {for j in 0..n {a[j]+=value*self.weights[offset+i*n+j];}}}
            if depth<layers.len() {for v in &mut a {*v=v.tanh();}}
            activations.push(a);offset+=(m+1)*n;
        }
        let p=Self::probabilities(activations.last().unwrap().as_slice().try_into().unwrap());
        let mut delta:Vec<_>=p.iter().enumerate().map(|(i,&v)|(v-f32::from(i==action))/0.8).collect();
        for depth in (0..offsets.len()).rev() {
            let (m,n)=(sizes[depth],sizes[depth+1]);let offset=offsets[depth];
            let mut previous=vec![0.0;m];
            if depth>0 {for i in 0..m {previous[i]=(1.0-activations[depth][i].powi(2))*(0..n).map(|j|self.weights[offset+i*n+j]*delta[j]).sum::<f32>();}}
            for i in 0..m {let value=activations[depth][i];if value!=0.0 {for j in 0..n {let k=offset+i*n+j;self.weights[k]=(self.weights[k]-0.01*value*delta[j]).clamp(-5.0,5.0);}}}
            for j in 0..n {let k=offset+m*n+j;self.weights[k]=(self.weights[k]-0.01*delta[j]).clamp(-5.0,5.0);}
            delta=previous;
        }
    }
}

#[cfg(test)] mod architecture_tests {
    use super::*;
    use rand::SeedableRng;
    #[test] fn dynamic_sparse_forward_and_gradient() {
        let obs=[(0,1.0),(605,0.6),(612,1.0),(732,1.0)];
        for layers in [vec![],vec![1],vec![17],vec![32,16],vec![8,7,6],vec![256;8]] {
            let b=Brain::configured(&mut rand_chacha::ChaCha8Rng::seed_from_u64(72),&layers).unwrap();
            assert!(b.valid());
            let actual=b.forward(&obs,&mut [0.0;32]);
            let mut dense=vec![0.0;SENSOR_COUNT];for &(i,v) in &obs {dense[i]=v;}
            let mut offset=0;
            for (d,n) in layers.iter().copied().chain(std::iter::once(6)).enumerate() {
                let next:Vec<_>=(0..n).map(|j|{let v=b.weights[offset+dense.len()*n+j]+dense.iter().enumerate().map(|(i,&v)|v*b.weights[offset+i*n+j]).sum::<f32>();if d<layers.len(){v.tanh()}else{v}}).collect();
                offset+=(dense.len()+1)*n;dense=next;
            }
            for (a,e) in actual.iter().zip(dense) {assert!((a-e).abs()<1e-5);}
            let mut trained=b.clone();trained.demonstrate(&obs,4);
            assert!(Brain::probabilities(trained.forward(&obs,&mut [0.0;32]))[4]>Brain::probabilities(actual)[4]);
            if layers.len()<8 {
                let first=layers.first().copied().unwrap_or(6);
                for k in [0,605*first,SENSOR_COUNT*first,b.weights.len()-2] {
                    let loss=|v:f32|{let mut c=b.clone();c.weights[k]+=v;-Brain::probabilities(c.forward(&obs,&mut [0.0;32]))[4].ln()};
                    let numerical=(loss(0.001)-loss(-0.001))/0.002;
                    let gradient=(b.weights[k]-trained.weights[k])/0.01;
                    assert!((numerical-gradient).abs()<0.002,"{layers:?} parameter {k}: {numerical} vs {gradient}");
                }
            }
            let decoded:Brain=serde_json::from_slice(&serde_json::to_vec(&trained).unwrap()).unwrap();
            assert_eq!(decoded.layers,trained.layers);assert_eq!(decoded.weights,trained.weights);
        }
        assert!(architecture_params(&[0]).is_none());assert!(architecture_params(&[257]).is_none());assert!(architecture_params(&[1;9]).is_none());
    }
}
