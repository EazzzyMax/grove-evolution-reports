import pathlib, subprocess, concurrent.futures, time
r=pathlib.Path('outputs/chambers');e='target/release/examples/chambers'
(r/'duels').mkdir(exist_ok=True)
jobs=[]
for arch in ['32','128','128-32','32-32']:
 for seed in range(801,807):
  for a,b in [('solo','shared'),('fresh','shared'),('fresh','solo'),('fresh','rotators')]:
   pa=r/f'{a}-{arch}-{seed}'/'final.json';pb=r/'rotators-source.json' if b=='rotators' else r/f'{b}-{arch}-{seed}'/'final.json'
   jobs.append((pa,pb,seed+10000,r/'duels'/f'{a}-vs-{b}-{arch}-{seed}.json'))
def ready(p):return p.exists() and (p.name!='final.json' or (p.parent/'summary.json').exists())
def run(job):
 a,b,seed,out=job
 if out.exists():return
 subprocess.run([e,'duel',str(a),str(b),str(seed),str(out)],check=True)
 print(out.name,flush=True)
# Dispatch only ready inputs: never occupy a worker waiting for training.
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 active={}
 while jobs or active:
  for f in list(active):
   if f.done():f.result();del active[f]
  for job in list(jobs):
   if len(active)>=2:break
   if ready(job[0]) and ready(job[1]):active[pool.submit(run,job)]=job;jobs.remove(job)
  time.sleep(1)
