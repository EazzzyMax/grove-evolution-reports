import json,subprocess
from pathlib import Path
D=Path('outputs/islands');(D/'founders').mkdir(exist_ok=True)
s=json.load(open(D/'selection.json'))
for r in s['islands']:
 tag=r['tag'];start=r['final']['tick']-1000000;founders=[];needle=f'"born":{start},'.encode()
 with (D/'search'/f'{tag}-lives.jsonl').open('rb') as f:
  for line in f:
   if needle in line[:350] and b'"generation":0,' in line[:250] and b'"genome_base":' in line:
    record=json.loads(line);founders.append(record)
 assert len(founders)==4,(tag,len(founders),start)
 w=json.load(open(D/'search'/f'{tag}-final.json'));template=w['agents'][0];agents=[]
 for f in founders:
  a=dict(template);a.update(id=f['id'],parent=None,lineage=f['lineage'],generation=0,x=f['birth_position'][0],y=f['birth_position'][1],age=0,energy=120.,children=0,eaten=0,cracked=0,last_birth=0,action=5,probabilities=[1/6]*6,hidden=[0.]*32,brain=f['genome_base']);agents.append(a)
 w['agents']=agents;w['lives']=[];path=D/'founders'/f'{tag}.json';path.write_text(json.dumps(w,separators=(',',':')))
 subprocess.run(['target/release/examples/island_eval',str(path),tag+'-founders'],check=True)
