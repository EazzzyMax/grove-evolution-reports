import subprocess,concurrent.futures,pathlib,time
r=pathlib.Path('outputs/chambers');e='target/release/examples/chambers'
jobs=[]
for a in ['32','128','128-32']:
 for seed in range(801,807):
  for mode in ['solo','shared','fresh']:
   d=r/f'{mode}-{a}-{seed}';jobs.append((d/'final.json',d/'eval.json'))
  d=r/f'solo-{a}-{seed}';jobs.append((d/'initial.json',d/'initial-eval.json'))
def run(job):
 p,out=job
 while not p.exists():time.sleep(2)
 # final.json is followed by summary.json; wait for complete writer
 if p.name=='final.json':
  while not (p.parent/'summary.json').exists():time.sleep(1)
 result=subprocess.run([e,'eval',str(p),str(out),'128'],capture_output=True,text=True)
 return str(out),result.returncode,result.stderr[-300:]
# Avoid workers all blocking on fresh before its training has started.
jobs.sort(key=lambda j: (not j[0].exists(), 'fresh' in str(j[0])))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for result in pool.map(run,jobs):print(*result,flush=True)
