import pathlib,concurrent.futures,subprocess,json,time
r=pathlib.Path('outputs/detective');exe='target/release/examples/detective'
pools=['target','earlier','main13','main689','rotators','chamber']
jobs=[]
for p in pools:
 jobs.append(('battery',p,[exe,'battery',str(r/f'{p}.json'),str(r/f'{p}-battery.json'),'192']))
 jobs.append(('fingerprint',p,[exe,'fingerprint',str(r/f'{p}.json'),str(r/f'{p}-fingerprint.json')]))
(r/'contests').mkdir(exist_ok=True)
for scene in ['solo','drought','expensive','short_ttl','low_food','poison','wide','dense']:
 for opponent in ['earlier','main13','main689','rotators','chamber']:
  for seed in range(1601,1605):
   for order in ['normal','swap']:
    name=f'{scene}-{opponent}-{seed}-{order}'
    jobs.append(('contest',name,[exe,'contest',str(r/'target.json'),str(r/f'{opponent}.json'),str(seed),scene,order,str(r/'contests'/f'{name}.json')]))
def run(job):
 kind,name,command=job
 out=pathlib.Path(command[-1] if kind=='contest' else command[3])
 if out.exists():return ('skip',name)
 with open(r/f'{kind}-{name}.log','w') as f:subprocess.run(command,stdout=f,stderr=f,check=True)
 return kind,name
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as p:
 for result in p.map(run,jobs):print(*result,flush=True)
