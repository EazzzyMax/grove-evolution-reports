//! Headless research only. Does not modify Grove checkpoints or installed presets.
#![allow(dead_code)]
#[path="../src/brain.rs"] mod brain;
#[path="../src/sim.rs"] mod sim;
#[path="../src/stats.rs"] mod stats;
use brain::*;use sim::*;
use rand::{Rng,SeedableRng,seq::SliceRandom};use rand_chacha::ChaCha8Rng;
use serde::{Serialize,Deserialize};use serde_json::json;
use std::{fs::{self,File},io::{BufReader,BufWriter,Write},time::Instant};
const OUT:&str="outputs/chambers";
#[derive(Clone,Serialize,Deserialize)] struct Pool {name:String,brains:Vec<Brain>}
fn write_json<T:Serialize>(path:&str,v:&T){let mut f=BufWriter::new(File::create(path).unwrap());serde_json::to_writer(&mut f,v).unwrap();f.flush().unwrap();}
fn pool(path:&str)->Pool {let v:serde_json::Value=serde_json::from_reader(BufReader::new(File::open(path).unwrap())).unwrap();let mut b:Vec<Brain>=serde_json::from_value(v["brains"].clone()).unwrap();for b in &mut b {upgrade(b);assert!(b.valid());} Pool{name:v["name"].as_str().or_else(||v["info"]["name"].as_str()).unwrap_or("pool").into(),brains:b}}
fn cfg(seed:u64,mode:&str)->Config {Config{size:if mode=="shared"{32}else{16},initial_population:if mode=="shared"{32}else{1},trees:if mode=="shared"{8}else{2},seed,drop_chance:0.04,food_energy:60.0,strike_cost:2.0,metabolism:0.25,mutation:0.25,max_age:10000,nut_lifetime:1200,cracked_lifetime:400,ready_fraction:0.0,..Default::default()}}
fn compact(w:&mut World){w.lives.retain(|l|w.agents.iter().any(|a|a.id==l.id));for l in &mut w.lives{l.genome_base=None;}w.history.clear();w.lineage_history.clear();w.events.clear();w.stats=Default::default();}
fn put(w:&mut World,brains:&[Brain]) {for (i,a) in w.agents.iter_mut().enumerate(){a.brain=brains[i%brains.len()].clone();}compact(w);}
struct Room {w:World,uid:u64}
fn train(arch:&str,mode:&str,seed:u64,budget:u64){
 let layers:Vec<usize>=arch.split('-').map(|s|s.parse().unwrap()).collect();let name=format!("{mode}-{arch}-{seed}");let dir=format!("{OUT}/{name}");fs::create_dir_all(&dir).unwrap();
 let mut rng=ChaCha8Rng::seed_from_u64(seed^0x498EF);let mut roots=Vec::new();let mut rooms=Vec::new();let mut uid=0u64;
 let mut log=BufWriter::new(File::create(format!("{dir}/events.jsonl")).unwrap());
 let make=|rng:&mut ChaCha8Rng|Brain::configured(rng,&layers).unwrap();
 for _ in 0..32 {roots.push(make(&mut rng));}
 write_json(&format!("{dir}/initial.json"),&Pool{name:format!("initial-{arch}-{seed}"),brains:roots.clone()});
 if mode=="shared" {let mut w=World::new(cfg(seed,mode));put(&mut w,&roots);rooms.push(Room{w,uid:0});}
 else {for (i,b) in roots.iter().enumerate(){let mut w=World::new(cfg(seed.wrapping_mul(1000)+i as u64,mode));put(&mut w,std::slice::from_ref(b));uid+=1;rooms.push(Room{w,uid});}}
 writeln!(log,"{}",json!({"kind":"protocol","name":name,"budget_agent_ticks":budget,"cap":64,"config":cfg(seed,mode),"layers":layers,"root_rooms":32,"seed":seed})).unwrap();
 let started=Instant::now();let mut work=0;let mut births=0;let mut deaths=0;let mut culled=0;let mut restarts=0;let mut eaten=0;let mut cracked=0;let mut strikes=0;let mut max_gen=0;let mut next_checkpoint=budget/4;let mut history=Vec::new();let mut cycles=0u64;
 while work<budget {
  let mut newborns=Vec::new();let mut dead=Vec::new();
  for (ri,room) in rooms.iter_mut().enumerate(){
   if work>=budget {break;}
   let w=&mut room.w;let old=w.counters.clone();let old_n=w.agents.len();let old_id=w.next_id;let before=if mode=="shared" {None}else{Some((w.agents[0].age,w.agents[0].eaten,w.agents[0].cracked,w.agents[0].children,w.agents[0].generation,w.agents[0].x,w.agents[0].y))};
   work+=old_n as u64;w.step_with_population_limit(if mode=="shared"{64}else{2});
   births+=w.counters.births-old.births;deaths+=w.counters.deaths-old.deaths;eaten+=w.counters.eaten-old.eaten;cracked+=w.counters.cracked-old.cracked;strikes+=w.counters.strikes-old.strikes;
   for l in w.lives.iter().filter(|l|l.died==Some(w.tick)){writeln!(log,"{}",json!({"kind":"death","work":work,"room":room.uid,"id":l.id,"parent":l.parent,"born":l.born,"tick":w.tick,"cause":l.cause,"outcome":l.outcome})).unwrap();}
   for a in w.agents.iter().filter(|a|a.id>=old_id){max_gen=max_gen.max(a.generation);let mutations=w.lives.iter().find(|l|l.id==a.id).and_then(|l|l.mutations.as_ref());writeln!(log,"{}",json!({"kind":"birth","work":work,"room":room.uid,"id":a.id,"parent":a.parent,"generation":a.generation,"position":[a.x,a.y],"mutations":mutations})).unwrap();}
   if mode!="shared" && w.agents.len()==2 {
    let child=w.agents.pop().unwrap();let child_record=w.lives.iter().find(|l|l.id==child.id).cloned();compact(w);let mut fork=w.clone();
    let mut child=child;child.x=w.agents[0].x;child.y=w.agents[0].y;
    fork.agents=vec![child];if let Some(l)=child_record {fork.lives.push(l);}fork.rng=ChaCha8Rng::seed_from_u64(rng.random());compact(&mut fork);
    if mode=="fresh" {
        let mut fresh=World::new(cfg(rng.random(),mode));let mut child=fork.agents.pop().unwrap();
        child.x=fresh.agents[0].x;child.y=fresh.agents[0].y;fresh.next_id=child.id+1;fresh.agents=vec![child];fresh.lives.clear();fork=fresh;
    }
    uid+=1;writeln!(log,"{}",json!({"kind":"fork","work":work,"child_room":uid,"parent_room":room.uid})).unwrap();newborns.push(Room{w:fork,uid});
   }
   if w.agents.is_empty(){if let Some(b)=before{writeln!(log,"{}",json!({"kind":"room_death","work":work,"uid":room.uid,"age_before":b.0,"eaten_before":b.1,"cracked_before":b.2,"children":b.3,"generation":b.4})).unwrap();}dead.push(ri);}
   if cycles%500==0 {compact(w);}
  }
  for i in dead.into_iter().rev(){rooms.swap_remove(i);}
  rooms.extend(newborns);
  while rooms.len()>64 {let i=rng.random_range(0..rooms.len());writeln!(log,"{}",json!({"kind":"capacity_cull","uid":rooms[i].uid,"work":work})).unwrap();rooms.swap_remove(i);culled+=1;}
  if rooms.is_empty(){restarts+=1;let newroots:Vec<_>=(0..32).map(|_|make(&mut rng)).collect();write_json(&format!("{dir}/restart-{restarts}.json"),&Pool{name:format!("restart-{restarts}"),brains:newroots.clone()});
   if mode=="shared"{let mut w=World::new(cfg(rng.random(),mode));put(&mut w,&newroots);uid+=1;rooms.push(Room{w,uid});}
   else{for b in &newroots{let mut w=World::new(cfg(rng.random(),mode));put(&mut w,std::slice::from_ref(b));uid+=1;rooms.push(Room{w,uid});}}
   writeln!(log,"{}",json!({"kind":"restart","work":work,"restart":restarts,"first_room":rooms[0].uid})).unwrap();
  }
  if work>=next_checkpoint || work>=budget {
   let brains=rooms.iter().flat_map(|r|r.w.agents.iter().map(|a|a.brain.clone())).collect();
   write_json(&format!("{dir}/checkpoint-{}.json",history.len()+1),&Pool{name:name.clone(),brains});
   let rec=json!({"work":work,"alive":rooms.iter().map(|r|r.w.agents.len()).sum::<usize>(),"births":births,"deaths":deaths,"capacity_culls":culled,"restarts":restarts,"eaten":eaten,"cracked":cracked,"strikes":strikes,"generation":max_gen,"seconds":started.elapsed().as_secs_f64()});
   history.push(rec);log.flush().unwrap();next_checkpoint+=budget/4;
  }
  cycles+=1;
 }
 let finalpool=Pool{name:name.clone(),brains:rooms.iter().flat_map(|r|r.w.agents.iter().map(|a|a.brain.clone())).collect()};write_json(&format!("{dir}/final.json"),&finalpool);write_json(&format!("{dir}/summary.json"),&history);
 eprintln!("DONE {name} work={work} births={births} restarts={restarts} gen={max_gen} sec={:.1}",started.elapsed().as_secs_f64());
}
fn observe(w:&World,a:&Agent,temperature:Option<f32>)->Vec<(usize,f32)> {let mut occ=vec![false;w.cells.len()];for b in &w.agents{occ[w.config.index(b.x,b.y).unwrap()]=true;}let mut obs=Vec::new();World::observation_wrapped(w.config.size,&w.cells,&occ,a,w.config.max_age,w.config.seasonal,&mut obs);if w.config.seasonal {obs.push((VISUAL_INPUTS+6,temperature.unwrap_or_else(||w.config.fertility(a.x as usize,w.tick))));}obs}
fn probe(p:&Pool)->serde_json::Value {
 let mut records=Vec::new();
 for scene in ["empty","whole_ahead","ready_ahead","ready_under","poison_under","tree_ahead","tree_left","tree_right","tree_behind"] {
  for temp in [0.0,0.5,1.0] {for dir in 0..4 {
   let mut w=World::new(Config{size:32,initial_population:1,trees:0,seasonal:true,..Default::default()});w.agents[0].x=16;w.agents[0].y=16;w.agents[0].dir=dir;w.agents[0].energy=60.;w.agents[0].age=200;
   let (right,forward)=match scene{"tree_left"=>(-1,0),"tree_right"=>(1,0),"tree_behind"=>(0,-1),"ready_under"|"poison_under"=>(0,0),_=>(0,1)};
   let (x,y)=relative(&w.agents[0],right,forward);let i=w.config.index(x,y).unwrap();
   match scene {"whole_ahead"=>w.cells[i].nut=1,"ready_ahead"|"ready_under"=>w.cells[i].nut=2,"poison_under"=>w.cells[i].nut=3,s if s.starts_with("tree")=>w.cells[i].tree=true,_=>{}}
   let obs=observe(&w,&w.agents[0],Some(temp));let mut probabilities=[0.0f64;6];
   for b in &p.brains {for (j,v) in Brain::probabilities(b.forward(&obs,&mut [0.;32])).iter().enumerate(){probabilities[j]+=*v as f64/p.brains.len() as f64;}}
   records.push(json!({"scene":scene,"temperature":temp,"direction":dir,"p":probabilities}));
  }}
 }
 json!({"name":p.name,"n":p.brains.len(),"records":records})
}
fn scenario(brain:&Brain,seed:u64,scene:&str)->World {
 let mut c=cfg(seed,"solo");c.seasonal=scene.ends_with("torus");c.initial_population=1;c.trees=if scene=="solo"||scene=="drought"||scene.ends_with("torus"){2}else{0};c.drop_chance=if scene=="drought"||scene=="drought_torus"{0.01}else if scene=="solo"||scene=="torus"{0.04}else{0.0};
 let mut w=World::new(c);put(&mut w,std::slice::from_ref(brain));
 if scene!="solo"&&scene!="drought"&&!scene.ends_with("torus") {
  w.agents[0].x=8;w.agents[0].y=8;w.agents[0].dir=0;w.agents[0].energy=120.0;
  let i=7*16+8;w.cells[i].nut=if scene=="ready"{2}else{1};w.cells[i].ttl=1200;
  if scene=="nut_tree" {w.cells[6*16+8].tree=true;}
  w.validate().unwrap();
 }
 w
}
fn evaluate(p:&Pool,seed:u64,count:usize)->serde_json::Value {
 evaluate_scenes(p,seed,count,&["nut","ready","nut_tree","solo","drought"])
}
fn evaluate_scenes(p:&Pool,seed:u64,count:usize,scenes:&[&str])->serde_json::Value {
 let mut records=Vec::new();
 let mut chosen:Vec<_>=(0..p.brains.len()).collect();chosen.shuffle(&mut ChaCha8Rng::seed_from_u64(seed));
 for &scene in scenes {
  for n in 0..count {let bi=chosen[n%chosen.len()];let brain=&p.brains[bi];let mut w=scenario(brain,seed+n as u64,scene);let limit=if scene=="solo"||scene=="drought"||scene.ends_with("torus"){5000}else{300};let mut first_food=None;let mut first_crack=None;let mut east=0;let mut steps=0;
   for _ in 0..limit {if w.agents.is_empty(){break;}w.step_with_population_limit(1);if w.counters.eaten>0&&first_food.is_none(){first_food=Some(w.tick);}if w.counters.cracked>0&&first_crack.is_none(){first_crack=Some(w.tick);}if let Some(a)=w.agents.first(){if let Some(t)=&a.travel{east=t.east;steps=t.steps;}}}
   records.push(json!({"scene":scene,"trial":n,"brain":bi,"ticks":w.tick,"alive":!w.agents.is_empty(),"eaten":w.counters.eaten,"cracked":w.counters.cracked,"strikes":w.counters.strikes,"first_food":first_food,"first_crack":first_crack,"steps":steps,"east":east}));
  }
 }
 json!({"name":p.name,"records":records})
}
fn duel(a:&Pool,b:&Pool,seed:u64)->serde_json::Value {
 let mut w=World::new(Config{initial_population:32,..cfg(seed,"shared")});let mut order:Vec<_>=(0..32).collect();order.shuffle(&mut ChaCha8Rng::seed_from_u64(seed^0xabc));
 let mut sampling=ChaCha8Rng::seed_from_u64(seed^0xdef);let mut ai:Vec<_>=(0..a.brains.len()).collect();let mut bi:Vec<_>=(0..b.brains.len()).collect();ai.shuffle(&mut sampling);bi.shuffle(&mut sampling);
 for (j,&i) in order.iter().enumerate(){w.agents[i].brain=if j<16 {a.brains[ai[j%ai.len()]].clone()}else{b.brains[bi[(j-16)%bi.len()]].clone()};w.agents[i].lineage=if j<16{1}else{2};}compact(&mut w);
 let mut history=Vec::new();for tick in 0..20000 {if w.agents.is_empty(){break;}w.step_with_population_limit(128);if tick%1000==999{history.push(json!({"tick":w.tick,"a":w.agents.iter().filter(|a|a.lineage==1).count(),"b":w.agents.iter().filter(|a|a.lineage==2).count()}));compact(&mut w);}}
 json!({"a":a.name,"b":b.name,"seed":seed,"history":history})
}
fn seasonal(p:&Pool,seed:u64,condition:&str)->serde_json::Value {
 let mut w=World::new(Config{size:128,trees:90,initial_population:32,seasonal:true,season_period:3000,seed,food_energy:60.,drop_chance:0.04,strike_cost:2.,mutation:0.25,max_age:10000,..Default::default()});put(&mut w,&p.brains);
 let mut history=Vec::new();let mut states=std::collections::BTreeMap::<String,[f64;4]>::new();
 let mut previous_steps=0;let mut previous_east=0;
 for tick in 0..12000 {
  if w.agents.is_empty(){break;}
  // Keep statistics before each step; counters continue across checkpoint compaction.
  if tick%20==0 {for a in &w.agents {
   let t=w.config.fertility(a.x as usize,w.tick);let zone=if t<0.2{"cold"}else if t>0.8{"warm"}else{"edge"};
   let near=(-2..=2).any(|dy|(-2..=2).any(|dx|w.cells[w.config.index(a.x+dx,a.y+dy).unwrap()].tree));
   let row=states.entry(format!("{zone}_{}",if near{"tree"}else{"open"})).or_default();
   let obs=observe(&w,a,None);let ps=Brain::probabilities(a.brain.forward(&obs,&mut [0.;32]));
   row[0]+=1.;row[1]+=ps[0] as f64;row[2]+=ps[3] as f64;row[3]+=ps[4] as f64;
  }}
  w.step_with_sensor_filter(|_,obs|match condition {
   "no_temperature"=>{for (i,v) in obs {if *i==611 {*v=0.5;}}},
   "no_trees"=>obs.retain(|(i,_)|!(*i<VISUAL_INPUTS && *i%5==1)),
   "no_compass"=>obs.retain(|(i,_)|!(*i>=607 && *i<=610)),_=>{}
  });
  let b=&w.stats.current;previous_steps=b.steps;previous_east=b.east;
  if tick%500==499 {history.push(json!({"tick":w.tick,"alive":w.agents.len(),"births":w.counters.births,"eaten":w.counters.eaten,"cracked":w.counters.cracked,"mean_x":w.agents.iter().map(|a|a.x as f64).sum::<f64>()/w.agents.len().max(1) as f64,"agent_ticks":b.agent_ticks,"steps":b.steps,"live_mean_east":w.agents.iter().map(|a|a.travel.as_ref().map_or(0,|t|t.east) as f64).sum::<f64>()/w.agents.len().max(1) as f64}));compact(&mut w);}
 }
 json!({"name":p.name,"seed":seed,"condition":condition,"ticks":w.tick,"alive":w.agents.len(),"counters":w.counters,"history":history,"states":states,"last_steps":previous_steps,"last_death_east":previous_east})
}
fn residence(p:&Pool)->serde_json::Value {
 let mut records=Vec::new();
 for tree in [false,true] {for temp in [0.0,1.0] {for dir in 0..4 {for (bi,b) in p.brains.iter().enumerate() {
  let mut w=World::new(Config{size:64,initial_population:1,trees:0,seasonal:true,drop_chance:0.,seed:4400+bi as u64,metabolism:0.25,strike_cost:2.,..Default::default()});
  w.agents[0].brain=b.clone();w.agents[0].x=35;w.agents[0].y=32;w.agents[0].dir=dir;if tree {w.cells[32*64+32].tree=true;}w.validate().unwrap();
  let mut near=0;let mut east=0;let mut steps=0;let mut actions=[0u32;6];
  for _ in 0..300 {if w.agents.is_empty(){break;}
   let a=&w.agents[0];let dx=(a.x-32).abs().min(64-(a.x-32).abs());let dy=(a.y-32).abs().min(64-(a.y-32).abs());if dx<=5&&dy<=5 {near+=1;}
   w.step_with_sensor_filter(|_,obs|{for (i,v) in obs{if *i==611 {*v=temp;}}});
   if let Some(a)=w.agents.first(){actions[a.action]+=1;if let Some(t)=&a.travel{east=t.east;steps=t.steps;}}
  }
  records.push(json!({"tree":tree,"temperature":temp,"direction":dir,"brain":bi,"near":near,"ticks":w.tick,"east":east,"steps":steps,"actions":actions}));
 }}}}
 json!({"name":p.name,"records":records})
}
fn benchmark()->serde_json::Value {
 let mut records=Vec::new();
 for rep in 0..5 {for layers in [vec![32],vec![128],vec![128,32],vec![32,32]] {
  let mut rng=ChaCha8Rng::seed_from_u64(111);let b=Brain::configured(&mut rng,&layers).unwrap();
  let mut w=World::new(cfg(444,"solo"));put(&mut w,std::slice::from_ref(&b));let obs=observe(&w,&w.agents[0],None);let mut hidden=[0.;32];
  let start=Instant::now();for _ in 0..100000 {std::hint::black_box(b.forward(std::hint::black_box(&obs),&mut hidden));}
  records.push(json!({"layers":layers,"rep":rep,"weights":b.weights.len(),"active_inputs":obs.len(),"calls":100000,"seconds":start.elapsed().as_secs_f64()}));
 }} json!({"records":records})
}
fn main(){rayon::ThreadPoolBuilder::new().num_threads(1).build_global().unwrap();let args:Vec<_>=std::env::args().collect();match args[1].as_str(){
 "benchmark"=>write_json(&args[2],&benchmark()),
 "train"=>train(&args[2],&args[3],args[4].parse().unwrap(),args[5].parse().unwrap()),
 "eval"=>{let p=pool(&args[2]);write_json(&args[3],&evaluate(&p,900001,args.get(4).map_or(64,|s|s.parse().unwrap())));},
 "blind_eval"=>{let mut p=pool(&args[2]);for b in &mut p.brains {let n=b.layers.as_ref().expect("configured brain")[0];for input in (0..VISUAL_INPUTS).chain(POISON_INPUT..SENSOR_COUNT){b.weights[input*n..(input+1)*n].fill(0.0);}}write_json(&args[3],&evaluate_scenes(&p,900001,128,&["solo"]));},
 "learning_eval"=>{let p=pool(&args[2]);write_json(&args[3],&evaluate_scenes(&p,900001,128,&["solo"]));},
 "torus_eval"=>{let p=pool(&args[2]);write_json(&args[3],&evaluate_scenes(&p,900001,128,&["torus","drought_torus"]));},
 "probe"=>{let p=pool(&args[2]);write_json(&args[3],&probe(&p));},
 "residence"=>{let p=pool(&args[2]);write_json(&args[3],&residence(&p));},
 "seasonal"=>{let p=pool(&args[2]);write_json(&args[5],&seasonal(&p,args[3].parse().unwrap(),&args[4]));},
 "duel"=>{let a=pool(&args[2]);let b=pool(&args[3]);write_json(&args[5],&duel(&a,&b,args[4].parse().unwrap()));},
 _=>panic!("train/eval/probe/duel")}}

#[cfg(test)] mod research_tests {
 use super::*;
 #[test] fn fork_keeps_one_agent_and_does_not_share_future_food(){
  let mut w=World::new(cfg(5,"solo"));w.agents[0].energy=220.;w.agents[0].age=60;w.step_with_population_limit(2);assert_eq!(w.agents.len(),2);
  let child=w.agents.pop().unwrap();let mut fork=w.clone();fork.agents=vec![child];fork.rng=ChaCha8Rng::seed_from_u64(66);
  assert_eq!(w.agents.len(),1);assert_eq!(fork.agents.len(),1);assert_eq!(w.cells.iter().map(|c|c.nut).collect::<Vec<_>>(),fork.cells.iter().map(|c|c.nut).collect::<Vec<_>>());
  let i=w.cells.iter().position(|c|c.nut==1).unwrap();fork.cells[i].nut=0;assert_eq!(w.cells[i].nut,1);
  assert_eq!(fork.agents[0].energy,60.);assert!(w.agents[0].energy<140.1);
 }
 #[test] fn diagnostic_can_complete_crack_move_eat(){
  let b=Brain::configured(&mut ChaCha8Rng::seed_from_u64(1),&[32]).unwrap();let mut w=scenario(&b,1,"nut");w.control=Some(w.agents[0].id);
  w.teach_step(3);assert_eq!(w.cells[7*16+8].nut,2);w.teach_step(0);w.teach_step(4);assert_eq!(w.counters.eaten,1);
 }
}
