import subprocess,time,json,concurrent.futures
from pathlib import Path
out=Path('outputs/comparison')
conditions=['normal','drought','expensive','sparse','no_nuts','pulses','short_pulses']
jobs=[]
for cond in conditions:
 for seed in range(1,6):
  for mode,swap in [('old',0),('current',0),('duel',0),('duel',1)]:jobs.append((mode,cond,str(seed),str(swap),'20000','frozen'))
for seed in range(1,6):
 for swap in range(2):jobs.append(('champion','normal',str(seed),str(swap),'20000','frozen'))
for cond in ['normal','drought']:
 for seed in range(1,6):
  for swap in range(2):jobs.append(('duel',cond,str(seed),str(swap),'20000','mut'))
(out/'design.json').write_text(json.dumps({'jobs':jobs,'conditions':conditions,'replicates':5,'paired_swaps':True,'population':120,'duration':20000,'workers':4},indent=2))
def run(job):
 mode,cond,seed,swap,steps,evolve=job
 p=out/'runs'/f'{mode}-{cond}-{seed}-{swap}-{evolve}.jsonl'
 if p.exists():
  lines=p.read_text().splitlines()
  if lines and '"kind":"final"' in lines[-1] and json.loads(lines[-1])['duration']==int(steps):return 'cached '+p.name
 t=time.time();r=subprocess.run(['target/release/examples/compare',*job],capture_output=True,text=True)
 if r.returncode:raise RuntimeError(str(job)+r.stderr)
 return f'{time.time()-t:.1f}s '+r.stdout.strip()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for i,r in enumerate(ex.map(run,jobs)):print(f'{i+1}/{len(jobs)} {r}',flush=True)
