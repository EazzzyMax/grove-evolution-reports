import json,collections,numpy as np
from pathlib import Path
D=Path('outputs/islands');results=[];assays={}
for p in (D/'assays').glob('*.jsonl'):
 rows=[json.loads(l) for l in p.open()];tag=p.stem;bytask=collections.defaultdict(list)
 for r in rows:bytask[r['task']].append(r)
 assays[tag]={'brains':len(set(r['agent'] for r in rows)),'trials':len(rows),'tasks':{t:{'success':float(np.mean([r['success'] for r in rs])),'penalized_time':float(np.mean([r['ticks'] if r['success'] else 300 for r in rs]))} for t,rs in bytask.items()},'whole_score':float(np.mean([r['success'] for r in rows if r['task'].startswith('whole')]))}
for p in (D/'search').glob('*-final.json'):
 tag=p.name.removesuffix('-final.json');mode,id=tag.split('-');log=[json.loads(l) for l in (D/'search'/f'{tag}.jsonl').open()];final=log[-1];assert final['kind']=='final' and final['colony_age']==1000000
 ext=[r for r in log if r.get('kind')=='extinction'];samples=[r for r in log if 'colony_age'in r];start=final['tick']-1000000
 results.append({'tag':tag,'mode':mode,'island':int(id),'final':final,'failed_attempts':len(ext),'total_failed_ticks':sum(r['duration'] for r in ext),'max_failed_lifetime':max([r['duration'] for r in ext],default=0),'last_colony_mean_n':float(np.mean([r['n'] for r in samples if r['tick']>=start+100000])),'assay':assays[tag]})
selected=[]
for mode in ['free','cap4']:
 ranked=sorted([r for r in results if r['mode']==mode],key=lambda r:(-r['assay']['whole_score'],r['island']))
 selected.extend(r['tag'] for r in ranked[:2])
 print(mode,'mean solo',np.mean([r['assay']['whole_score'] for r in ranked]),'median',np.median([r['assay']['whole_score'] for r in ranked]),'restarts',sum(r['failed_attempts'] for r in ranked),'best',[(r['tag'],r['assay']['whole_score']) for r in ranked[:4]])
summary={'islands':results,'assays':assays,'selected':selected};(D/'selection.json').write_text(json.dumps(summary,indent=2));print('selected',selected)
