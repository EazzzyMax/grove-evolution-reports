import concurrent.futures,subprocess,pathlib
r=pathlib.Path('outputs/chambers');e='target/release/examples/chambers'
def run(d):
 subprocess.run([e,'blind_eval',str(d/'final.json'),str(d/'blind-eval.json')],check=True)
 print(d.name,flush=True)
jobs=[r/f'{m}-{a}-{s}' for a in ['32','32-32','128','128-32'] for m in ['solo','fresh','shared'] for s in range(801,807)]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as p:list(p.map(run,jobs))
