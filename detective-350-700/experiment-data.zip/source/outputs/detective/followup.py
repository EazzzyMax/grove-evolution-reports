import concurrent.futures,pathlib,subprocess
r=pathlib.Path('outputs/detective');e='target/release/examples/detective'
jobs=[]
for p in ['target','earlier','main13','main689','rotators','chamber']:
 jobs.append(([e,'focused',str(r/f'{p}.json'),str(r/f'{p}-focused.json')],p+' focused'))
for scene in ['whole_short','ready_short','frozen_solo','frozen_short_ttl']:
 for opp in ['earlier','main13','main689']:
  for seed in range(1601,1605):
   for order in ['normal','swap']:
    name=f'{scene}-{opp}-{seed}-{order}';jobs.append(([e,'contest',str(r/'target.json'),str(r/f'{opp}.json'),str(seed),scene,order,str(r/'contests'/f'{name}.json')],name))
for scene in ['cost20','cheap']:
 for seed in range(1601,1605):
  for order in ['normal','swap']:
   name=f'{scene}-main13-{seed}-{order}';jobs.append(([e,'contest',str(r/'target.json'),str(r/'main13.json'),str(seed),scene,order,str(r/'contests'/f'{name}.json')],name))
def run(j):
 command,name=j
 with open(r/f'{name}.log','w') as f:subprocess.run(command,stdout=f,stderr=f,check=True)
 return name
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as p:
 for name in p.map(run,jobs):print(name,flush=True)
