import pathlib,json,statistics as s,collections,hashlib
R=pathlib.Path(__file__).parent
read=lambda p:json.loads(p.read_text())
def summarize(v):
 d={}
 for scene in sorted({x['scene'] for x in v}):
  z=[x for x in v if x['scene']==scene];tt=[x['first_food'] for x in z if x['first_food'] is not None]
  d[scene]={'n':len(z),'food':s.mean(x['eaten'] for x in z),'success':s.mean(x['eaten']>0 for x in z)*100,'survival':s.mean(x['alive'] for x in z)*100,'ticks':s.mean(x['ticks'] for x in z),'first_food':s.mean(tt) if tt else None,'strikes':s.mean(x['strikes'] for x in z),'cracked':s.mean(x['cracked'] for x in z)}
  if 'poisoned' in z[0]:d[scene]['poison_deaths']=sum(x['poisoned'] for x in z)
 return d
old=read(pathlib.Path('outputs/detective/analysis.json'));D={'confirmed_lineage':'User confirmed barbarians continue 350+700','new':{k:summarize(read(R/f'{k}.json')['records']) for k in ['battery','focused']},'old':{k:old[k]['target'] for k in ['battery','focused']},'old_audit':old['audit'],'old_contests':old['contests'],'genomes':read(R/'genomes.json'),'contests':{}}
D['new']['fingerprint']=[{k:v for k,v in x.items() if k!='individual'} for x in read(R/'fingerprint.json')['records']];D['old']['fingerprint']=old['fingerprint']['target']
v=read(R/'micro_audit.json')['records'];D['audit']={scene:{'n':sum(x['scene']==scene for x in v),'success':sum(x['success'] for x in v if x['scene']==scene),'mean_ticks':s.mean(x['first_food'] for x in v if x['scene']==scene and x['success'])} for scene in sorted({x['scene'] for x in v})}
groups=collections.defaultdict(list)
for p in (R/'contests').glob('*.json'):
 v=read(p);groups[(v['scene'],p.name.split('-')[1])].append(v)
for (scene,opp),z in groups.items():D['contests'][scene+':'+opp]={'n':len(z),'wins':sum(x['final_a']>x['final_b'] for x in z),'losses':sum(x['final_a']<x['final_b'] for x in z),'both_dead':sum(x['final_a']==x['final_b']==0 for x in z),'final_a':s.mean(x['final_a'] for x in z),'final_b':s.mean(x['final_b'] for x in z),'own':[sum(x['own'][i] for x in z) for i in [0,1]],'other':[sum(x['other'][i] for x in z) for i in [0,1]],'self_food':[sum(x['self_food'][i] for x in z) for i in [0,1]],'runs':[{'seed':x['seed'],'swap':x['swap'],'a':x['final_a'],'b':x['final_b']} for x in z]}
D['clutter']={};D['poison']={}
for p in ['barbarians','350700']:
 D['clutter'][p]=read(R/f'{p}-clutter.json')['records'];v=read(R/f'{p}-poison.json')['records'];D['poison'][p]=[{'disabled':dis,'n':sum(x['disabled']==dis for x in v),'deaths':sum(x['poisoned'] for x in v if x['disabled']==dis),'ticks':s.mean(x['ticks'] for x in v if x['disabled']==dis),'food':s.mean(x['eaten'] for x in v if x['disabled']==dis)} for dis in [False,True]]
D['source_sha256']=hashlib.sha256((R/'source.json').read_bytes()).hexdigest();D['total_contests']=sum(x['n'] for x in D['contests'].values());assert D['total_contests']==216
(R/'analysis.json').write_text(json.dumps(D,ensure_ascii=False,indent=2));print('216 contests complete')
