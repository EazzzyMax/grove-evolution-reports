import json,subprocess,concurrent.futures,os
from pathlib import Path
D=Path('outputs/islands');selected=json.load(open(D/'selection.json'))['selected']
def run(job):
 tag,seed,swap=job;env=os.environ.copy();env['ISLAND_WORLD']=str(D/'search'/f'{tag}-final.json');env['ISLAND_TAG']=tag
 r=subprocess.run(['target/release/examples/island_duel','duel','normal',str(seed),str(swap),'20000','frozen'],env=env,capture_output=True,text=True)
 if r.returncode:raise RuntimeError(r.stderr)
 return r.stdout.strip()
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as e:
 for i,result in enumerate(e.map(run,[(t,s,r) for t in selected for s in range(1,6) for r in range(2)])):print(i+1,result,flush=True)
