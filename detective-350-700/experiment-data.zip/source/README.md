# Grove: 350+700 behavioral investigation (2026-11-11)

Frozen inputs are described by manifest.json (names, SHA-256, counts, architecture).
The public archive deliberately omits the original population weights. Put the
corresponding presets/pools into outputs/detective/{target,earlier,main13,main689,rotators,chamber}.json.
Without these files the numerical experiments cannot be rerun from this archive alone.
All raw trial outcomes and comparison outcomes are included under data/.

Rust 1.95+, Python 3. Analyses and plots additionally need NumPy, SciPy and Matplotlib.
From the source/ directory:

    cargo build --release --example detective
    cargo test --release --example detective detective_tests
    cargo test --release --example detective sensor_tests
    python3 outputs/detective/run.py
    python3 outputs/detective/followup.py
    target/release/examples/detective micro_audit outputs/detective/target.json outputs/detective/target-micro-audit.json
    python3 outputs/detective/genomes.py
    python3 outputs/detective/clusters.py
    python3 outputs/detective/analyze.py

run.py: six populations, 33 battery conditions with 192 trials each, exact policy
fingerprints, 320 contests. followup.py: nine focused conditions with 256 trials,
112 additional contests. Full micro audit: 454 brains x four repeats x four tasks.
The final fingerprint code includes distances 0,1,2,3,4,5.

All environments are nonseasonal, as requested. No temperature experiments.
The research copy sim_research.rs differs from the frozen production simulator
only by skipped serialization fields and bookkeeping for the cracker/eater of each nut.
A regression test checks identical complete serialized world state and RNG after
500 ticks, and verifies event count equals eaten counter. The sensory-mask test
checks equivalence to removing boundary inputs, for both network layouts.

Each contest uses four map seeds and mirrored starting groups: eight matches,
not eight independent maps. Normal contests allow mutations and reproduction;
frozen_* contests set mutation strength to zero but preserve reproduction.
Final surviving descendants determine the winner; mutual extinction is recorded separately.
Nut attribution records actual successful cracking and eating in execution order,
including same-tick consumption and poisoning, without extra random draws.

Absolute performance is specific to these presets and environments. Preset tick
is not cumulative genealogy time. Gene distance is not proof of direct ancestry.
Original training-world settings and checkpoint contents were not inspected.
